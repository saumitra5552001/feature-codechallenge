package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.Reporting.ExtentManager;
import com.surveilx.qa.Utils.DriverManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;
//import io.qameta.allure.Allure;
import io.qameta.allure.Allure;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.html.HTMLOptionElement;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class Hooks extends CommonFunctions {

    public WebDriver driver ;
    public WebDriverWait wait = DriverManager.getWebDriverWait();
    public static String scenarioName;

    @Before
    public void initializeTest(Scenario scenario) throws Exception {
        scenarioName = scenario.getName();
        ExtentManager.startTest(scenario.getName());


        //String executionEnv = prop.getProperty("executionEnv");
        String executionEnv = jsonRead.readStringFromEnvironmentJSON("executionMode");
        String browser = jsonRead.readStringFromEnvironmentJSON("browser");
        if (executionEnv.equalsIgnoreCase("Local")) {
            if (browser.equalsIgnoreCase("Chrome")) {
                WebDriverManager.chromedriver().setup();
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--incognito");
                options.addArguments("start-maximized");
                options.addArguments("--ignore-ssl-errors=yes");
                options.addArguments("--ignore-certificate-errors");
                options.addArguments("--headless");
                options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
                //options.addArguments("user-data-dir=C:/Users/pgandhi/AppData/Local/Google/Chrome/User Data");
                HashMap<String, Object> chromePref = new HashMap<>();
                chromePref.put("download.default_directory", System.getProperty("user.home") + "\\Downloads");
                chromePref.put("pdfjs.disabled", true);
                chromePref.put("plugins.always_open_pdf_externally", true);
                options.setExperimentalOption("prefs", chromePref);
                DesiredCapabilities capabilities = new DesiredCapabilities();
                capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                options.merge(capabilities);
                driver = new ChromeDriver(options);
            }
            if (browser.equalsIgnoreCase("IE")) {
                System.setProperty("webdriver.ie.driver", "C:\\Users\\pgandhi\\IdeaProjects\\test1\\Drivers\\IEDriverServer.exe");
                driver = new InternetExplorerDriver();
                driver.manage().window().maximize();
            }
            if (browser.equalsIgnoreCase("Edge")) {
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                driver.manage().window().maximize();
            }
            if (browser.equalsIgnoreCase("HTML")) {
                driver = new HtmlUnitDriver(true);
              //  driver.setJavascriptEnabled(true);
                driver.manage().window().maximize();
            }
        }
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
        DriverManager.setDriver(driver);

        wait = new WebDriverWait(driver, 60);
        DriverManager.setWebDriverWait(wait);
    }

    @After
    public void TearDownApplication(Scenario scenario) throws IOException {
        attachScreenshotToAllureReport();
        if (scenario.isFailed()) {
            logFail(driver,"Test Case is failed");
        }
        if (driver != null) {
            driver.quit();
        }
    }

    public void attachScreenshotToAllureReport() throws IOException {
        Allure.getLifecycle()
                .addAttachment(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yy_hh:mm:ss")), "image/png", "png", getByteArrayFromAshot());
    }

    public byte[] getByteArrayFromAshot() throws IOException {
        byte[] imageInByte = null;
        BufferedImage image = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(100)).takeScreenshot(DriverManager.getDriver()).getImage();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "jpg", baos);
        baos.flush();
        imageInByte = baos.toByteArray();
        baos.close();
        return imageInByte;
    }
}
