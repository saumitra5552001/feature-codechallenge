package com.surveilx.qa.BaseLibrary;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.surveilx.qa.Reporting.ExtentManager;
import com.surveilx.qa.Utils.DriverManager;
import com.surveilx.qa.Utils.JSONReader;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class CommonFunctions extends ExtentManager {

    public static Properties prop;
    public static FileInputStream fis;

    public WebDriver driver;
    public WebDriverWait wait;
    public String parentWindow;
    Set<String> allWindow;

    {
        driver = DriverManager.getDriver();
        wait = DriverManager.getWebDriverWait();
    }

    public JSONReader jsonRead = new JSONReader();

    /**
     * To load properties file
     * @author pgandhi
     * @param fileName - property file path and name
     * @exception java.io.FileNotFoundException - Throws exception
     */
    public static void loadConfig(String fileName) throws IOException {
        if (prop == null) {
            fis = new FileInputStream(fileName);
            prop = new Properties();
            prop.load(fis);
        }
    }

    public static int counter = 0;

    /**
     * To log failure instance in extent report
     * @author pgandhi
     * @param driver - WebDriver
     * @param message - Logger Message
     * @exception java.io.FileNotFoundException - Throws exception
     */
    public static synchronized void logFail(WebDriver driver, String message) throws IOException {
        Augmenter augmenter = new Augmenter();
        //TakesScreenshot screenshot = (TakesScreenshot) augmenter.augment(driver);
        //File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
     //   String path_screenshot = System.getProperty("user.dir") + "/TestReport/Screenshot/" + timeStamp + "/" + counter;
      //  File targetFile = new File(path_screenshot + ".png");
      //  FileUtils.copyFile(srcFile, targetFile);
      //  String path = path_screenshot.concat(".png");
        ExtentManager.getTest().log(Status.FAIL, "<b>" + "<font color=" + "red>" + message + "</font>" + "</b>");
        Assert.assertTrue(true, message);
        counter++;
    }

    /**
     * To log pass instance in extent report
     * @author pgandhi
     * @param driver - WebDriver
     * @param message - Logger Message
     * @exception java.io.FileNotFoundException - Throws exception
     */
    public static synchronized void logPass(WebDriver driver, String message) throws IOException {
        Augmenter augmenter = new Augmenter();
        TakesScreenshot screenshot = (TakesScreenshot) augmenter.augment(driver);
//        File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
//        String path_screenshot = System.getProperty("user.dir") + "/TestReport/Screenshot/" + timeStamp + "/" + counter;
//        File targetFile = new File(path_screenshot + ".png");
//        FileUtils.copyFile(srcFile, targetFile);
//        String path = path_screenshot.concat(".png");
        ExtentManager.getTest().log(Status.PASS, "<b>" + "<font color=" + "green>" + message + "</font>" + "</b>");
        Assert.assertTrue(true, message);
        counter++;
    }

    /**
     * To log informative instance in extent report
     * @author pgandhi
     * @param driver - WebDriver
     * @param message - Logger Message
     * @exception java.io.FileNotFoundException - Throws exception
     */
    public static synchronized void logInfo(WebDriver driver, String message) throws IOException {
        Augmenter augmenter = new Augmenter();
//        TakesScreenshot screenshot = (TakesScreenshot) augmenter.augment(driver);
//        File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
//        String path_screenshot = System.getProperty("user.dir") + "/TestReport/Screenshot/" + timeStamp + "/" + counter;
//        File targetFile = new File(path_screenshot + ".png");
//        FileUtils.copyFile(srcFile, targetFile);
//        String path = path_screenshot.concat(".png");
        ExtentManager.getTest().log(Status.INFO, "<font color=" + "black>" + message + "</font>");
        Assert.assertTrue(true, message);
        counter++;
    }

    /**
     * To verify text(equalsIgnoreCase)
     * @author pgandhi
     * @param element - WebElement
     * @param data - Expected data
     */
    public void verifyText(WebElement element, String data) throws IOException {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            String actual = element.getText().trim();
            String expected = data.trim();
            if (actual.equalsIgnoreCase(expected)) {
                logPass( driver,"Expected: " + expected + " value is matching with Actual: " + actual);
            } else {
                logFail(driver, "Expected: " + expected + " value is not matching with Actual: " + actual);
                Assert.fail("Expected: " + expected + " value is not matching with Actual: " + actual);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
        }
    }

    /**
     * To verify text(equalsIgnoreCase)
     * @author pgandhi
     * @param locator - By locator
     * @param data - Expected data
     */
    public void verifyText(By locator, String data) throws IOException {
        WebElement element = null;
        try {
            scrollIntoView(locator);
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            String actual = element.getText().trim();
            String expected = data.trim();
            System.out.println(expected);
            System.out.println(actual);
            if (actual.equalsIgnoreCase(expected)) {
                logPass(driver, "Expected: " + expected + " value is matching with Actual: " + actual);
            } else {
                logFail(driver, "Expected: " + expected + " value is not matching with Actual: " + actual);
                Assert.fail("Expected: " + expected + " value is not matching with Actual: " + actual);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
        }
    }

    public void verifyText(String expected, String actual) throws IOException {
        if (actual.equalsIgnoreCase(expected)) {
            logPass(driver, "Expected: " + expected + " value is matching with Actual: " + actual);
        } else {
            logFail(driver, "Expected: " + expected + " value is not matching with Actual: " + actual);
        }
    }

    /**
     * To verify contains text
     * @author pgandhi
     * @param locator - By locator
     * @param data - Expected data
     */
    public void verifyContainsText(By locator, String data) throws IOException {
        WebElement element = null;
        try {
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            String actual = element.getText().trim();
            String expected = data.trim();
            if (actual.contains(expected)) {
                logPass(driver, "Expected: " + expected + " value is matching with Actual: " + actual);
            } else {
                logFail(driver, "Expected: " + expected + " value is not matching with Actual: " + actual);
                Assert.fail("Expected: " + expected + " value is not matching with Actual: " + actual);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
        }
    }

    public void verifyContainsText(WebElement element, String data) throws IOException {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            String actual = element.getText().trim();
            String expected = data.trim();
            if (actual.contains(expected)) {
                logPass(driver, "Expected: " + expected + " value is matching with Actual: " + actual);
            } else {
                logFail(driver, "Expected: " + expected + " value is not matching with Actual: " + actual);
                Assert.fail("Expected: " + expected + " value is not matching with Actual: " + actual);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
        }
    }

    /**
     * To fetch attributes from element
     * @author pgandhi
     * @param locator - By locator
     * @param attributeName - String Element attribute
     * @return string
     */
    public String fetchAttribute(By locator, String attributeName) throws IOException {
        WebElement element = null;
        try {
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            return element.getAttribute(attributeName).trim();
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
            return null;
        }
    }

    /**
     * To fetch text from element
     * @author pgandhi
     * @param locator - By locator
     * @return string
     */
    public String fetchText(By locator) throws IOException {
        WebElement element = null;
        try {
            scrollIntoView(locator);
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            return element.getText().trim();
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
            return null;
        }
    }

    /**
     * To fetch text from element
     * @author pgandhi
     * @param element - WebElement
     * @return string
     */
    public String fetchText(WebElement element) throws IOException {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            return element.getText().trim();
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
            return null;
        }
    }

    /**
     * To write text in element
     * @author pgandhi
     * @param element, expected
     */
    public void verifyAndEnterText(WebElement element, String expected) {
        try {
            String browser = jsonRead.readStringFromEnvironmentJSON("browser");
            if(browser.equalsIgnoreCase("IE")){
                //wait.until(ExpectedConditions.elementToBeClickable(element));
            }else{
                wait.until(ExpectedConditions.visibilityOf(element));
            }
           if (element.isDisplayed()) {
                highLighterMethod(element);
                element.clear();
                element.click();
                sleep(1);
                element.sendKeys(expected);
                ExtentManager.getTest().log(Status.PASS, "Enter text on " + element + " :" + expected);
                logPass(driver, "Enter text on " + element);
            }
        } catch (Exception e) {
            ExtentManager.getTest().log(Status.FAIL, "Failed to write on " + element.toString());
            Assert.fail("Fail to write on" + element);
        }
    }

    /**
     * To write text in element
     * @author pgandhi
     * @param locator, expected
     */
    public void verifyAndEnterText(By locator, String expected) {
        try {
            WebElement element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.clear();
                element.click();
                sleep(1);
                element.sendKeys(expected);
                ExtentManager.getTest().log(Status.PASS, "Enter text on " + locator.toString() + " :" + expected);
            }
        } catch (Exception e) {
            ExtentManager.getTest().log(Status.FAIL, "Failed to write on " + locator.toString());
        }
    }

    public void verifyAndEnterTextViaJavaScript(By locator, String expected) {
        try {
            WebElement element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
                // set the text
                jsExecutor.executeScript("arguments[0].value='"+expected+"'", element);
                logPass(driver,"Enter text on " + element + " :" + expected);
            }
        } catch (Exception e) {
            ExtentManager.getTest().log(Status.FAIL, "Failed to write on " + locator.toString());
            Assert.fail("Fail to write on" + locator);
        }
    }

    /**
     * wait for i no of seconds
     * @author pgandhi
     * @param i - no of seconds
     */
    protected void sleep(int i) throws InterruptedException {
        Thread.sleep(i * 1000);
    }

    /**
     * To click on element
     * @author pgandhi
     * @param element - WebElement
     */
    public void verifyAndClick(WebElement element) throws Throwable {
        try {
            scrollIntoView(element);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.click();
                logPass(driver, "Clicked on " + element);

            }
        } catch (WebDriverException e) {
            logFail(driver,"Fail to clicked on " + element);
        }
    }

    /**
     * To click on element
     * @author pgandhi
     * @param locator - By locator
     */
    public void verifyAndClick(By locator) throws Throwable {
        WebElement element;
        try {
            if(locator==null)
            {
                element = null;
            }else{
                element =driver.findElement(locator);
            }
            scrollIntoView(locator);
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.click();
                logPass(driver, "Clicked on " + element);
            }
        } catch (WebDriverException e) {
            logFail(driver,"Fail to clicked on " + locator.toString());
        }
    }

    /**
     * To click on element via JavaScript
     * @author pgandhi
     * @param locator, expected
     */
    public void verifyAndClickViaJavaScript(By locator) throws Throwable {
        WebElement element;
        if(locator==null)
        {
            element = null;
        }else{
            element =driver.findElement(locator);
        }
        try {
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                JavascriptExecutor executor = (JavascriptExecutor)driver;
                executor.executeScript("arguments[0].click();", element);
                logPass(driver, "Clicked on " + element+ " via javascript");
            }
        } catch (WebDriverException e) {
            logFail(driver,"Fail to clicked on " + element+ " via javascript");
        }
    }

    /**
     * To click on element via JavaScript
     * @author pgandhi
     * @param element
     */
    public void verifyAndClickViaJavaScript(WebElement element) throws Throwable {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                JavascriptExecutor executor = (JavascriptExecutor)driver;
                executor.executeScript("arguments[0].click();", element);
                logPass(driver, "Clicked on " + element+ " via javascript");
            }
        } catch (WebDriverException e) {
            logFail(driver,"Fail to clicked on " + element+ " via javascript");
        }
    }

    /**
     * To check page is proper  loaded via JavaScript
     * @author pgandhi
     */
    public void checkPageIsReady() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        //Initially bellow given if condition will check ready state of page.
        if (js.executeScript("return document.readyState").toString().equals("complete")) {
            System.out.println("Page Is loaded.");
        }
    }

    /**
     * To switch into new frame via frameName
     * @author pgandhi
     * @param frameName - New Frame name
     */
    public void changeFrameWithFrameName(String frameName) throws InterruptedException {
        sleep(15);
        try{
            driver.switchTo().frame(frameName);
            logPass("Driver is changed to frame: "+frameName);
        }catch (Exception e){
            logFail("Driver is not changed to frame: "+frameName);
 			Assert.fail("Fail to switch on iframe" + frameName);
        }
    }

    public void changeBackToParentFrame() throws InterruptedException {
        sleep(15);
        try{
            driver.switchTo().parentFrame();
            logPass("Driver is changed to parent frame");
        }catch (Exception e){
            logFail("Driver is not changed to parent frame");
        }
    }

    /**
     * To switch into new frame via WebElement
     * @author pgandhi
     * @param element - WebElement
     */
    public void changeFrameWithFrameName(WebElement element) throws InterruptedException {
        sleep(15);
        driver.switchTo().frame(element);
    }

    /**
     * To switch into new frame via index
     * @author pgandhi
     * @param number - Index number of frame
     */
    public void changeFrameWithIndex(int number) throws InterruptedException {
        sleep(15);
        driver.switchTo().frame(number);
    }

    /**
     * To highlight element
     * @author pgandhi
     * @param element - WebElement
     */
    public void highLighterMethod(WebElement element){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('style','border: 3px solid red;');", element);
        js.executeScript("arguments[0].setAttribute('style', arguments[1]);",element);
    }

    /**
     * To press EnterButton on element
     * @author pgandhi
     * @param locator - By locator
     */
    public void pressEnterButton(By locator) {
        try {
            WebElement element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.sendKeys(Keys.RETURN);
                ExtentManager.getTest().log(Status.PASS, "User is able to press enter for" + locator.toString());
            }
        } catch (Exception e) {
            ExtentManager.getTest().log(Status.FAIL, "User is not able to press enter for" + locator.toString());

        }
    }

    public void pressSpecialKeys(By locator,Keys specialkey) {
        try {
            WebElement element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.sendKeys(specialkey);
                ExtentManager.getTest().log(Status.PASS, "User is able to press backspace for" + locator.toString());
            }
        } catch (Exception e) {
            ExtentManager.getTest().log(Status.FAIL, "User is not able to press backspace for" + locator.toString());

        }
    }

    /**
     * To press EnterButton on element
     * @author pgandhi
     * @param element - WebElement
     */
    public void pressEnterButton(WebElement element) {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.sendKeys(Keys.RETURN);
                ExtentManager.getTest().log(Status.PASS, "User is able to press enter for" + element);
            }
        } catch (Exception e) {
            ExtentManager.getTest().log(Status.FAIL, "User is not able to press enter for" + element);

        }
    }

    /**
     * To check weather element is displayed or not
     * @author pgandhi
     * @param locator - By locator
     */
    public void isElementDisplayed(By locator) throws Throwable {
        WebElement element = null;
        try {
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                logPass(driver,element+" element is displayed");
            }
        } catch (WebDriverException e) {
            logFail(driver,element+" element is not displayed");
        }
    }

    public void isElementEnabled(By locator) throws Throwable {
        WebElement element = null;
        try {
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isEnabled()) {
                highLighterMethod(element);
                logPass(driver,element+" element is enabled");
            }
        } catch (WebDriverException e) {
            logFail(driver,element+" element is not enabled");
        }
    }

    public void isElementNotDisplayed(By locator) throws Throwable {
        sleep(10);
        List<WebElement> element = driver.findElements(locator);
        if (element.size()==0) {
            logPass(driver,element+" element is not displayed");
        }else{
            logFail(driver,element+" element is displayed");
        }
    }

    public void isElementDisplayed(WebElement element) throws Throwable {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                logPass(driver,element+" element is displayed");
            }
        } catch (WebDriverException e) {
            logFail(driver,element+" element is not displayed");
        }
    }

    /**
     * To hover on element
     * @author pgandhi
     * @param locator - By locator
     */
    public void mouseHoverToElement(By locator) throws IOException {
        WebElement element;
        {
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            highLighterMethod(element);
            Actions builder = new Actions(driver);
            builder.moveToElement(element).perform();
            logPass(driver,"Mouse has been hover to element");
        }
    }

    /**
     * To generate random string
     * @author pgandhi
     * @return  string
     */
    protected String getRandomStringString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 9) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        return salt.toString();
    }

    /**
     * To scroll till element
     * @author pgandhi
     * @param locator - By locator
     */
    public void scrollIntoView(By locator){
        WebElement element=driver.findElement(locator);
        // Javascript executor
        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    /**
     * To scroll till element
     * @author pgandhi
     * @param element - WebElement
     */
    public void scrollIntoView(WebElement element){
        // Javascript executor
        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    /**
     * To clear text from text box
     * @author pgandhi
     * @param element - WebElement
     */
    public void clearText(WebElement element) {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.clear();
                ExtentManager.getTest().log(Status.PASS, "Clear text on " + element);
            }
        } catch (Exception e) {
            ExtentManager.getTest().log(Status.FAIL, "Failed to clear text " + element);
        }
    }

    /**
     * To clear text from text box
     * @author pgandhi
     * @param locator - By locator
     */
    public void clearText(By locator) {
        WebElement element=driver.findElement(locator);
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.clear();
                ExtentManager.getTest().log(Status.PASS, "Clear text on " + element);
            }
        } catch (Exception e) {
            ExtentManager.getTest().log(Status.FAIL, "Failed to clear text " + element);
        }
    }

    /**
     * This method will wait until the folder is having any downloads
     * @author pgandhi
     * @throws InterruptedException
     */
    public void waitUntilFileToDownload() throws InterruptedException {
        File directory = new File(System.getProperty("user.home")+"\\Downloads");
        boolean downloadinFilePresence = false;
        File[] filesList =null;
        LOOP:
        while(true) {
            filesList =  directory.listFiles();
            for (File file : filesList) {
                downloadinFilePresence = file.getName().contains(".crdownload");
            }
            if(downloadinFilePresence) {
                for(;downloadinFilePresence;) {
                    sleep(5);
                    continue LOOP;
                }
            }else {
                break;
            }
        }
    }

    public boolean isFileDownloaded() throws IOException, InterruptedException {
        File dir = new File(System.getProperty("user.home")+"\\Downloads");
        File[] dirContents = dir.listFiles();
        sleep(5);
        for (int i = 0; i < dirContents.length; i++) {
            if (dirContents[i].getName().contains(".crdownload")) {
                // File has been found, it can now be deleted:
                sleep(10);
                dirContents[i].delete();
                return true;
            }
        }
        return false;
    }

    /**
     * to verify is File Downloaded In System
     *
     * @author smagdum
     */
    public boolean isFileDownloadedInSystem(String fileExtension) throws IOException, InterruptedException {
        File dir = new File(System.getProperty("user.home") + "\\Downloads");
        File[] dirContents = dir.listFiles();
        sleep(5);
        for (int i = 0; i < dirContents.length; i++) {
            if (dirContents[i].getName().contains(fileExtension)) {
                sleep(5);
                dirContents.toString().getBytes(StandardCharsets.UTF_8);
                dirContents[i].delete();
                return true;
            }
        }
        return false;
    }
    /**
     * To verify text(equalsIgnoreCase)
     * @author pgandhi
     * @param locator - By locator
     */
    public void verifyTextWithNonEmptyString(By locator) throws IOException {
        WebElement element = null;
        try {
            scrollIntoView(locator);
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            String actual = element.getText().trim();
            if (actual!= null && !actual.isEmpty()) {
                logPass(driver, "Value is matching with Actual: " + actual);
            } else {
                logFail(driver, "Value is not matching with Actual: " + actual);
                Assert.fail("Value is not matching with Actual: " + actual);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
        }
    }

    /**
     * to verify Text Field Is Non Empty
     *
     * @author smagdum
     */
    public void verifyTextFieldIsNonEmpty(By locator) throws IOException {
        WebElement element=null;
        try {
            scrollIntoView(locator);
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            String actual = element.getAttribute("value");
            if (actual !=null) {
                logPass(driver,"Some value is present");
            } else {
                logFail(driver, "Value is not present");
                Assert.fail("No value present for that field" );
            }
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " +element + " not found");
        }
    }

    public void refreshBrowser() throws InterruptedException {
        driver.navigate().refresh();
        sleep(15);
    }

    public void pressEnterButtonWithoutElement() throws AWTException, InterruptedException {
        sleep(2);
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_ENTER); //press enter key
        robot.keyRelease(KeyEvent.VK_ENTER); //release enter key
        sleep(2);
    }

    public void pressDownButtonWithoutElement() throws AWTException, InterruptedException {
        sleep(2);
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_DOWN); //press down key
        robot.keyRelease(KeyEvent.VK_DOWN); //release down key
        sleep(2);
    }

    public LocalDateTime stringToDateConvert(String dateInString){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE M/d/yyyy h:mm:ss a", Locale.ENGLISH);
        LocalDateTime date = LocalDateTime.parse(dateInString, formatter);
        return date;
    }


    public boolean verifyElementPresent(WebElement element) throws Throwable {
        try {
            scrollIntoView(element);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                logPass(driver, "Element present on " + element);
            }
            return true;
        } catch (WebDriverException e) {
            logFail(driver, "Element not present " + element);
            return false;
        }
    }


    public String fetchPageSource(){
        return driver.getPageSource();
    }

    public String fetchPageTitle(){ return driver.getTitle(); }

    public String fetchCSSValue(By locator, String cssProperty) throws IOException {
        WebElement element = null;
        try {
            scrollIntoView(locator);
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            return element.getCssValue(cssProperty);
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
            return null;
        }
    }

    /**
     * Fetch text for specific attribute
     *
     * @param element, expected
     * @author smagdum
     */
    public String fetchTextWithSpecificAttribute(WebElement element, String attribute) throws IOException {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            highLighterMethod(element);
            return element.getAttribute(attribute).trim();
        } catch (Exception e) {
            e.printStackTrace();
            logFail(driver, "Element: " + element + " not found");
            Assert.fail("Element: " + element + " not found");
            return null;
        }
    }

    /**
     * To Click For Child Window
     *
     * @param locator, expected
     * @author smagdum
     */
    public void verifyAndClickForChildWindow(By locator) throws Throwable {
        WebElement element;
        if (locator == null) {
            element = null;
        } else {
            element = driver.findElement(locator);
        }
        try {
            scrollIntoView(locator);
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                highLighterMethod(element);
                element.click();
                logPass("Clicked on " + locator.toString());
            }
        } catch (WebDriverException e) {
            logFail(driver, "Fail to clicked on " + element);
        }
    }


    /**
     * To select Element From Dropdown
     *
     * @param locator, expected
     * @author smagdum
     */
    public void selectElementFromDropdown(By locator, String expected) throws Throwable {
        try {
            WebElement element;
            if (locator == null) {
                element = null;
            } else {
                element = driver.findElement(locator);
            }
            scrollIntoView(locator);
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            Select dropDownObj = new Select(element);
            dropDownObj.selectByVisibleText(expected);
            logPass(driver, "Selected from dropdown " + element);
        } catch (WebDriverException e) {
            logFail(driver, "Fail to select from dropdown " + locator);
        }
    }

    /**
     * To switch To Default Frame
     *
     * @author smagdum
     */
    public void switchToDefaultFrame() throws InterruptedException {
        sleep(5);
        try {
            driver.switchTo().defaultContent();
            logPass("Driver is switch to defaultFrame");
        } catch (Exception e) {
            logFail("Fail to switch on default frame: ");
            Assert.fail("Fail to switch on default frame");
        }
    }

    public void switchToDefaultWindow() throws InterruptedException {
        sleep(8);
        driver.switchTo().window(parentWindow);
    }


    /**
     * Maximize window
     *
     * @author smagdum
     */
    public void maximizeWindow() throws InterruptedException {
        sleep(2);
        driver.manage().window().maximize();
    }

    /**
     * To get all windows titles
     *
     * @author smagdum
     */
    public Set<String> getAllWindowTitles() throws InterruptedException {
        sleep(2);
        Set<String> allWindowHandles = driver.getWindowHandles();
        return allWindowHandles;
    }


    /**
     * To get current window title
     *
     * @author smagdum
     */
    public String getCurrentWindowTitle() throws InterruptedException {
        sleep(2);
        String currentWindow = driver.getWindowHandle();
        return currentWindow;
    }

    /**
     * To get current page title
     *
     * @author smagdum
     */
    public void getPageTitle(String expectedPageTitle) throws Throwable {
        sleep(2);
        try {
            wait.until(ExpectedConditions.titleContains(expectedPageTitle));
            sleep(2);
            String pageTitle = driver.getTitle();
            assertEquals(pageTitle, expectedPageTitle, "User failed to lands on page of title" + pageTitle);
            logPass(driver, "User landed on page of title" + pageTitle);
        } catch (Exception e) {
            logFail(driver, "User failed to lands on expected page");
            ;
        }
    }

    /**
     * To get current page url
     *
     * @author smagdum
     */
    public void getCurrentURL(String expectedURL) throws Throwable {
        sleep(2);
        try {
            wait.until(ExpectedConditions.titleContains(expectedURL));
            sleep(2);
            String currentUrl = driver.getCurrentUrl();
            //assertTrue(pageTitle.contentEquals(expectedPageTitle));
            assertEquals(currentUrl, expectedURL, "User failed to open expected URL" + currentUrl);
            logPass(driver, "Successfully opened the URL" + currentUrl);
        } catch (Exception e) {
            logFail(driver, "Failed to open expected URL");
            ;
        }
    }

    /**
     * To verify page title
     *
     * @author smagdum
     */
    public boolean verifyPageTitle(String expectedPageTitle) throws Throwable {
        sleep(2);
        try {
            wait.until(ExpectedConditions.titleContains(expectedPageTitle));
            sleep(2);
            String pageTitle = driver.getTitle();
            assertTrue(pageTitle.contentEquals(expectedPageTitle));
            logPass(driver, "User landed on page of title" + pageTitle);
            return true;
        } catch (Exception e) {
        }
        return false;
    }


    public void waitUntilFileToDownloadInSystem(String fileExtension) throws InterruptedException {
        File directory = new File(System.getProperty("user.home") + "\\Downloads");
        boolean downloadinFilePresence = false;
        File[] filesList = null;
        LOOP:
        while (true) {
            filesList = directory.listFiles();
            for (File file : filesList) {
                downloadinFilePresence = file.getName().contains(fileExtension);
            }
            if (downloadinFilePresence) {
                for (; downloadinFilePresence; ) {
                    sleep(5);
                    continue LOOP;
                }
            } else {
                break;
            }
        }
    }

    /**
     * is Element Displayed And Enabled
     *
     * @author smagdum
     */
    public void isElementDisplayedAndEnabled(By locator) throws Throwable {
        WebElement element = null;
        try {
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed() && element.isEnabled()) {
                highLighterMethod(element);
                logPass(driver, element + " element is displayed and enabled");
            }
        } catch (WebDriverException e) {
            logFail(driver, element + " element is not displayed or not enabled");
        }
    }

    /**
     * verify element present
     * returns true/false
     * @author smagdum
     */
    public boolean verifyElementPresent(By locator) throws Throwable {
        WebElement element = null;
        try {
            scrollIntoView(locator);
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
            element = driver.findElement(locator);
            if (element.isDisplayed()) {
                highLighterMethod(element);
                logPass(driver, "Element present on " + element);
            }
            return true;
        } catch (WebDriverException e) {
            logFail(driver, "Element not present " + element);
            return false;
        }
    }


    /**
     * To switch to new window or tab.
     *
     * @author smagdum
     */
    public void switchToNewWindow() throws Throwable {
        try {
            parentWindow = driver.getWindowHandle();
            allWindow = driver.getWindowHandles();
            int numberOfWindows = allWindow.size();
            for (String childWindow : allWindow) {
                if (!parentWindow.equalsIgnoreCase(childWindow)) {
                    driver.switchTo().window(childWindow);
                }
            }
            logPass(driver, "Driver switch to new window");
        } catch (Exception e) {
            logFail(driver, "Driver failed to switch to new window");
        }
    }

    /**
     * verify switch to new window or not
     * returns true/false
     * @author smagdum
     */
    public boolean verifySwitchToNewWindowOrNot() throws Throwable {
        try {
            parentWindow = driver.getWindowHandle();
            allWindow = driver.getWindowHandles();
            int numberOfWindows = allWindow.size();
            for (String childWindow : allWindow) {
                if (!parentWindow.equalsIgnoreCase(childWindow)) {
                    driver.switchTo().window(childWindow);
                }
            }
            logPass(driver, "Driver switch to new window");
            return true;
        } catch (Exception e) {
            logFail(driver, "Driver failed to switch to new window");
            return false;
        }
    }

    /**
     * To switch And Accept the Alert pop up
     * @author smagdum
     */
    public void switchAndAcceptAlert() throws Throwable {
        try {
            Alert alert = driver.switchTo().alert();
            String alertMessage = driver.switchTo().alert().getText();
            logInfo(alertMessage);
            alert.accept();
            logPass(driver, "Driver switch to alert pop up and accept");
        } catch (Exception e) {
            logFail(driver, "Driver failed to switch to alert pop up");
        }
    }

    /**
     * To verify Alert pop up present or not
     * @author smagdum
     */
    public boolean verifyAlertPopUpPresent() throws Throwable {
        try {
            Alert alert = driver.switchTo().alert();
            String alertMessage = driver.switchTo().alert().getText();
            logInfo(alertMessage);
            logPass(driver, "AlertPopUpPresent");
            return true;
        } catch (Exception e) {
            logFail(driver, "AlertPopUpPresent");
            return false;
        }
    }

    /**
     * To switch And Close Alert pop up
     * @author smagdum
     */
    public void switchAndCloseAlert() throws Throwable {
        try {
            Alert alert = driver.switchTo().alert();
            String alertMessage = driver.switchTo().alert().getText();
            logInfo(alertMessage);
            alert.dismiss();
            logPass(driver, "Update Failed - The step deadline has already passed and therefore cannot be changed");
        } catch (Exception e) {
            logFail(driver, "Driver failed to switch to alert pop up");
        }
    }


}
