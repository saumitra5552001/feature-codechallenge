package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.StepDefinition.CommonSteps;
import com.surveilx.qa.StepDefinition.LoginSteps;
import com.surveilx.qa.StepDefinition.NavigationSteps;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;
import java.util.List;

public class AuditHistoryPageObjects extends CommonFunctions {

    public AuditHistoryPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    LoginSteps loginsteps = new LoginSteps();
    NavigationSteps navigation = new NavigationSteps();
    CommonSteps commonSteps = new CommonSteps();

    public enum AuditHistory {
        titleAuditTrail(By.id("audittrailTitle")),
        headingDateTime(By.xpath("//a[text()='Date & time']")),
        headingTimezone(By.xpath("//a[text()='Timezone']")),
        headingUser(By.xpath("//a[text()='User']")),
        headingCluster(By.xpath("//a[text()='Cluster']")),
        headingEntityType(By.xpath("//a[text()='Entity Type']")),
        headingEntityId(By.xpath("//a[text()='Entity Id']")),
        headingAction(By.xpath("//a[text()='Action']")),
        headingHost(By.xpath("//a[text()='Host']")),
        headingSection(By.xpath("//a[text()='Section']")),
        headingMessage(By.xpath("//a[text()='Message']")),
        buttonExportToCSV(By.xpath("//input[@title='Export to CSV']")),
        buttonFirstPage(By.xpath("//input[@title='First Page']")),
        buttonPreviousPage(By.xpath("//input[@title='Previous Page']")),
        buttonNextPage(By.xpath("//input[@title='Next Page']")),
        buttonLastPage(By.xpath("//input[@title='Last Page']")),
        labelPagesize(By.xpath("//span[text()='Page size:']")),
        msgStatusTime(By.id("statusTime")),
        msgStatusText(By.id("statusText")),
        log1forDate(By.xpath("((//div[contains(@id,'rgAuditTrail')])[7]/table/tbody/tr/td[1])[1]")),
        log1forTimezone(By.xpath("((//div[contains(@id,'rgAuditTrail')])[7]/table/tbody/tr/td[2])[1]")),
        log1forUser(By.xpath("((//div[contains(@id,'rgAuditTrail')])[7]/table/tbody/tr/td[3])[1]")),
        log1forAction(By.xpath("((//div[contains(@id,'rgAuditTrail')])[7]/table/tbody/tr/td[7])[1]")),
        log1forHost(By.xpath("((//div[contains(@id,'rgAuditTrail')])[7]/table/tbody/tr/td[8])[1]")),
        log1forSection(By.xpath("((//div[contains(@id,'rgAuditTrail')])[7]/table/tbody/tr/td[9])[1]")),
        log1forMessage(By.xpath("((//div[contains(@id,'rgAuditTrail')])[7]/table/tbody/tr/td[10])[1]")),
        ;
        public By findBy;

        AuditHistory(By locator) {
            this.findBy = locator;
        }
    }

    public By valueXpath(String s) {
        return By.xpath("//*[text()='" + s + "']");
    }

    public By spanXpath(String s) {
        return By.xpath("//span[text()='" + s + "']");
    }

    public By divXpath(String s) {  return By.xpath("//div[text()='" + s + "']");}

    public By divContainsTextXpath(String s){ return By.xpath("//div[contains(text(),'"+s+"')]");}

    public By liContainsTextXpath(String s){ return By.xpath("//li[contains(text(),'"+s+"')]");}

    @FindBy(xpath="//div[@class='apf-explore-interaction-content-text']")
    List<WebElement> listInteraction;

    public void iValidateUIofAuditHistoryPage() throws Throwable {
        verifyText(AuditHistory.titleAuditTrail.findBy,"Audit Trail");
        changeFrameWithFrameName("frameContainer");
        isElementDisplayed(AuditHistory.buttonExportToCSV.findBy);
        verifyText(AuditHistory.headingDateTime.findBy,"Date & time");
        verifyText(AuditHistory.headingTimezone.findBy,"Timezone");
        verifyText(AuditHistory.headingUser.findBy,"User");
        verifyText(AuditHistory.headingCluster.findBy,"Cluster");
        verifyText(AuditHistory.headingEntityType.findBy,"Entity Type");
        verifyText(AuditHistory.headingEntityId.findBy,"Entity Id");
        verifyText(AuditHistory.headingAction.findBy,"Action");
        verifyText(AuditHistory.headingHost.findBy,"Host");
        verifyText(AuditHistory.headingSection.findBy,"Section");
        verifyText(AuditHistory.headingMessage.findBy,"Message");
        isElementDisplayed(AuditHistory.buttonFirstPage.findBy);
        isElementDisplayed(AuditHistory.buttonPreviousPage.findBy);
        isElementDisplayed(AuditHistory.buttonNextPage.findBy);
        isElementDisplayed(AuditHistory.buttonLastPage.findBy);
        verifyText(AuditHistory.labelPagesize.findBy,"Page size:");
        verifyTextWithNonEmptyString(AuditHistory.msgStatusTime.findBy);
        verifyTextWithNonEmptyString(AuditHistory.msgStatusText.findBy);
    }

    public void generalValidation() throws InterruptedException, IOException {
        changeFrameWithFrameName("frameContainer");
        verifyTextWithNonEmptyString(AuditHistory.log1forDate.findBy);
        verifyText(AuditHistory.log1forTimezone.findBy,"GMT +01:00");
        verifyText(AuditHistory.log1forUser.findBy,"admin");
        //verifyContainsText(AuditHistory.log1forHost.findBy, InetAddress.getLocalHost().toString());
    }

    public void checkLogsForExploreFilterFunctionality() throws IOException, InterruptedException {
        generalValidation();
        verifyText(AuditHistory.log1forAction.findBy,"FindInteractions");
        verifyText(AuditHistory.log1forSection.findBy,"QueryComponent");
        verifyText(AuditHistory.log1forMessage.findBy,"Find interaction. Text: Facets: Type: Email");
    }

    public void checkLogsForExploreOpenInteractionFunctionality() throws IOException, InterruptedException {
        generalValidation();
        verifyText(AuditHistory.log1forAction.findBy,"RetrieveInteractionDetails");
        verifyText(AuditHistory.log1forSection.findBy,"QueryComponent");
        verifyText(AuditHistory.log1forMessage.findBy,"Retrieve interaction details.");
    }

    public void checkLogsForExploreDownloadResultMetadataFunctionality() throws IOException, InterruptedException {
        generalValidation();
        verifyText(AuditHistory.log1forAction.findBy,"Download");
        verifyText(AuditHistory.log1forSection.findBy,"Nice.ApplicationPlugins.Explorer.Plugin");
        verifyText(AuditHistory.log1forMessage.findBy,"Meta data downloaded");
    }

    public void checkLogsForExploreSaveSearchFunctionality() throws IOException, InterruptedException {
        generalValidation();
        verifyText(AuditHistory.log1forAction.findBy,"Create");
        verifyText(AuditHistory.log1forSection.findBy,"SearchComponent");
        verifyContainsText(AuditHistory.log1forMessage.findBy,"Saved search");
    }

    public void checkLogsForExploreDefaultSearchFunctionality() throws IOException, InterruptedException {
        generalValidation();
        verifyText(AuditHistory.log1forAction.findBy,"Default");
        verifyText(AuditHistory.log1forSection.findBy,"SearchComponent");
        verifyContainsText(AuditHistory.log1forMessage.findBy,"Defaulted search");
    }

    public void checkLogsForExploreDeleteSearchFunctionality() throws IOException, InterruptedException {
        generalValidation();
        verifyText(AuditHistory.log1forAction.findBy,"Delete");
        verifyText(AuditHistory.log1forSection.findBy,"SearchComponent");
        verifyContainsText(AuditHistory.log1forMessage.findBy,"Delete search");
    }

    public void checkLogsForLoginFunctionality() throws IOException, InterruptedException {
        generalValidation();
        verifyText(AuditHistory.log1forAction.findBy,"Logon");
        verifyText(AuditHistory.log1forSection.findBy,"UserManagerWrapperComponent");
        verifyContainsText(AuditHistory.log1forMessage.findBy,"Logon user 'admin' to Application Framework");
    }

}