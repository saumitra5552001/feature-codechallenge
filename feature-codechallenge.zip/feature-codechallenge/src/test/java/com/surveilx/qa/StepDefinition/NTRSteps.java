package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.NTRPageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class NTRSteps extends CommonFunctions {

    NTRPageObjects ntrpom = new NTRPageObjects(driver);

    @And("I verify NICE Trading Recording Page UI$")
    public void iVerifyNICETradingRecordingPageUI() throws Throwable {
        ntrpom.iValidateNICETradingRecordingPageUI();
    }

    @And("I add NTR$")
    public void iAddNTR() throws Throwable {
        ntrpom.iAddNTR();
    }


}
