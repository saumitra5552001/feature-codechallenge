package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import jdk.nashorn.internal.ir.Labels;
import org.apache.poi.sl.usermodel.ConnectorShape;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.IDynamicGraph;

import javax.print.attribute.standard.JobSheets;
import javax.security.auth.login.Configuration;
import java.awt.*;
import java.io.IOException;
import java.util.List;
import java.util.Set;

public class NavigationPageObjects extends CommonFunctions {

    public NavigationPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private enum Navigation {
        buttonRCMSideBarMenu(By.xpath("//div[@id='rcmSideBarMenu']/div")),
        buttonNavBar(By.xpath("//div[@class='navbar']/a")),
        labelWorkBench(By.xpath("//span[text()='Workbench']")),
        labelWorkItems(By.xpath("//a[text()='Work Items']")),
		labelWorkItemViews(By.xpath("//a[text()='Work Item Views']")),
        labelScenarioItems(By.xpath("//a[text()='Scenario Items']")),
        labelCommunicationPolicies(By.xpath("//span[text()='Communication Policies']")),
        labelPolicyManager(By.xpath("//span[text()='Policy Manager']")),
        labelObservePolicies(By.xpath("//a[text()='Observe Policies']")),
        labelReviewSelection(By.xpath("//a[text()='Review Selection']")),
        labelQueueManager(By.xpath("//a[text()='Queue Manager']")),
        labelAuditHistory(By.xpath("//a[text()='Audit History']")),
        labelSettings(By.xpath("//span[text()='Settings']")),
        labelThresholds(By.xpath("//a[text()='Thresholds']")),
        labelReferences(By.xpath("//a[text()='References']")),
        labelDisclaimerManager(By.xpath("//a[text()='Disclaimer Manager']")),
        labelSettingsNavigator(By.xpath("//a[text()='Settings Navigator']")),
        labelPlatformLists(By.xpath("//a[text()='Platform Lists']")),
        labelEntityManagement(By.xpath("//a[text()='Entity Management']")),
        labelNexidiaSearchGrid(By.xpath("//a[text()='Nexidia Search Grid']")),
        labelFieldConfiguration(By.xpath("//a[text()='Field Configuration']")),
        labelViewAssignment(By.xpath("//a[text()='View Assignment']")),
        labelLabels(By.xpath("//a[text()='Labels']")),
        labelGlobalSettings(By.xpath("//a[text()='Global Settings']")),
        labelReportDelivery(By.xpath("//a[text()='Report Delivery']")),
        labelAudioPlayer(By.xpath("//a[text()='Audio Player']")),
        labelScenarioConfiguration(By.xpath("//a[text()='Scenario Configuration']")),
        labelSmartIndexConfiguration(By.xpath("//a[text()='Smart Index Configuration']")),
        labelNTRClustersAdministrations(By.xpath("//a[text()='NTR Clusters Administration']")),
        labelNTRClustersStatus(By.xpath("//a[text()='NTR Clusters Status']")),
        labelReportingConfigurations(By.xpath("//a[text()='Reporting Configuration']")),
        labelDashboards(By.xpath("//span[text()='Dashboards']")),
        labelCommunicationAnalytics(By.xpath("//a[text()='Communication Analytics']")),
        labelCases(By.xpath("//span[text()='Cases']")),
        labelResearch(By.xpath("//span[text()='Research']")),
        labelOnDemandReports(By.xpath("//a[text()='On-Demand Reports']")),
        labelExplore(By.xpath("//a[text()='Explore']")),
        labelMonitoring(By.xpath("//span[text()='Monitoring']")),
        labelTranscriptionQueue(By.xpath("//a[text()='Transcription Queue']")),
        labelAlarms(By.xpath("//a[text()='Alarms']")),
        labelConnectors(By.xpath("//span[text()='Connectors']")),
        labelJob(By.xpath("//a[text()='Jobs']")),
        labelLegacyNTRConnector(By.xpath("//a[text()='Legacy NTR Connector']")),
        labelNetworkVoiceConnector(By.xpath("//a[text()='Network Voice Connector']")),
        labelNICETradingRecording(By.xpath("//a[text()='NICE Trading Recording']")),
        labelNIMConnector(By.xpath("//a[text()='NIM Connector']")),
        labelDoItYourself(By.xpath("//span[contains(text(),'Do it Yourself')]")),

        labelWorkItem(By.xpath("//a[text()='Work Items']")),
        labelDart(By.xpath("//a[text()='DART']")),
        toggleButton (By.xpath(".//div[@id='tab-names-toggle-btn']")),
        analyticsTab (By.xpath(".//span[@id='Analytics_0']")),
        transactionTab(By.xpath(".//span[@id='Transactions_1']")),
        expansionIconForAnalyticsTab (By.xpath("(.//toggle-dropdown[@class='ng-scope']/md-icon)[1]")),
        expansionIconForTransactionTab (By.xpath("(.//toggle-dropdown[@class='ng-scope']/md-icon)[2]")),
        fullScreenUnderItemDetails (By.xpath("((.//span[@class='ng-scope'])/span)[1]")),
        detachAsNewTabUnderItemDetails (By.xpath("((.//span[@class='ng-scope'])/span)[2]")),
        fullScreenUnderItemDetailsTransactionTab (By.xpath("(.//span[@class='ng-scope']/span)[3]")),
        detachAsNewTabUnderItemDetailsTransactionTab (By.xpath("(.//span[@class='ng-scope']/span)[4]")),
        refreshIcon (By.xpath(".//i[@id='icon_refresh']")),
        transactionsOfRelatedProductsTab (By.xpath("(.//div[@id='TransactionsofRelatedProducts_1'])[1]")),
        advancedFilterIcon (By.xpath(".//i[@id='icon_advancedFilter']")),
        advancedFilterOption (By.xpath("(.//a[@id='icon_print_list_a'])[2]")),
        alertNameTextBox (By.xpath(".//input[@id='rcmAlertName_valuesField']")),
        goButtonOnAdvancedFilter (By.xpath(".//td[@id='textButton__SubmitButton']")),

        ;
        private By findBy;

        Navigation(By locator) {
            this.findBy = locator;
        }
    }

    public By valueXpath(String s) {
        return By.xpath("//*[text()='" + s + "']");
    }

    @FindBy(xpath = "(//span[contains(text(),'Search')])[2]")
    WebElement labelSearch;

    @FindBy(id ="closeDescriptionPane")
    WebElement imageCloseDisplayPan;

    @FindBy(xpath = "//span[text()='Review Queues']")
    WebElement labelReviewQueues;

    @FindBy(id="icon_refresh")
    WebElement imageRefreshIcon;

    @FindBy(id="widgetlibrary-cogwheel")
    WebElement cogWheel;

    @FindBy(id="errorMessage")
    WebElement msgYouAreNotAuthorized;

    @FindBy(xpath="//div[contains(text(),'On-Demand Reports')]")
    WebElement labelOnDemandReports;

    @FindBy(id="apf-explore-download-set-icon")
    WebElement labelDownload;

    public void validateDefaultRCMSideBarMenuDisplayStatus() throws Throwable {
        if(fetchAttribute(Navigation.buttonRCMSideBarMenu.findBy, "class").contains("collapse")){
            logPass(driver,"RCM Side bar is collapsed by default");
        }else{
            logFail(driver,"RCM Side bar is not collapsed by default");
        }
        verifyAndClick(Navigation.buttonNavBar.findBy);
        if(fetchAttribute(Navigation.buttonRCMSideBarMenu.findBy, "class").contains("expand")){
            logPass(driver,"RCM Side bar is expanded");
        }else{
            logFail(driver,"RCM Side bar is not expanded");
        }
    }

    public void clickOnNavBar() throws Throwable {
        sleep(10);
        verifyAndClick(Navigation.buttonNavBar.findBy);
    }

    public void clickOnWorkBenchTileAndValidateItsName() throws Throwable {
        sleep(15);
        verifyAndClick(Navigation.labelWorkBench.findBy);
    }

    public void clickOnWorkBenchTitleAndValidateItsName() throws Throwable {
        sleep(4);
        verifyAndClick(Navigation.labelWorkBench.findBy);
    }

    public void clickOnResearchTitleAndValidateItsName() throws Throwable {
        sleep(4);
        verifyAndClick(Navigation.labelResearch.findBy);
    }

    public void clickOnSettingsTitleAndValidateItsName() throws Throwable {
        sleep(4);
        verifyAndClick(Navigation.labelSettings.findBy);
    }

    public void clickOnWorkItemViewsTileAndValidateItsName() throws Throwable {
        sleep(15);
        verifyText(Navigation.labelWorkItems.findBy,"Work Items");
        verifyAndClick(Navigation.labelWorkItems.findBy);
        isElementDisplayed(imageRefreshIcon);
    }

    public void clickOnWorkItemTitleAndValidateItsName() throws Throwable {
        sleep(5);
        verifyText(Navigation.labelWorkItem.findBy,"Work Items");
        verifyAndClick(Navigation.labelWorkItem.findBy);
        isElementDisplayed(imageRefreshIcon);
    }

    public void clicksOnDARTAndValidateItsName() throws Throwable {
        sleep(5);
        verifyText(Navigation.labelDart.findBy,"DART");
        verifyAndClick(Navigation.labelDart.findBy);
        isElementDisplayed(imageRefreshIcon);
    }

    public void clicksOnSettingsNavigatorAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelSettingsNavigator.findBy,"Settings Navigator");
        verifyAndClick(Navigation.labelSettingsNavigator.findBy);
        sleep(2);
        isElementDisplayed(imageRefreshIcon);
    }


    public void clickOnScenarioItemsTileAndValidateItsName() throws Throwable {
        sleep(10);
        verifyText(Navigation.labelScenarioItems.findBy,"Scenario Items");
        verifyAndClick(Navigation.labelScenarioItems.findBy);
        sleep(30);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(labelSearch);
    }

    public void clickOnCommunicationPolicyTileAndValidateItsName() throws Throwable {
        verifyAndClick(Navigation.labelPolicyManager.findBy);
    }

    public void clickOnObservePoliciesTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelObservePolicies.findBy,"Observe Policies");
        verifyAndClick(Navigation.labelObservePolicies.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnReviewSelectionTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelReviewSelection.findBy,"Review Selection");
        verifyAndClick(Navigation.labelReviewSelection.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnQueueManagerTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelQueueManager.findBy,"Queue Manager");
        verifyAndClick(Navigation.labelQueueManager.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(labelReviewQueues);
    }

    public void clickOnAuditHistoryTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelAuditHistory.findBy,"Audit History");
        verifyAndClick(Navigation.labelAuditHistory.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnSettingsTileAndValidateItsName() throws Throwable {
        verifyAndClick(Navigation.labelSettings.findBy);
    }
    public void clickOnThresholdsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelThresholds.findBy,"Thresholds");
        verifyAndClick(Navigation.labelThresholds.findBy);
        sleep(10);
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnReferencesTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelReferences.findBy,"References");
        verifyAndClick(Navigation.labelReferences.findBy);
        sleep(10);
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnListsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelReferences.findBy,"Lists");
        verifyAndClick(Navigation.labelReferences.findBy);
        sleep(10);
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnDisclaimerManagerTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelDisclaimerManager.findBy,"Disclaimer Manager");
        verifyAndClick(Navigation.labelDisclaimerManager.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnSettingsNavigatorTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelSettingsNavigator.findBy,"Settings Navigator");
        verifyAndClick(Navigation.labelSettingsNavigator.findBy);
        sleep(10);
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnPlatformListsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelPlatformLists.findBy,"Platform Lists");
        verifyAndClick(Navigation.labelPlatformLists.findBy);
        sleep(10);
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnEntityManagementTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelEntityManagement.findBy,"Entity Management");
        verifyAndClick(Navigation.labelEntityManagement.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnNexidiaSearchGridTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelNexidiaSearchGrid.findBy,"Nexidia Search Grid");
        verifyAndClick(Navigation.labelNexidiaSearchGrid.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnFieldConfigurationTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelFieldConfiguration.findBy,"Field Configuration");
        verifyAndClick(Navigation.labelFieldConfiguration.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnViewAssignmentTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelViewAssignment.findBy,"View Assignment");
        verifyAndClick(Navigation.labelViewAssignment.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnLabelsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelLabels.findBy,"Labels");
        verifyAndClick(Navigation.labelLabels.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnGlobalSettingsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelGlobalSettings.findBy,"Global Settings");
        verifyAndClick(Navigation.labelGlobalSettings.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnReportDeliveryTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelReportDelivery.findBy,"Report Delivery");
        verifyAndClick(Navigation.labelReportDelivery.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnAudioPlayerTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelAudioPlayer.findBy, "Audio Player");
        verifyAndClick(Navigation.labelAudioPlayer.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnScenarioConfigurationTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelScenarioConfiguration.findBy,"Scenario Configuration");
        verifyAndClick(Navigation.labelScenarioConfiguration.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnSmartIndexConfigurationTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelSmartIndexConfiguration.findBy,"Smart Index Configuration");
        verifyAndClick(Navigation.labelSmartIndexConfiguration.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnNTRClustersAdministrationsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelNTRClustersAdministrations.findBy,"NTR Clusters Administration");
        verifyAndClick(Navigation.labelNTRClustersAdministrations.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnNTRClustersStatusTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelNTRClustersStatus.findBy,"NTR Clusters Status");
        verifyAndClick(Navigation.labelNTRClustersStatus.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }
    public void clickOnReportingConfigurationsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelReportingConfigurations.findBy,"Reporting Configuration");
        verifyAndClick(Navigation.labelReportingConfigurations.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnDashboardsTileAndValidateItsName() throws Throwable {
        verifyAndClick(Navigation.labelDashboards.findBy);
    }

    public void clickOnCommunicationAnalyticsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelCommunicationAnalytics.findBy,"Communication Analytics");
        verifyAndClick(Navigation.labelCommunicationAnalytics.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(cogWheel);
    }

    public void clickOnCasesTileAndValidateItsName() throws Throwable {
        verifyAndClick(Navigation.labelCases.findBy);
        isElementDisplayed(imageRefreshIcon);
    }

    public void clickOnResearchTileAndValidateItsName() throws Throwable {
        verifyAndClick(Navigation.labelResearch.findBy);
    }

    public void clickOnOnDemandReportsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelOnDemandReports.findBy,"On-Demand Reports");
        verifyAndClick(Navigation.labelOnDemandReports.findBy);
        isElementDisplayed(labelOnDemandReports);
    }

    public void clickOnExploreTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelExplore.findBy,"Explore");
        verifyAndClick(Navigation.labelExplore.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(labelDownload);
    }

    public void clickOnMonitoringTileAndValidateItsName() throws Throwable {
        verifyAndClick(Navigation.labelMonitoring.findBy);
    }

    public void clickOnTranscriptionQueueTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelTranscriptionQueue.findBy,"Transcription Queue");
        verifyAndClick(Navigation.labelTranscriptionQueue.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnAlarmsTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelAlarms.findBy,"Alarms");
        verifyAndClick(Navigation.labelAlarms.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnConnectorsTileAndValidateItsName() throws Throwable {
        verifyAndClick(Navigation.labelConnectors.findBy);
    }

    public void clickOnJobTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelJob.findBy,"Jobs");
        verifyAndClick(Navigation.labelJob.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(msgYouAreNotAuthorized);
    }

    public void clickOnLegacyNTRConnectorTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelLegacyNTRConnector.findBy,"Legacy NTR Connector");
        verifyAndClick(Navigation.labelLegacyNTRConnector.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnNetworkVoiceConnectorTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelNetworkVoiceConnector.findBy,"Network Voice Connector");
        verifyAndClick(Navigation.labelNetworkVoiceConnector.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnNICETradingRecordingTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelNICETradingRecording.findBy,"NICE Trading Recording");
        verifyAndClick(Navigation.labelNICETradingRecording.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(imageCloseDisplayPan);
    }

    public void clickOnNIMConnectorTileAndValidateItsName() throws Throwable {
        verifyText(Navigation.labelNIMConnector.findBy,"NIM Connector");
        verifyAndClick(Navigation.labelNIMConnector.findBy);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(msgYouAreNotAuthorized);
    }

    public void verifySideBarMenuName() throws IOException {
        verifyText(Navigation.labelWorkBench.findBy,"Workbench");
        verifyText(Navigation.labelCommunicationPolicies.findBy,"Communication Policies");
        verifyText(Navigation.labelSettings.findBy,"Settings");
        verifyText(Navigation.labelDashboards.findBy,"Dashboards");
        verifyText(Navigation.labelCases.findBy,"Cases");
        verifyText(Navigation.labelResearch.findBy,"Research");
        verifyText(Navigation.labelMonitoring.findBy,"Monitoring");
        verifyText(Navigation.labelConnectors.findBy,"Connectors");
        verifyText(Navigation.labelDoItYourself.findBy,"Do it Yourself");
    }

    public void verifySideBarMenuName_MSC() throws IOException {
        verifyText(Navigation.labelDashboards.findBy,"Dashboards");
    }

    public void clickOnToggleButtonUnderItemDetails() throws Throwable {
        verifyAndClick(Navigation.toggleButton.findBy);
    }

    public void clickOnAnalyticsTabUnderItemDetails() throws Throwable {
        verifyAndClick(Navigation.analyticsTab.findBy);
    }

    public void clickOnTransactionTabUnderItemDetails() throws Throwable {
        verifyAndClick(Navigation.transactionTab.findBy);
    }

    public void clickOnTransactionsOfRelatedProductsTab() throws Throwable {
        verifyAndClick(Navigation.transactionsOfRelatedProductsTab.findBy);
    }

    public void fullScreenUnderItemDetails() throws Throwable {
        verifyAndClick(Navigation.expansionIconForAnalyticsTab.findBy);
        sleep(2);
        verifyAndClick(Navigation.fullScreenUnderItemDetails.findBy);
    }

    public void fullScreenUnderItemDetailsTransactionTab() throws Throwable {
        verifyAndClick(Navigation.expansionIconForTransactionTab.findBy);
        sleep(2);
        verifyAndClick(Navigation.fullScreenUnderItemDetailsTransactionTab.findBy);
    }

    public void detachAsANewTabUnderItemDetails() throws Throwable {
        verifyAndClick(Navigation.expansionIconForAnalyticsTab.findBy);
        sleep(2);
        verifyAndClick(Navigation.detachAsNewTabUnderItemDetails.findBy);
        switchToNewWindow();
    }

    public void detachAsNewTabUnderItemDetailsTransactionTab() throws Throwable {
        verifyAndClick(Navigation.expansionIconForTransactionTab.findBy);
        sleep(2);
        verifyAndClick(Navigation.detachAsNewTabUnderItemDetailsTransactionTab.findBy);
        switchToNewWindow();
    }

    public void clickOnRefreshButtonOnWorkItemPage() throws Throwable {
        verifyAndClick(Navigation.refreshIcon.findBy);
        sleep(2);
    }
}