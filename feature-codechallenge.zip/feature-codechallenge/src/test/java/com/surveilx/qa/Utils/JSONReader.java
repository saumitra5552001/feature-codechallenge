package com.surveilx.qa.Utils;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;

public class JSONReader {

    /**
     * To fetch data from TestData.json file
     * @author pgandhi
     * @param key
     * @return string
     * @exception java.io.FileNotFoundException
     */
    public static String readStringFromDataJSON(String key) throws Exception {
        // parsing file "JSONExample.json"
        Object obj = null;
        if(readStringFromEnvironmentJSON("application").equalsIgnoreCase("CS")){
            obj  = new JSONParser().parse(new FileReader("src/test/resources/TestData/CS/TestData.json"));
        }
        if(readStringFromEnvironmentJSON("application").equalsIgnoreCase("MSC")){
             obj = new JSONParser().parse(new FileReader("src/test/resources/TestData/MSC/TestData.json"));
        }
        if(readStringFromEnvironmentJSON("application").equalsIgnoreCase("SP")){
             obj = new JSONParser().parse(new FileReader("src/test/resources/TestData/SP/TestData.json"));
        }
        // typecasting obj to JSONObject
        JSONObject jo = (JSONObject) obj;
        // getting key
        String value = (String) jo.get(key);
        return value;
    }

    /**
     * To fetch data from TestData.json file
     * @author pgandhi
     * @param key
     * @return string
     * @exception java.io.FileNotFoundException
     */
    public static ArrayList readArrayFromDataJSON(String key) throws Exception {
        // parsing file "JSONExample.json"
        Object obj = null;
        if(readStringFromEnvironmentJSON("application").equalsIgnoreCase("CS")){
            obj  = new JSONParser().parse(new FileReader("src/test/resources/TestData/CS/TestData.json"));
        }
        if(readStringFromEnvironmentJSON("application").equalsIgnoreCase("MSC")){
            obj = new JSONParser().parse(new FileReader("src/test/resources/TestData/MSC/TestData.json"));
        }
        if(readStringFromEnvironmentJSON("application").equalsIgnoreCase("SP")){
            obj = new JSONParser().parse(new FileReader("src/test/resources/TestData/SP/TestData.json"));
        }
        // typecasting obj to JSONObject
        JSONObject jo = (JSONObject) obj;
        //Creating a list for output
        ArrayList<String> list = new ArrayList<String>();
        //getting JSON Array
        JSONArray value = (JSONArray) jo.get(key);
        Iterator<String> iterator = value.iterator();
        while (iterator.hasNext()) {
            String s = iterator.next().toString();
            list.add(s);
        }
        return list;
    }

    /**
     * To fetch data from Environment.json file
     * @author pgandhi
     * @param key
     * @return string
     * @exception java.io.FileNotFoundException
     */
    public static String readStringFromEnvironmentJSON(String key) throws Exception {
        // parsing file "JSONExample.json"
        Object obj = new JSONParser().parse(new FileReader("src/test/resources/Environment.json"));
        // typecasting obj to JSONObject
        JSONObject jo = (JSONObject) obj;
        // getting firstName and lastName
        String value = (String) jo.get(key);
        return value;
    }
}
