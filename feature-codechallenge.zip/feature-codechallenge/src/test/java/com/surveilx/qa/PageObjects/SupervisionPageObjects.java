package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.StepDefinition.CommonSteps;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class SupervisionPageObjects extends CommonFunctions {

    public SupervisionPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private enum Supervision {
        tabNameContainer(By.id("tab-names-container")),
        toggleCollapseButton(By.xpath("//span[@class='collapse-button']")),
        imageCommunicationButton(By.xpath("(//span[@class='tab-name-icon ng-scope'])[1]")),
        textCommunication(By.id("Communication_0")),
        imageInvestigateButton(By.xpath("(//span[@class='tab-name-icon ng-scope'])[2]")),
        textInvestigate(By.id("Investigate_1")),
        ThreeDotButton(By.xpath("//md-icon[@alt='Widget Menu']")),
        labelFullScreen(By.xpath("//span[@title='Full Screen']")),
        labelDetachAsNewTab(By.xpath("//span[@title='Detach as new Tab']")),
        headingCommunication(By.xpath("//h1[text()='Communication']")),
        headingItemId(By.xpath("//h2")),
        closeButtonFullScreen(By.xpath("//md-icon[@alt='Close']")),
        sectionTimezone(By.xpath("//div[@class='timezone-select__div']")),
        sectionPolicyReview(By.xpath("//div[@class='review-details-container__policy-overview']")),
        sectionTranscription(By.xpath("//div[@class='review-details-container__audio-interaction-content-placeholder']")),
        sectionVoicePlayer(By.id("player-id")),
        buttonScenario(By.xpath("//div[@id='apf-investigate-icon-scenarios-container']/div[1]")),
        labelNewScenario(By.xpath("(//label[contains(text(),'New Scenario')])[2]")),
        labelStatus(By.xpath("(//div[contains(text(),'Status')])[1]")),
        valueStatus(By.xpath("(//div[contains(text(),'Status')])[1]/../div/div[1]")),
        labelCreatedBy(By.xpath("(//div[contains(text(),'Created By')])[1]")),
        valueCreatedBy(By.xpath("(//div[contains(text(),'Created By')])[1]/../div[2]/span[1]")),
        labelAssignedTo(By.xpath("(//div[contains(text(),'Assigned To')])[1]")),
        valueAssignedTo(By.xpath("(//div[contains(text(),'Assigned To')])[1]/../div[1]")),
        inputScenarioName(By.xpath("//input[@id='scenarioSubjectInOverview']")),
        labelReferenceID(By.xpath("//div[contains(text(),'Reference ID')]")),
        valueReferenceID(By.xpath("//input[@id='scenarioReferenceID']")),
        scenarioNameInList(By.xpath("(//div[@id='scenarioSubject'])[1]")),
        sectionPlayerContainer(By.id("HTML5PlayerContainer")),
        linkCloseInteaction(By.xpath("//div[@class='closeInteractionDetailsImg']")),
        imageEmailInteraction(By.xpath("//div[@class='apf-interaction-details-image apf-interaction-details-image-Email']")),
        imageVoiceInteraction(By.xpath("//div[@class='apf-interaction-details-image apf-interaction-details-image-Voice']")),
        notificationText(By.id("notificationText")),
        labelParticipants(By.xpath("//div[contains(text(),'Participants') and @class='apf-interaction-details-header-text']")),
        labelFrom(By.xpath("//div[text()='From' and @class='apf-interaction-details-content-label']")),
        labelTo(By.xpath("//div[text()='To' and @class='apf-interaction-details-content-label']")),
        labelMetadata(By.xpath("//div[contains(text(),'Metadata') and @class='apf-interaction-details-header-text']")),
        labelCategorization(By.xpath("//div[contains(text(),'Categorization') and @class='apf-interaction-details-header-text']")),
        labelAnalytics(By.xpath("//span[contains(text(),'Analytics')]")),
        labelAnalytics1(By.xpath("//div[contains(text(),'Analytics') and @class='apf-interaction-details-header-text']")),
        labelRemarks(By.xpath("//div[contains(text(),'Remarks') and @class='apf-interaction-details-header-text']")),
        labelScenarioInformation(By.xpath("//span[contains(text(),'Scenario Information')]")),
        labelScenarioInformation1(By.xpath("//div[contains(text(),'Scenario Information') and @class='apf-interaction-details-header-text']")),
        labelInvestigation(By.xpath("//span[contains(text(),'Investigation')]")),
        labelInvestigation1(By.xpath("//div[contains(text(),'Investigation') and @class='apf-interaction-details-header-text']")),
        arrowScenarioInformation(By.xpath("//span[contains(text(),'Scenario Information')]/../div[2]")),
        buttonDownload(By.xpath("//span[text()='Download']")),
        imageDownload(By.xpath("//div[@class='icon-button downloadScenario']")),
        msgDownloadScenario(By.xpath("//p[contains(text(),'Download scenario')]")),
        msgFileIsProtected(By.xpath("//span[contains(text(),'The file is')]")),
        msgYouNeedThisPassword(By.xpath("//span[contains(text(),'The file is')]")),
        imageRightSign(By.xpath("//span[@class='close-baloon']")),
        getImageMoreButton(By.xpath("//div[@class='icon-button moreBtn']")),
        labelMore(By.xpath("(//span[text()='More'])[2]")),
        msgRemoveScenarios(By.xpath("//span[contains(text(),'Remove scenario?')]")),
        imageRightSign1(By.xpath("(//span[@class='confirm-panel littleY'])[2]")),
        imageCrossSign(By.xpath("(//span[@class='decline-panel littleN'])[2]")),
        labelIssueId(By.xpath("//span[contains(text(),'Issue ID')]")),
        buttonTextView(By.xpath("//span[contains(text(),'Text View')]")),
        labelEmailView(By.xpath("//span[contains(text(),'Email View')]")),
        buttonEmailView(By.xpath("//span[contains(text(),'Email View')]/..")),
        labelCollusionPolicyReview(By.xpath("//span[contains(text(),'Collusion')]")),
        labelParticipantsPolicyReview(By.xpath("//div[contains(text(),'Participants')]")),
        labelMetadataPolicyReview(By.xpath("//div[contains(text(),'Metadata')]")),
        labelCategorizationPolicyReview(By.xpath("//div[contains(text(),'Categorization')]")),
        labelAnalyticsPolicyReview(By.xpath("//div[contains(text(),'Analytics')]")),
        labelObservePolicyHeader(By.xpath("//span[@class='observe-policy-header__policy-name']")),
        buttonRuleConfirm(By.xpath("//button[contains(@class,'confirm')]")),
        buttonRuleReject(By.xpath("//button[contains(@class,'reject')]")),
        buttonDone(By.xpath("//span[text()='Done']")),
        buttonRejectAllRules(By.xpath("//span[text()='Reject all rules']")),
        labelPotentialPriorityLevel(By.xpath("//span[text()='Potential Priority Level']")),
        labelConfirmedPriorityLevel(By.xpath("//span[text()='Confirmed Priority Level']")),
        msgRejectionReason(By.xpath("//div[text()='Rejection reason']")),

        ;
        private By findBy;

        Supervision(By locator) {
            this.findBy = locator;
        }
    }

    public By valueXpath(String s) {
        return By.xpath("//*[text()='" + s + "']");
    }

    @FindBy(xpath="(//div[@class='selectable_false checkbox interactionSpinningWheel_false'])")
    List<WebElement> listCheckBox;

    public void validatePresetPanelCollepsed() throws IOException {
        if (fetchAttribute(Supervision.tabNameContainer.findBy, "class").contains("collapsed")) {
            logPass(driver, "The preset panel is collapsed when page loads and only icons of each is displayed.");
        } else {
            logFail(driver, "The preset panel is not collapsed when page loads and only icons of each is not displayed.");
        }
    }

    public void validatePresetPanelExpanded() throws IOException {
        if (fetchAttribute(Supervision.tabNameContainer.findBy, "class").contains("expanded")) {
            logPass(driver, "The preset panel is expanded when page loads and only icons of each is displayed.");
        } else {
            logFail(driver, "The preset panel is not expanded when page loads and only icons of each is displayed.");
        }
    }

    public void clickOnTabNameToggleButton() throws Throwable {
        verifyAndClick(Supervision.toggleCollapseButton.findBy);
    }

    public void mouseHoverToCommunicationTab() throws IOException {
        mouseHoverToElement(Supervision.imageCommunicationButton.findBy);
        verifyText(Supervision.textCommunication.findBy, "Communication");
    }

    public void mouseHoverToInvestigateTab() throws IOException {
        mouseHoverToElement(Supervision.imageInvestigateButton.findBy);
        verifyText(Supervision.textInvestigate.findBy, "Investigate");
    }

    public void clickOnInvestigateTab() throws Throwable {
        sleep(60);
        if (!fetchAttribute(Supervision.tabNameContainer.findBy, "class").contains("expanded")) {
                clickOnTabNameToggleButton();
        }
        verifyAndClick(Supervision.textInvestigate.findBy);
        sleep(60);
    }

    public void clickOn3DotButton() throws Throwable {
        verifyAndClick(Supervision.ThreeDotButton.findBy);
    }

    public void validateOn3DotButton() throws Throwable {
        verifyText(Supervision.labelFullScreen.findBy, "Full Screen");
        verifyText(Supervision.labelDetachAsNewTab.findBy, "Detach as new Tab");
    }

    public void clickOnFullScreenButton() throws Throwable {
        verifyAndClick(Supervision.labelFullScreen.findBy);
    }

    public void clickOnDetachAsNewTabButton() throws Throwable {
        verifyAndClick(Supervision.labelDetachAsNewTab.findBy);
    }

    public void tabHandleForCommunicationNewTab(String ItemID,String itemType) throws Throwable {
        //getting all the handles currently available
        sleep(15);
        String currentHandle = driver.getWindowHandle();
        Set<String> handles = driver.getWindowHandles();
        for (String actual : handles) {
            if (!actual.equalsIgnoreCase(currentHandle)) {
                //switching to the opened tab
                driver.switchTo().window(actual);
                verifyText(Supervision.headingCommunication.findBy, "Communication");
                verifyText(Supervision.headingItemId.findBy, ItemID);
                validateUIOfSuperVisionPart(itemType);
                sleep(5);
                driver.switchTo().defaultContent();
            }
        }
    }

    public void closeButtonOnFullScreenScreen() throws Throwable {
        verifyAndClick(Supervision.closeButtonFullScreen.findBy);
    }

    public void validateUIOfSuperVisionPart(String itemType) throws Throwable {
        sleep(15);
        changeFrameWithFrameName("cs_frame");
        isElementDisplayed(Supervision.sectionTimezone.findBy);
        isElementDisplayed(Supervision.sectionPolicyReview.findBy);
        //verifyText(Supervision.labelCollusionPolicyReview.findBy,"Collusion");
        verifyText(Supervision.labelParticipantsPolicyReview.findBy,"Participants");
        verifyText(Supervision.labelMetadataPolicyReview.findBy,"Metadata");
        verifyText(Supervision.labelCategorizationPolicyReview.findBy,"Categorization");
        verifyText(Supervision.labelAnalyticsPolicyReview.findBy,"Analytics");
        if(itemType.equalsIgnoreCase("Voice")){
            isElementDisplayed(Supervision.sectionTranscription.findBy);
            isElementDisplayed(Supervision.sectionVoicePlayer.findBy);
        }
        if(itemType.equalsIgnoreCase("Email")){
            verifyText(Supervision.buttonTextView.findBy,"Text View");
            verifyText(Supervision.labelEmailView.findBy,"Email View");
            //verifyAndClick(Supervision.buttonEmailView.findBy);
        }
    }

    public void createNewInteractionScenario() throws Throwable {
        sleep(15);
        changeFrameWithFrameName(driver.findElement(By.xpath("(//iframe[@id='cs_frame'])[2]")));
        verifyAndClickViaJavaScript(Supervision.linkCloseInteaction.findBy);
        System.out.println(fetchAttribute(Supervision.arrowScenarioInformation.findBy,"class"));
        String scenarioName = "Test"+getRandomStringString();
        verifyAndEnterText(Supervision.inputScenarioName.findBy,scenarioName);
        if(fetchAttribute(Supervision.arrowScenarioInformation.findBy,"class").contains("flip")){

        }else verifyAndClickViaJavaScript(Supervision.labelScenarioInformation.findBy);
        verifyAndClick(Supervision.labelReferenceID.findBy);
        sleep(40);
        //verifyText(Supervision.inputScenarioName.findBy,scenarioName);
        //verifyContainsText(Supervision.valueReferenceID.findBy,"Communication Work Item ID: ");
        verifyText(Supervision.labelStatus.findBy,"Status");
        verifyText(Supervision.valueStatus.findBy,"Not Reviewed");
        verifyText(Supervision.labelCreatedBy.findBy,"Created By");
        verifyContainsText(Supervision.valueCreatedBy.findBy,"Eugene Gray (admin)");
        verifyText(Supervision.labelAssignedTo.findBy,"Assigned To");
        verifyText(Supervision.valueAssignedTo.findBy,"You");
        isElementDisplayed(Supervision.sectionPlayerContainer.findBy);
    }

    public void closeInteractions() throws Throwable {
        sleep(15);
        changeFrameWithFrameName(driver.findElement(By.xpath("(//iframe[@id='cs_frame'])[2]")));
        verifyAndClickViaJavaScript(Supervision.linkCloseInteaction.findBy);
        //driver.navigate().refresh();
        sleep(15);
    }

    public void validateInteractionsFunctionalityCounts(String noOfInteractions) throws Throwable {
        //changeFrameWithFrameName("frmDetailsSingleView");
        //changeFrameWithFrameName("cs_frame");
        //Click for Scenario which has predefined interactions
        //verifyAndClick(valueXpath("Interactions: "+noOfInteractions));
        for(int i =1;i<Integer.valueOf(noOfInteractions);i++){
            verifyAndClickViaJavaScript(listCheckBox.get(i));
            sleep(5);
        }
        sleep(15);
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='player-adv-row']"));
        if(elements.size()==Integer.valueOf(noOfInteractions)){
            logPass(driver, "Number of interactions:"+noOfInteractions+" is matched with number of players:"+elements.size());
        }else{
            logFail(driver, "Number of interactions:"+noOfInteractions+" is not matched with number of players:"+elements.size());
        }
    }

    public void validateInteractionsFunctionalityCountsInSameFrame(String noOfInteractions) throws Throwable {
        sleep(15);
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='player-adv-row']"));
        if(elements.size()==Integer.valueOf(noOfInteractions)){
            logPass(driver, "Number of interactions:"+noOfInteractions+" is matched with number of players:"+elements.size());
        }else{
            logFail(driver, "Number of interactions:"+noOfInteractions+" is not matched with number of players:"+elements.size());
        }
    }

    public void validateCorrelatedInteractions(String itemId) throws Throwable {
        sleep(60);
        changeFrameWithFrameName(driver.findElement(By.xpath("(//iframe[@id='cs_frame'])[2]")));
        //verifyContainsText(Supervision.notificationText.findBy,"interactions found.");
        if(itemId.equalsIgnoreCase("Email")){
            isElementDisplayed(Supervision.imageEmailInteraction.findBy);
        }
        if(itemId.equalsIgnoreCase("Voice")){
            isElementDisplayed(Supervision.imageVoiceInteraction.findBy);
        }
//        verifyText(Supervision.labelParticipants.findBy,"Participants");
//        verifyText(Supervision.labelFrom.findBy,"From");
//        verifyText(Supervision.labelTo.findBy,"To");
//        verifyText(Supervision.labelMetadata.findBy,"MetaData");
        scrollIntoView(Supervision.labelCategorization.findBy);
        verifyText(Supervision.labelCategorization.findBy,"Categorization");
        verifyText(Supervision.labelAnalytics1.findBy,"Analytics");
        verifyText(Supervision.labelRemarks.findBy,"Remarks");
    }

    public void selectMultipleInteractions() throws Throwable {
        for(int i =1; i<4;i++){
            By locator = By.xpath("(//div[@class='selectable_false checkbox interactionSpinningWheel_false'])["+i+"]");
            verifyAndClickViaJavaScript(locator);
        }
    }

    public void validateScenarioOverviewText() throws Throwable {
        sleep(15);
        verifyText(Supervision.labelScenarioInformation.findBy,"Scenario Information");
        if(fetchAttribute(Supervision.arrowScenarioInformation.findBy,"class").contains("flip")){

        }else verifyAndClickViaJavaScript(Supervision.labelScenarioInformation.findBy);
        verifyText(Supervision.labelStatus.findBy,"Status");
        verifyText(Supervision.valueStatus.findBy,"Not Reviewed");
        verifyText(Supervision.labelCreatedBy.findBy,"Created By");
        verifyTextWithNonEmptyString(Supervision.valueCreatedBy.findBy);
        verifyText(Supervision.labelAssignedTo.findBy,"Assigned To");
        verifyText(Supervision.valueAssignedTo.findBy,"You");
        isElementDisplayed(Supervision.sectionPlayerContainer.findBy);
        verifyText(Supervision.labelAnalytics.findBy,"Analytics");
        verifyText(Supervision.labelInvestigation.findBy,"Investigation");
    }

    public void validateScenarioCreationForEmptyScenario() throws Throwable {
        sleep(15);
        changeFrameWithFrameName(driver.findElement(By.xpath("(//iframe[@id='cs_frame'])[2]")));
        verifyAndClickViaJavaScript(Supervision.linkCloseInteaction.findBy);
        System.out.println(fetchAttribute(Supervision.arrowScenarioInformation.findBy,"class"));
        clearText(Supervision.inputScenarioName.findBy);
        if(fetchAttribute(Supervision.arrowScenarioInformation.findBy,"class").contains("flip")){

        }else verifyAndClickViaJavaScript(Supervision.labelScenarioInformation.findBy);
        verifyAndClick(Supervision.labelReferenceID.findBy);
        //waitForFrame();
        verifyText(Supervision.notificationText.findBy,"Subject cannot be empty.");
    }

    public void clickOnDownloadOption() throws Throwable {
        sleep(30);
        changeFrameWithFrameName("cs_frame");
        sleep(10);
        verifyAndClickViaJavaScript(Supervision.buttonDownload.findBy);
        sleep(10);
        if(isFileDownloaded()==true){
            logPass(driver,"File is downloaded");
        }else{
            logFail(driver,"File is not downloaded");
        }
    }

    public void clickOnDownloadOptionForInvestigateTab() throws Throwable {
        sleep(10);
        verifyAndClickViaJavaScript(Supervision.imageDownload.findBy);
        verifyContainsText(Supervision.msgDownloadScenario.findBy,"Download scenario");
        verifyContainsText(Supervision.msgFileIsProtected.findBy,"The file is protected with the folowing password:");
        verifyContainsText(Supervision.msgYouNeedThisPassword.findBy,"You need this password to access the downloaded content.");
        verifyAndClickViaJavaScript(Supervision.imageRightSign.findBy);
        sleep(10);
        if(isFileDownloaded()==true){
            logPass(driver,"File is downloaded");
        }else{
            logFail(driver,"File is not downloaded");
        }
    }

    public void clickOnRemoveScenariosOptionForInvestigateTab() throws Throwable {
        sleep(10);
        verifyAndClickViaJavaScript(Supervision.getImageMoreButton.findBy);
        verifyText(Supervision.labelMore.findBy,"More");
        verifyText(Supervision.msgRemoveScenarios.findBy,"Remove Scenario?");
        isElementDisplayed(Supervision.imageRightSign1.findBy);
        isElementDisplayed(Supervision.imageCrossSign.findBy);
        verifyAndClickViaJavaScript(Supervision.imageRightSign1.findBy);
        verifyText(Supervision.notificationText.findBy,"Scenario deleted!");
    }

    public String getItemID() throws IOException {
        String rowId = fetchText(Supervision.labelIssueId.findBy);
        String midId = rowId.replace("Issue ID: ","");
        return midId.replace(" |","");
    }
    public void ivalidateRulesUI() throws Throwable {
        sleep(60);
        changeFrameWithFrameName("cs_frame");
        verifyText(Supervision.labelObservePolicyHeader.findBy,"Everything");
        isElementDisplayed(Supervision.buttonRuleConfirm.findBy);
        isElementDisplayed(Supervision.buttonRuleReject.findBy);
        isElementDisplayed(Supervision.buttonDone.findBy);
        isElementEnabled(Supervision.buttonDone.findBy);
        isElementDisplayed(Supervision.buttonRejectAllRules.findBy);
        verifyText(Supervision.labelPotentialPriorityLevel.findBy,"Potential Priority Level");
        verifyText(Supervision.labelConfirmedPriorityLevel.findBy,"Confirmed Priority Level");
    }

    public void ivalidateRulesFunctionality(String rulecheck) throws Throwable {
        if(rulecheck.equalsIgnoreCase("accept")){
            verifyAndClick(Supervision.buttonRuleConfirm.findBy);
            sleep(10);
            //verifyAndClick(Supervision.buttonDone.findBy);
        }
        if(rulecheck.equalsIgnoreCase("deny")||rulecheck.equalsIgnoreCase("rejectall")){
            if(rulecheck.equalsIgnoreCase("deny")){
                verifyAndClickViaJavaScript(Supervision.buttonRuleReject.findBy);
            }else{
                verifyAndClickViaJavaScript(Supervision.buttonRejectAllRules.findBy);
            }
            sleep(5);
            verifyText(Supervision.msgRejectionReason.findBy,"Rejection reason");
            List<WebElement> elements = driver.findElements(By.xpath("//li[contains(text(),'Close')]"));
            Random rand = new Random();
            int randomNum = rand.nextInt((4 - 1) + 1) + 1;
            verifyAndClick(elements.get(randomNum));
            sleep(10);
            //verifyAndClick(Supervision.buttonDone.findBy);
        }

    }
}