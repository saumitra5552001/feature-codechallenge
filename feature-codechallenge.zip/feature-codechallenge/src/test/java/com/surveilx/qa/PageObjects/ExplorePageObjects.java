package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.StepDefinition.CommonSteps;
import com.surveilx.qa.StepDefinition.LoginSteps;
import com.surveilx.qa.StepDefinition.NavigationSteps;
import org.apache.commons.math3.analysis.function.Exp;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class ExplorePageObjects extends CommonFunctions {

    public ExplorePageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    LoginSteps loginsteps = new LoginSteps();
    NavigationSteps navigation = new NavigationSteps();
    CommonSteps commonSteps = new CommonSteps();

    public enum Explore {
        msgLoadedInteractions(By.xpath("//div[@class='rs_inter_container']")),
        inputSearch(By.id("sb-searchinput")),
        facetSource(By.xpath("//span[text()='Source']")),
        facetChannel(By.xpath("//span[text()='Channel']")),
        facetDate(By.xpath("//span[text()='Date']")),
        facetValueBloomberg(By.xpath("//div[text()='Bloomberg']")),
        facetValueVoice(By.xpath("//div[text()='Voice']")),
        facetValueChat(By.xpath("//div[text()='Chat']")),
        facetValueEmail(By.xpath("//div[text()='Email']")),
        facetValueAttachment(By.xpath("//div[text()='Attachment']")),
        facetValueNiceTradingRecording(By.xpath("//div[text()='NiceTradingRecording']")),
        labelInteraction(By.xpath("//span[contains(text(),'Interaction')]")),
        imageVoiceInteraction(By.xpath("//div[@class='apf-interaction-details-image apf-interaction-details-image-Voice']")),
        imageEmailInteraction(By.xpath("//div[@class='apf-interaction-details-image apf-interaction-details-image-Email']")),
        imageChatInteraction(By.xpath("//div[@class='apf-interaction-details-image apf-interaction-details-image-Chat']")),
        imageAttachmentInteraction(By.xpath("//div[@class='apf-interaction-details-image apf-interaction-details-image-Attachment']")),
        labelParticipants(By.xpath("//div[contains(text(),'Participants')]")),
        labelFrom(By.xpath("//div[text()='From']")),
        labelTo(By.xpath("//div[text()='To']")),
        labelMetadata(By.xpath("//div[contains(text(),'Metadata')]")),
        labelCategorization(By.xpath("//div[contains(text(),'Categorization')]")),
        labelAnalytics(By.xpath("//div[contains(text(),'Analytics')]")),
        labelAttachments(By.xpath("(//div[contains(text(),'Attachments')])[1]")),
        labelContent(By.xpath("//div[contains(text(),'Content')]")),
        labelConversation(By.xpath("//div[contains(text(),'Conversation')]")),
        textAudit(By.xpath("//div[@id='apf-explore-icon-history-text']")),
        textContent(By.xpath("//div[@id='apf-explore-icon-content-text']")),
        playerExplore(By.xpath("//div[@class='player-timeline-container']")),
        buttonPlayerExpandCollapsed(By.xpath("//div[@id='player_expand_btn']")),
        buttonSpeedRate(By.xpath("//div[@id='player_speed_rate']")),
        buttonPrevious(By.xpath("//div[@id='player_previous']")),
        buttonPlay(By.id("player_play_btn")),
        buttonNext(By.id("player_next")),
        buttonLoop(By.id("player_loop_btn")),
        labelTimeText(By.id("player_time_text")),
        buttonSpeaker(By.id("speakerstyle")),
        labelTimeZone(By.xpath("//span[contains(text(),'Time Zone:')]")),
        valueTimeZone(By.xpath("//span[@class='timezoneNameText']")),
        valueDateExplore(By.xpath("//div[@class='apf-interaction-details-content-date']/span")),
        valueLocalTimeZone(By.xpath("//div[@class='timezone-popup-option-item-islocal']")),
        valuePlayerDate(By.xpath("//div[contains(@class,'starttime')]/div[1]")),
        valuePlayerTime(By.xpath("//div[contains(@class,'starttime')]/div[2]")),
        valueChatDateTime(By.xpath("//div[@class='interaction-chat-message-date']")),
        linkClearSearchInput(By.xpath("//a[@class='sb_clearSearchInputButton']")),
        linkClearSelection(By.xpath("//div[text()='Clear selections']")),
        yellowPointer(By.xpath("//div[@class='player-term-interaction-pointer']")),
        dropDownLast(By.xpath("//span[@class='k-input']")),
        listValueLastHour(By.xpath("//li[text()='Last Hour']")),
        listValueLastXHour(By.xpath("//li[text()='Last X Hours']")),
        listValueLastDay(By.xpath("//li[text()='Last Day']")),
        listValueLastWeek(By.xpath("//li[text()='Last Week']")),
        listValueLast4Weeks(By.xpath("//li[text()='Last 4 Weeks']")),
        listValueBetween(By.xpath("//li[text()='Between']")),
        startCalendar(By.xpath("(//span[@class='k-icon k-i-calendar'])[1]/..")),
        buttonNextMonthFromCalendar(By.xpath("(//span[@class='k-icon k-i-arrow-60-right'])[1]")),
        buttonNextMonthToCalendar(By.xpath("(//span[@class='k-icon k-i-arrow-60-right'])[2]")),
        link1stDate(By.xpath("(//td[@role='gridcell']/a[text()='1'])[1]")),
        link3rdDate(By.xpath("(//td[@role='gridcell']/a[text()='3'])[1]")),
        endCalendar(By.xpath("(//span[@class='k-icon k-i-calendar'])[2]/..")),
        linkTodayDate(By.xpath("(//td[contains(@class,'k-today')]/a)[2]")),
        msgNoResultFound(By.xpath("(//div[text()='No result items found.'])[2]")),
        listInteraction1(By.xpath("//div[@class='apf-explore-interaction-content-text']")),
        listInteraction2(By.xpath("(//div[@class='apf-explore-interaction-content-text'])[2]")),
        buttonSearch(By.id("apf-explore-icon-queries-text")),
        buttonNewSearch(By.xpath("//div[@class='ss_plus_button']")),
        textBoxNewSearch(By.xpath("//input[@class='ss_window_input']")),
        buttonSaveSearch(By.xpath("//div[@class='ss_button_ok']")),
        buttonOpenSearch(By.xpath("(//div[@class='ss_menu_button ss_menu_open'])[1]")),
        buttonSaveSearch1(By.xpath("(//div[@class='ss_menu_button ss_menu_save'])[1]")),
        buttonMoreSearch(By.xpath("(//div[@class='ss_menu_button ss_menu_more'])[1]")),
        optionSetAsDefault(By.xpath("(//div[@class='ss_more_default ss_popup_menu'])[1]")),
        optionDelete(By.xpath("(//div[@class='ss_more_delete ss_popup_menu'])[1]")),
        linkLogout(By.id("logoutUserLink")),
        labelSearchHeader(By.id("searchHeader")),
        loggedInUserId(By.id("usernameInHeader")),
        playthumb(By.id("player_timeline_thumb")),
        buttonDownload(By.id("apf-explore-download-set-icon")),
        leftdragablepart(By.id("player-left-loop-part-draggable")),
        rightdragablepart(By.id("player-right-loop-part-draggable")),
        volumeDrager(By.xpath("//a[@class='k-draghandle']/../..")),
        highlightedWord(By.xpath("(//span[@class='exact_match'])[1]")),
        buttonAddScenario(By.xpath("//span[@id='addNewScenario']")),
        inputScenarioName(By.xpath("//*[@id='scenarioSubjectInOverview']")),
        inputScenarioDescription(By.xpath("//textarea[@placeholder='Enter scenario description here...']")),
        inputScenarioId(By.id("scenarioReferenceID")),
        labelStatus(By.xpath("//div[text()='Status']")),
        valueStatus(By.xpath("//div[@class='mini-dropDownListView-item mini-dropDownListView-item-inRequestedBy']")),
        valueRole(By.xpath("//div[@role='combobox']")),
        buttonAddComment(By.xpath("//div[@class='addComment']")),
        inputTextArea(By.xpath("//textarea[@class='newCommentText']")),
        labelComments(By.xpath("//div[contains(text(),'Comments')]")),
        buttonExplore(By.xpath("//div[contains(text(),' Explore')]")),
        buttonScenarios(By.xpath("(//div[contains(text(),' Scenarios')])[2]")),
        checkbox1stInteraction(By.xpath("//div[@class='selectable_false checkbox interactionSpinningWheel_false']")),
        checkbox1stInteraction1(By.xpath("//div[@class='selectable_false checkbox']")),
        list1stScenarios(By.xpath("//div[@class='listItem-details-container']")),
        buttonScenario(By.xpath("//div[@id='apf-investigate-icon-scenarios-container']/div[1]")),
        list2ndScenarioFromInvestigate(By.xpath("(//div[@id='scenarioSubject'])[2]")),
        buttonCreateWorkItem(By.xpath("//div[@id='create-work-item']")),
        labelChooseQueue(By.xpath("//div[contains(text(),'Choose Queue')]")),
        msgChooseQueue(By.xpath("//span[contains(text(),'Create 1 Work Item in Queue:')]")),
        dropdownWorkItem(By.xpath("//div[@class='b-dropdown dropdown']")),
        dropdownApacDemo(By.xpath("//a[contains(text(),'test1 (Business Unit: Corporate)')]")),
        buttonConfirm(By.xpath("//div[text()='Confirm']")),
        notificationText(By.id("notificationText")),
        buttonCloseDetailsPan(By.id("closeDetailsPane")),
        dropdownSort(By.xpath("//div[@class='sort-type-search-results-icon']")),
        dropdownDescending(By.xpath("//div[text()='Date descending (most recent at the top)']")),
        dropdownAscending(By.xpath("//div[text()='Date ascending (oldest at the top)']")),
        ;
        public By findBy;

        Explore(By locator) {
            this.findBy = locator;
        }
    }

    public By valueXpath(String s) {
        return By.xpath("//*[text()='" + s + "']");
    }

    public By spanXpath(String s) {
        return By.xpath("//span[text()='" + s + "']");
    }

    public By divXpath(String s) {  return By.xpath("//div[text()='" + s + "']");}

    public By divContainsTextXpath(String s){ return By.xpath("//div[contains(text(),'"+s+"')]");}

    public By liContainsTextXpath(String s){ return By.xpath("//li[contains(text(),'"+s+"')]");}

    @FindBy(xpath="//div[@class='apf-explore-interaction-content-text']")
    List<WebElement> listInteraction;

    @FindBy(xpath="//div[@class='historyItemContent']")
    List<WebElement> listInteractionHistory;

    @FindBy(xpath="//div[@title='Download call']")
    WebElement labelDownloadForVoice;

    @FindBy(xpath="//div[@title='Download call']/../div[2]")
    WebElement labelDownloadForEmail;

    @FindBy(xpath="//div[@class='timezone-popup-option-item']")
    List<WebElement> listTimeZone;

    @FindBy(xpath="//div[@class='player-adv-row']")
    List<WebElement> listPlayerCount;

    public void iValidateNumberOfInteractionsInExplorePageForTextInput(String word,String count) throws Throwable {
//        verifyAndClick(Explore.linkClearSelection.findBy);
//        sleep(2);
//        verifyAndClick(Explore.linkClearSearchInput.findBy);
        sleep(2);
        int totalInteraction = Integer.valueOf(jsonRead.readStringFromDataJSON("TotalInteraction"));
        verifyContainsText(Explore.msgLoadedInteractions.findBy,"Loaded 50 of "+jsonRead.readStringFromDataJSON("TotalInteraction")+" interactions.");
        verifyAndEnterText(Explore.inputSearch.findBy,word);
        sleep(3);
        pressEnterButton(Explore.inputSearch.findBy);
        sleep(10);
        if(Integer.valueOf(count)<=50)
        {
            verifyContainsText(Explore.msgLoadedInteractions.findBy,"Loaded "+count+" of "+count+" interactions.");
        }
        if(Integer.valueOf(count)>50)
        {
            verifyContainsText(Explore.msgLoadedInteractions.findBy,"Loaded 50 of "+count+" interactions.");
        }

        int searchedInteraction = Integer.valueOf(count);
        if(searchedInteraction<totalInteraction){
            logPass(driver,"Total Interactions:"+totalInteraction+" and Searched Interactions:"+searchedInteraction);
        }else{
            logFail(driver,"Total Interactions:"+totalInteraction+" and Searched Interactions:"+searchedInteraction);
        }
        verifyAndClick(Explore.linkClearSearchInput.findBy);
        sleep(10);
        int totalInteraction1 = Integer.valueOf(fetchText(Explore.msgLoadedInteractions.findBy).replaceAll("Loaded 50 of","").replaceAll("interactions.","").trim());
        if(searchedInteraction<totalInteraction1){
            logPass(driver,"Total Interactions:"+totalInteraction1+" and Searched Interactions:"+searchedInteraction);
        }else{
            logFail(driver,"Total Interactions:"+totalInteraction1+" and Searched Interactions:"+searchedInteraction);
        }
    }

    public void iInsertFilterViaSourceOption(String itemType) throws Throwable {
        sleep(20);
        verifyAndClick(Explore.facetChannel.findBy);
        if(itemType.equalsIgnoreCase("Voice")){
            verifyAndClick(Explore.facetValueVoice.findBy);
        }
        if(itemType.equalsIgnoreCase("Chat")){
            verifyAndClick(Explore.facetValueChat.findBy);
        }
        if(itemType.equalsIgnoreCase("Email")){
            verifyAndClick(Explore.facetValueEmail.findBy);
        }
        if(itemType.equalsIgnoreCase("Attachment")){
            verifyAndClick(Explore.facetValueAttachment.findBy);
        }
        sleep(20);
        List<WebElement> el = listInteraction;
        //nextInt as provided by Random is exclusive of the top value so you need to add 1
        Random rand = new Random();
        int randomNum = rand.nextInt((5 - 1) + 1) + 1;
        sleep(5);
        verifyAndClick(listInteraction.get(randomNum));
    }

    public void iValidateInteractionInExplore(String itemType) throws Throwable {
        sleep(15);
        verifyText(Explore.labelInteraction.findBy,"Interaction");
        sleep(10);
        if(itemType.equalsIgnoreCase("Voice")){
            isElementDisplayed(Explore.imageVoiceInteraction.findBy);
            verifyAndClickViaJavaScript(labelDownloadForVoice);
            verifyText(Explore.labelContent.findBy,"Content");
        }
        if(itemType.equalsIgnoreCase("Email")){
            isElementDisplayed(Explore.imageEmailInteraction.findBy);
            verifyAndClickViaJavaScript(labelDownloadForEmail);
            verifyText(Explore.labelParticipants.findBy,"Participants");
            verifyText(Explore.labelFrom.findBy,"From");
            verifyText(Explore.labelTo.findBy,"To");
        }
        if(itemType.equalsIgnoreCase("Attachment")){
            isElementDisplayed(Explore.imageAttachmentInteraction.findBy);
            verifyText(Explore.labelParticipants.findBy,"Participants");
            verifyText(Explore.labelFrom.findBy,"From");
            verifyText(Explore.labelTo.findBy,"To");
        }
        if(itemType.equalsIgnoreCase("Chat")){
            isElementDisplayed(Explore.imageChatInteraction.findBy);
            verifyText(Explore.labelParticipants.findBy,"Participants");
            verifyText(Explore.labelFrom.findBy,"From");
            verifyText(Explore.labelTo.findBy,"To");
        }
        //verifyText(Explore.labelMetadata.findBy,"Metadata");
        verifyText(Explore.labelCategorization.findBy,"Categorization");
        verifyText(Explore.labelAnalytics.findBy,"Analytics");
        if(itemType.equalsIgnoreCase("Email")){
            verifyText(Explore.labelContent.findBy,"Content");
        }
        if(itemType.equalsIgnoreCase("Chat")){
            verifyText(Explore.labelConversation.findBy,"Conversation");
        }
        verifyAndClick(Explore.textAudit.findBy);
        sleep(5);
        isElementDisplayed(listInteractionHistory.get(1));
        isElementDisplayed(listInteractionHistory.get(2));
        verifyAndClick(Explore.textContent.findBy);
        if(itemType.equalsIgnoreCase("Voice")){
            voicePlayerVerify();
        }
    }

    public void voicePlayerVerify() throws Throwable {
        isElementDisplayed(Explore.playerExplore.findBy);
        sleep(5);
        verifyAndClick(Explore.buttonPlayerExpandCollapsed.findBy);
        if(fetchAttribute(Explore.buttonPlayerExpandCollapsed.findBy,"class").contains("collapsed")){
            logPass(driver,"Player is collapsed");
        }else{
            logFail(driver,"Player is expanded");
        }
        verifyAndClick(Explore.buttonPlayerExpandCollapsed.findBy);
        if(fetchAttribute(Explore.buttonPlayerExpandCollapsed.findBy,"class").contains("expanded")){
            logPass(driver,"Player is expanded");
        }else{
            logFail(driver,"Player is collapsed");
        }
        verifyAndClick(Explore.buttonPlay.findBy);
        isElementDisplayed(Explore.playthumb.findBy);
        verifyAndClick(Explore.buttonSpeedRate.findBy);
        verifyAndClick(Explore.buttonSpeedRate.findBy);
        verifyAndClick(Explore.buttonSpeedRate.findBy);
        verifyAndClick(Explore.buttonPrevious.findBy);
        verifyAndClick(Explore.buttonPlay.findBy);
        verifyAndClick(Explore.buttonNext.findBy);
        verifyAndClick(Explore.buttonLoop.findBy);
        isElementDisplayed(Explore.leftdragablepart.findBy);
//            if(fetchAttribute(Explore.leftdragablepart.findBy,"data-role").equalsIgnoreCase("draggable")){
//                logPass(driver,"Draggable attribute is there");
//            }else{
//                logFail(driver,"Draggable attribute is not there");
//            }
        isElementDisplayed(Explore.rightdragablepart.findBy);
//            if(fetchAttribute(Explore.rightdragablepart.findBy,"data-role").equalsIgnoreCase("draggable")){
//                logPass(driver,"Draggable attribute is there");
//            }else{
//                logFail(driver,"Draggable attribute is not there");
//            }
        isElementDisplayed(Explore.labelTimeText.findBy);
        isElementDisplayed(Explore.buttonSpeaker.findBy);
        mouseHoverToElement(Explore.buttonSpeaker.findBy);
//        isElementDisplayed(Explore.volumeDrager.findBy);
//            if(fetchAttribute(Explore.volumeDrager.findBy,"data-role").equalsIgnoreCase("draggable")){
//                logPass(driver,"Draggable attribute is there");
//            }else{
//                logFail(driver,"Draggable attribute is not there");
//            }
    }

    public void timeZoneVerification() throws Throwable {
        //Timezone Verification
        sleep(15);
        verifyText(Explore.labelTimeZone.findBy,"Time Zone: ");
        String date1 = fetchText(Explore.valueDateExplore.findBy);
        verifyAndClick(Explore.valueTimeZone.findBy);
        Random rand = new Random();
        int randomNum = rand.nextInt((7 - 1) + 1) + 1;
        sleep(3);
        verifyAndClick(listTimeZone.get(randomNum));
        String date2 = fetchText(Explore.valueDateExplore.findBy);
        if(date1.equalsIgnoreCase(date2)){
            logFail(driver,"Time and Date is not getting changed according to timezone");
            logFail("Local Timezone:"+date1+" vs Changed Timezone:"+date2);
        }else{
            logPass(driver,"Time and Date are getting changed according to timezone");
            logPass("Local Timezone:"+date1+" vs Changed Timezone:"+date2);
        }
        verifyAndClick(Explore.valueTimeZone.findBy);
        sleep(3);
        verifyAndClick(Explore.valueLocalTimeZone.findBy);
    }

    public void timeZoneVerificationForPlayerTime() throws Throwable {
        sleep(15);
        String date1 = fetchText(Explore.valuePlayerDate.findBy);
        String time1 = fetchText(Explore.valuePlayerTime.findBy);
        String dateAndTime1 = date1.concat(time1);
        verifyAndClick(Explore.valueTimeZone.findBy);
        Random rand = new Random();
        int randomNum = rand.nextInt((7 - 1) + 1) + 1;
        sleep(3);
        verifyAndClick(listTimeZone.get(randomNum));
        String date2 = fetchText(Explore.valuePlayerDate.findBy);
        String time2 = fetchText(Explore.valuePlayerTime.findBy);
        String dateAndTime2 = date2.concat(time2);
        if(dateAndTime1.equalsIgnoreCase(dateAndTime2)){
            logFail(driver,"Time and Date is not getting changed according to timezone");
            logFail("Local Timezone:"+dateAndTime1+" vs Changed Timezone:"+dateAndTime2);
        }else{
            logPass(driver,"Time and Date are getting changed according to timezone");
            logPass("Local Timezone:"+dateAndTime1+" vs Changed Timezone:"+dateAndTime2);
        }
    }

    public void timeZoneVerificationForChatTime() throws Throwable {
        sleep(15);
        String datetime1 = fetchText(Explore.valueChatDateTime.findBy);
        verifyAndClick(Explore.valueTimeZone.findBy);
        Random rand = new Random();
        int randomNum = rand.nextInt((7 - 1) + 1) + 1;
        sleep(3);
        verifyAndClick(listTimeZone.get(randomNum));
        String datetime2 = fetchText(Explore.valueChatDateTime.findBy);
        if(datetime1.equalsIgnoreCase(datetime2)){
            logFail(driver,"Time and Date is not getting changed according to timezone");
            logFail("Local Timezone:"+datetime1+" vs Changed Timezone:"+datetime2);
        }else{
            logPass(driver,"Time and Date are getting changed according to timezone");
            logPass("Local Timezone:"+datetime1+" vs Changed Timezone:"+datetime2);
        }
    }

    public void iValidateNumberOfInteractionsInFacetFilterFunctionality(String menu, String subMenu,String count) throws Throwable {
        int totalInteraction = Integer.valueOf(jsonRead.readStringFromDataJSON("TotalInteraction"));
        verifyContainsText(Explore.msgLoadedInteractions.findBy,"Loaded 50 of "+jsonRead.readStringFromDataJSON("TotalInteraction")+" interactions.");
        iCreateFilterAs(menu,subMenu);
        sleep(3);
        pressEnterButton(Explore.inputSearch.findBy);
        sleep(10);
        if(Integer.valueOf(count)<=50)
        {
            verifyContainsText(Explore.msgLoadedInteractions.findBy,"Loaded "+count+" of "+count+" interactions.");
        }
        if(Integer.valueOf(count)>50)
        {
            verifyContainsText(Explore.msgLoadedInteractions.findBy,"Loaded 50 of "+count+" interactions.");
        }

        int searchedInteraction = Integer.valueOf(count);
        if(searchedInteraction<totalInteraction){
            logPass(driver,"Total Interactions:"+totalInteraction+" and Searched Interactions:"+searchedInteraction);
        }else{
            logFail(driver,"Total Interactions:"+totalInteraction+" and Searched Interactions:"+searchedInteraction);
        }
        verifyAndClick(Explore.linkClearSelection.findBy);
        sleep(10);
        int totalInteraction1 = Integer.valueOf(fetchText(Explore.msgLoadedInteractions.findBy).replaceAll("Loaded 50 of","").replaceAll("interactions.","").trim());
        if(searchedInteraction<totalInteraction1){
            logPass(driver,"Total Interactions:"+totalInteraction1+" and Searched Interactions:"+searchedInteraction);
        }else{
            logFail(driver,"Total Interactions:"+totalInteraction1+" and Searched Interactions:"+searchedInteraction);
        }
    }

    public void iCreateFilterAs(String menu,String subMenu) throws Throwable {
        sleep(20);
        verifyAndClick(spanXpath(menu));
        sleep(3);
        verifyAndClick(divXpath(subMenu));
        sleep(20);
    }

    public void iValidateInteraction(String word,String fileType) throws Throwable {
        if(fileType.equalsIgnoreCase("Voice")){
            isElementDisplayed(Explore.playerExplore.findBy);
            mouseHoverToElement(Explore.yellowPointer.findBy);
            sleep(20);
        }
        if(fileType.equalsIgnoreCase("Email")){
            isElementNotDisplayed(Explore.playerExplore.findBy);
            verifyText(Explore.highlightedWord.findBy,word);
        }
        if(fileType.equalsIgnoreCase("Chat")){
            isElementNotDisplayed(Explore.playerExplore.findBy);
            verifyText(Explore.highlightedWord.findBy,word);
        }

    }

    public void iOpenInteractionForWord(String word) throws Throwable {
        verifyText(fetchAttribute(Explore.inputSearch.findBy,"placeholder"),"Enter Search Term");
        verifyAndEnterText(Explore.inputSearch.findBy,word);
        isElementDisplayed(Explore.linkClearSearchInput.findBy);
        sleep(3);
        pressEnterButton(Explore.inputSearch.findBy);
        sleep(10);
        verifyAndClick(listInteraction.get(0));
        sleep(20);
        verifyAndClick(Explore.linkClearSearchInput.findBy);
        isElementNotDisplayed(Explore.linkClearSearchInput.findBy);
        verifyAndEnterText(Explore.inputSearch.findBy,word);
        isElementDisplayed(Explore.linkClearSearchInput.findBy);
        pressEnterButton(Explore.inputSearch.findBy);
        for(int i=0;i<word.length();i++){
            pressSpecialKeys(Explore.inputSearch.findBy, Keys.BACK_SPACE);
        }
        isElementNotDisplayed(Explore.linkClearSearchInput.findBy);
        verifyAndEnterText(Explore.inputSearch.findBy,word);
        isElementDisplayed(Explore.linkClearSearchInput.findBy);
        pressEnterButton(Explore.inputSearch.findBy);
        WebElement element = driver.findElement(Explore.inputSearch.findBy);
        element.sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
        isElementNotDisplayed(Explore.linkClearSearchInput.findBy);
        iCreateFilterAs("Type","Voice");
        verifyAndEnterText(Explore.inputSearch.findBy,word);
        isElementDisplayed(Explore.linkClearSearchInput.findBy);
        sleep(3);
        pressEnterButton(Explore.inputSearch.findBy);
        sleep(10);
        verifyAndClick(listInteraction.get(0));
    }

    public void iOpenInteraction() throws Throwable {
        verifyAndClick(listInteraction.get(0));
        sleep(20);
    }

    public void iDownloadInteraction() throws Throwable {
        verifyAndClickViaJavaScript(Explore.buttonDownload.findBy);
        sleep(20);
    }

    public void iCheckFilterForDateFacet() throws Throwable {
        sleep(10);
        verifyAndClick(Explore.facetDate.findBy);
        //Last Hour
        verifyAndClick(Explore.dropDownLast.findBy);
        verifyAndClick(Explore.listValueLastHour.findBy);
        interactionCheck();
        clearSelection();
        //Last X Hour
        verifyAndClick(Explore.dropDownLast.findBy);
        verifyAndClick(Explore.listValueLastXHour.findBy);
        interactionCheck();
        clearSelection();
        //Last Day
        verifyAndClick(Explore.dropDownLast.findBy);
        verifyAndClick(Explore.listValueLastDay.findBy);
        interactionCheck();
        clearSelection();
        //Last Week
        verifyAndClick(Explore.dropDownLast.findBy);
        verifyAndClick(Explore.listValueLastWeek.findBy);
        interactionCheck();
        clearSelection();
        //Last 4 Weeks
        verifyAndClick(Explore.dropDownLast.findBy);
        verifyAndClick(Explore.listValueLast4Weeks.findBy);
        interactionCheck();
        clearSelection();
        //Date Between
        verifyAndClick(Explore.dropDownLast.findBy);
        verifyAndClick(Explore.listValueBetween.findBy);
        verifyAndClick(Explore.startCalendar.findBy);
        verifyAndClick(Explore.link1stDate.findBy);
        verifyAndClick(Explore.endCalendar.findBy);
        pressEnterButtonWithoutElement();
        interactionCheck();
        clearSelection();
        //Future Date
        verifyAndClick(Explore.dropDownLast.findBy);
        verifyAndClick(Explore.listValueBetween.findBy);
        verifyAndClick(Explore.startCalendar.findBy);
        verifyAndClick(Explore.buttonNextMonthFromCalendar.findBy);
        pressEnterButtonWithoutElement();
        verifyAndClick(Explore.endCalendar.findBy);
        verifyAndClick(Explore.buttonNextMonthToCalendar.findBy);
        verifyAndClick(Explore.buttonNextMonthToCalendar.findBy);
        pressEnterButtonWithoutElement();
        interactionCheck();
        clearSelection();
    }

    public void interactionCheck() throws Throwable {
        sleep(5);
        List li = driver.findElements(Explore.listInteraction1.findBy);
        if(li.size()>0)
        {
            isElementDisplayed(listInteraction.get(0));
        }else{
            verifyText(Explore.msgNoResultFound.findBy,"No result items found.");
        }
    }

    static String searchName;
    public void iValidateSaveSearchFunctionality() throws Throwable {
        verifyAndClick(Explore.buttonSearch.findBy);
        verifyAndClick(Explore.buttonNewSearch.findBy);
        searchName="Automation_"+getRandomStringString();
        verifyAndEnterText(Explore.textBoxNewSearch.findBy,searchName);
        verifyAndClick(Explore.buttonSaveSearch.findBy);
    }
    public void iValidateDefaultSearchFunctionality() throws Throwable {
        verifyAndClick(divXpath(searchName));
        isElementDisplayed(Explore.buttonOpenSearch.findBy);
        isElementDisplayed(Explore.buttonSaveSearch1.findBy);
        isElementDisplayed(Explore.buttonMoreSearch.findBy);
        verifyAndClick(Explore.buttonOpenSearch.findBy);
        verifyAndEnterText(Explore.inputSearch.findBy,"cat");
        sleep(3);
        pressEnterButton(Explore.inputSearch.findBy);
        sleep(10);
        verifyAndClick(divXpath(searchName));
        verifyAndClick(Explore.buttonSaveSearch1.findBy);
        verifyAndClick(divXpath(searchName));
        verifyAndClick(Explore.buttonMoreSearch.findBy);
        verifyAndClick(Explore.optionSetAsDefault.findBy);
    }
    public void iValidateDeleteSearchFunctionality() throws Throwable {
        commonSteps.logout();
        loginsteps.iLoginWithValidCredentials();
        navigation.iVerifyExplorerSubmenu();
        verifyText(Explore.labelSearchHeader.findBy,"Search - "+searchName);
        verifyAndClick(Explore.buttonSearch.findBy);
        verifyAndClick(divXpath(searchName));
        verifyAndClick(Explore.buttonMoreSearch.findBy);
        verifyAndClick(Explore.optionDelete.findBy);
        isElementNotDisplayed(divXpath(searchName));
    }



    public By divXpathForInteractionCount(String s) {  return By.xpath("//div[text()='" + s + "']/../div[2]");}
    public void iValidateNoOfInteractionsAccordingToSubmenu(String subMenu) throws IOException {
        if(fetchText(Explore.msgLoadedInteractions.findBy).contains(fetchText(divXpathForInteractionCount(subMenu)))){
            logPass(driver,"Interaction count is matched:"+fetchText(divXpathForInteractionCount(subMenu)));
        }else{
            logFail(driver,"Interaction count is matched:"+fetchText(divXpathForInteractionCount(subMenu)));
        }
    }

    public static String scenarioName;
    public void iAddScenario(String valueStatus,String valueRole) throws Throwable {
        sleep(15);
        verifyAndClick(Explore.buttonAddScenario.findBy);
        scenarioName = "Scenario "+getRandomStringString();
        verifyAndEnterText(Explore.inputScenarioName.findBy,scenarioName);
        verifyAndEnterText(Explore.inputScenarioDescription.findBy,"Demo Test");
        sleep(15);
        verifyAndClick(Explore.labelStatus.findBy);
        String scenarioID = "ID "+getRandomStringString();
        verifyAndEnterText(Explore.inputScenarioId.findBy,scenarioID);
        verifyAndClick(Explore.labelStatus.findBy);
        sleep(15);
        verifyText(Explore.labelStatus.findBy,"Status");
        verifyText(Explore.valueStatus.findBy,"Not Reviewed");
        verifyAndClick(Explore.valueStatus.findBy);
        verifyAndClick(divContainsTextXpath(valueStatus));
        verifyAndClick(Explore.labelStatus.findBy);
        sleep(15);
        //verifyAndClickViaJavaScript(Explore.valueRole.findBy);
        WebElement element1 = driver.findElement(By.xpath("//div[@role='combobox']"));
        element1.click();
        sleep(5);
        verifyAndClick(liContainsTextXpath(valueRole));
        verifyAndClick(Explore.labelStatus.findBy);
        sleep(15);
        verifyAndClick(Explore.buttonAddComment.findBy);
        sleep(5);
        WebElement element = driver.findElement(By.xpath("//textarea[@class='newCommentText']"));
        element.sendKeys("Test Comment");
        verifyAndClick(Explore.labelComments.findBy);
        sleep(5);
    }

    public static String countOfInteractions;
    public void iAddInteractionsInScenario(String countScenario) throws Throwable {
        countOfInteractions=countScenario;
        verifyAndClick(Explore.buttonExplore.findBy);
        switch(countScenario){
            case "1": {
                iAddInteraction("Chat");
            }
            break;
            case "2":{
                iAddInteraction("Chat");
                iAddInteraction("Email");
            }
            break;
            case "3":{
                iAddInteraction("Chat");
                iAddInteraction("Email");
                iAddInteraction("Voice");
            }
            break;
            default: iAddInteraction("Chat");
        }
    }

    public void iAddInteraction(String typeOfInteraction) throws Throwable {
        verifyAndEnterText(Explore.inputSearch.findBy,typeOfInteraction);
        sleep(3);
        pressEnterButton(Explore.inputSearch.findBy);
        sleep(5);
        verifyAndClick(Explore.checkbox1stInteraction.findBy);
        sleep(15);
    }

    public void iValidateCountOfInteractions(String countScenario) throws Throwable {
        verifyAndClick(Explore.buttonScenarios.findBy);
        verifyAndClick(Explore.list1stScenarios.findBy);
        sleep(30);
        if(countScenario.equalsIgnoreCase(String.valueOf(listPlayerCount.size()))){
            logPass(driver,"Interaction count is mateched with "+listPlayerCount.size());
        }else{
            logFail(driver,"Interaction count is not mateched with "+listPlayerCount.size());
        }
        sleep(10);
    }

    public void iDoInteractionValidation() throws Throwable {
        voicePlayerVerify();
    }

    public void iVerifyScenarioItemWithInvestigatePage() throws Throwable {
        sleep(30);
        refreshBrowser();
        changeFrameWithFrameName("frmDetailsSingleView");
        sleep(5);
        changeFrameWithFrameName("cs_frame");
        sleep(5);
        verifyAndClickViaJavaScript(Explore.buttonScenario.findBy);
        sleep(15);
        WebElement element = driver.findElement(By.xpath("//div[text()='"+scenarioName+"']/../../div[@id='interactionCount']"));
        verifyContainsText(element,countOfInteractions);
        verifyAndClick(element);
        sleep(10);
        if(countOfInteractions.equalsIgnoreCase(String.valueOf(listPlayerCount.size()))){
            logPass(driver,"Interaction count is mateched with "+listPlayerCount.size());
        }else{
            logFail(driver,"Interaction count is not mateched with "+listPlayerCount.size());
        }
    }

    public void clearSelection() throws Throwable {
        verifyAndClick(Explore.linkClearSelection.findBy);
        interactionCheck();
    }

    public void iCreateWorkItem() throws Throwable {
        sleep(30);
        verifyAndClick(Explore.checkbox1stInteraction1.findBy);
        verifyAndClick(Explore.buttonCreateWorkItem.findBy);
        verifyText(Explore.labelChooseQueue.findBy,"Choose Queue");
        verifyText(Explore.msgChooseQueue.findBy,"Create 1 Work Item in Queue:");
        verifyAndClick(Explore.dropdownWorkItem.findBy);
        verifyAndClick(Explore.dropdownApacDemo.findBy);
        verifyAndClick(Explore.buttonConfirm.findBy);
        verifyContainsText(Explore.notificationText.findBy,"1 interaction successfully added to queue test1");
    }

    public void iValidateSorting(String sortType) throws Throwable {
        sleep(30);
        verifyAndClick(Explore.dropdownSort.findBy);
        if(sortType.equalsIgnoreCase("descending")){
            verifyAndClickViaJavaScript(Explore.dropdownDescending.findBy);
        }
        if(sortType.equalsIgnoreCase("ascending")){
            verifyAndClickViaJavaScript(Explore.dropdownAscending.findBy);
        }
        sleep(15);
        verifyAndClick(Explore.listInteraction1.findBy);
        sleep(5);
        String date1 =fetchText(Explore.valueDateExplore.findBy);
        LocalDateTime date2 = stringToDateConvert(date1);
        sleep(10);
        verifyAndClickViaJavaScript(Explore.buttonCloseDetailsPan.findBy);
        verifyAndClick(Explore.listInteraction2.findBy);
        sleep(5);
        String date3 =fetchText(Explore.valueDateExplore.findBy);
        LocalDateTime date4 = stringToDateConvert(date3);
        sleep(10);
        verifyAndClickViaJavaScript(Explore.buttonCloseDetailsPan.findBy);
        if(sortType.equalsIgnoreCase("descending")){
            if(date2.isAfter(date4)){
                logPass(driver,"Latest Time:"+date2+" Previous Time:"+date4);
            }else{
                logFail(driver,"Latest Time:"+date2+" Previous Time:"+date4);
            }
        }
        if(sortType.equalsIgnoreCase("ascending")){
            if(date2.isBefore(date4)){
                logPass(driver,"Latest Time:"+date4+" Previous Time:"+date2);
            }else{
                logFail(driver,"Latest Time:"+date4+" Previous Time:"+date2);
            }
        }
    }

}