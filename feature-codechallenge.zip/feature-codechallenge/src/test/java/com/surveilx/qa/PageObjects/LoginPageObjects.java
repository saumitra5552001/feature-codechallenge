package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class LoginPageObjects extends CommonFunctions {

    public LoginPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }
    private enum LOGIN_PORTAL{
        USERNAMEXPATH(By.xpath("//input[@id='j_username_1']")),
        LOGINBUTTON(By.id("textButton_btnLogin")),
        PASSWORDXPATH(By.xpath("//input[@id='j_password']")),
        imageLoginPage(By.xpath("//img[contains(@src,'loginPageLogo')]")),
        ;
        private By findBy;

        LOGIN_PORTAL(By locator) {
            this.findBy = locator;
        }
    }

    @FindBy(id = "rcm-loginPageHeader")
    public WebElement loginPageHeader;

    @FindBy(id = "rcm-loginVersionHeader")
    public WebElement applicationVersionLabel;

    @FindBy(id = "rcm-loginUsernameLabel")
    public WebElement usernameLabel;

    @FindBy(id = "rcm-loginPasswordLabel")
    public WebElement passwordLabel;

    @FindBy(id = "rcm-loginCopyright")
    public WebElement messageCopyRight;

    @FindBy(xpath = "//*[@id='j_username_1']")
    public WebElement textBoxUserName;

    public void validateLoginPageElements() throws Throwable
    {
        isElementDisplayed(LOGIN_PORTAL.imageLoginPage.findBy);
        verifyText(loginPageHeader, "ActOne | Case Manager");
        verifyText(applicationVersionLabel, jsonRead.readStringFromDataJSON("AppVersion"));
        verifyText(usernameLabel, "User Name");
        verifyText(passwordLabel, "Password");
        verifyText(LOGIN_PORTAL.LOGINBUTTON.findBy, "Login");
        System.out.println(fetchCSSValue(LOGIN_PORTAL.LOGINBUTTON.findBy,"font-family"));
        verifyText(fetchPageTitle(),"[SURVEIL-X]");
        verifyText(messageCopyRight, "Copyright 2004 - 2021 Actimize Ltd. All rights reserved. Protected by one or more of the US patents listed at www.nice.com/Patents");
    }

    public void enterUsername(String username) throws IOException {
        verifyAndEnterText(textBoxUserName, username);
    }

    public void enterPassword(String password) throws IOException {
        verifyAndEnterText(LOGIN_PORTAL.PASSWORDXPATH.findBy, password);
    }

    public void clickLoginButton() throws Throwable {
        verifyAndClickViaJavaScript(LOGIN_PORTAL.LOGINBUTTON.findBy);
    }
}
