package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.StepDefinition.CommonSteps;
import com.surveilx.qa.StepDefinition.LoginSteps;
import com.surveilx.qa.StepDefinition.NavigationSteps;
import com.surveilx.qa.StepDefinition.WorkItemsSteps;
import org.apache.logging.log4j.core.util.Assert;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class WorkbenchWorkItemsPageObjects extends CommonFunctions {

    public WorkbenchWorkItemsPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    LoginSteps loginsteps = new LoginSteps();
    NavigationSteps navigation = new NavigationSteps();
    CommonSteps commonSteps = new CommonSteps();
    PageObject pom = new PageObject(driver);
    String clickedProductSymbolID;
    String newScoreInput;
    String changeItemUse_BUWindow;

    private enum WorkbenchWorkItems {
        /* MSC tab icons on Alerts Details page' */
        alertDetailsPageIconChangeStep(By.xpath(".//i[@id='icon_change_step']")),
        alertDetailsPageIconAssign(By.xpath(".//i[@id='icon_assign']")),
        alertDetailsPageIconAddNote(By.xpath(".//i[@id='icon_add_notes']")),
        alertDetailsPageIconViewNotes(By.xpath(".//i[@id='icon_view_notes']")),
        alertDetailsPageIconOpenWorkspace(By.xpath(".//i[@id='icon_open_workspace']")),
        alertDetailsPageIconAttachments(By.xpath(".//i[@id='icon_open_attachments']")),
        alertDetailsPageIconRFI(By.xpath(".//i[@id='icon_rfi']")),
        alertDetailsPageIconExport(By.xpath(".//i[@id='icon_export']")),
        alertDetailsPageIconNewItem(By.xpath(".//i[@id='icon_create_item']")),
        alertDetailsPageIconForms(By.xpath(".//i[@id='icon_forms']")),
        alertDetailsPageIconAddCase(By.xpath(".//i[@id='icon_add_case']")),
        alertDetailsPageIconMoreOption(By.xpath(".//a[@id='icon_default_a']")),
        alertDetailsPageIconEditItem(By.xpath(".//i[@id='icon_edit_item']")),
        alertDetailsPageIconChangeStepDeadline(By.xpath(".//a[@id='icon_change_deadline_a']")),
        alertDetailsPageIconChangeScore(By.xpath(".//a[@id='icon_change_score_a']")),
        alertDetailsPageIconChangePriority(By.xpath(".//a[@id='icon_change_priority_a']")),
        alertDetailsPageIconViewHistory(By.xpath(".//a[@id='icon_view_history_a']")),
        alertDetailsPageIconDelete(By.xpath(".//a[@id='icon_delete_item_a']")),
        alertDetailsPageEntityInsights(By.xpath(".//li[@id='singleViewBtn']")),
        alertDetailsPageOptionShowAsPDF(By.xpath(".//a[@id='icon_pdf_a']")),
        //alertDetailsPageOptionShowAsPDF(By.xpath(".//i[contains(text(),'Show as PDF')]")),


        //recentAlertId (By.xpath("(//td[@class='ui-ellipsis clsGridReadRow']/span/a)[1]")),
        recentAlertId(By.xpath("//td[@id='cell_1_3']/span/a")),
        //recentAlertId (By.xpath("(//td[@class='ui-ellipsis clsGridReadRow']/span/)")),

        latestProductSymbol(By.xpath("(.//td[@class='ui-ellipsis clsGridReadRow']/span/a)[2]")),
        exportButtonOnAlertTransactions(By.xpath(".//td[@id='textButton_btnExport']")),
        HeaderOnNewWindow(By.xpath(".//div[@id='dialogHeader']")),
        HeaderOnNewWindowViewNote(By.xpath(".//div[@id='dialogHeader']")),
        dropDownOnAddNoteWindow(By.xpath(".//select[@id='noteModelPreDefinedNotes']")),
        textAreaToAddNote(By.xpath(".//body[@id='tinymce']")),
        viewNotes(By.xpath(".//td[@id='cell_1_1']")),
        viewHistoryLine(By.xpath(".//td[@id='cell_1_1']")),
        oKButtonOnAddNotePage(By.xpath(".//td[@id='textButton_addNoteDialog_SubmitButton']")),
        saveButtonOnEditItemPage(By.xpath(".//td[@id='textButton_addNoteDialog_SubmitButton']")),
        oKButtonOnChangeScorePage(By.xpath(".//td[@id='textButton__SubmitButton']")),
        okButtonOnBusinessUnitExplorer(By.xpath(".//td[@id='textButton__SubmitButton']")),
        oKButtonOnSelectUserPage(By.xpath(".//td[@id='textButton__SubmitButton']")),
        addToCaseButton(By.xpath(".//td[@id='textButton__SubmitButton']")),
        yesButtonOnDeletePage(By.xpath(".//td[@id='textButton__SubmitButton']")),
        oKButtonOnChangeItemUserBUPage(By.xpath(".//td[@id='textButton_changeAlertUser_SubmitButton']")),
        oKButtonOnChangeStepPage(By.xpath(".//td[@id='textButton_changeStatusDialog_SubmitButton']")),
        closeButtonOnViewNotesPage(By.xpath(".//td[@id='textButton_viewNotesPopup_OkButton']")),
        closeButtonOnViewHistoryPage(By.xpath(".//td[@id='textButton_generalViewAudits_OkButton']")),
        closeButtonOnErrorPage(By.xpath(".//td[@id='textButton_close_button']")),
        recentUpdatedHistoryValue(By.xpath(".//div[@id='auditContent']")),
        recentHistoryLineValue(By.xpath(".//td[@id='cell_1_4']")),
        labelAssignToAnotherBusinessUnit(By.xpath("(.//font[@class='clsBoldText'])[1]")),
        labelAssignToAnotherUser(By.xpath("(.//font[@class='clsBoldText'])[2]")),
        buPickerImgOnChangeItemUserPage(By.xpath(".//span[@id='buPickerImg']")),
        userPickerImgOnChangeItemUserPage(By.xpath(".//span[@id='userPickerImg']")),
        businessUnitHierarchyRootAnchor(By.xpath(".//a[@id='root-anchor']")),
        radioButtonAssignToUser(By.xpath(".//input[@id='notme']")),
        assignToUserTextBox(By.xpath(".//input[@id='user_name']")),
        labelEnterSearchText(By.xpath(".//td[@class='clsText']")),
        enterSearchTextBox(By.xpath(".//input[@id='ownerName']")),
        goButtonOnSelectUserPage(By.xpath("(.//td[@id='textButton_'])[2]")),
        availableUserOptionsOnSelectUserPage(By.xpath(".//select[@id='user']")),
        changeStatusCurrentStatus(By.xpath("(.//td[@class='changeStatusCurrentStatus'])[1]")),
        nextStepDropDownOnChangeStep(By.xpath(".//div[@id='statusesSelectText']")),
        selectedStatusInProgress(By.xpath("(.//td[@id='statusesDropDownColumn3'])[2]")),
        selectedStatusResetToReady(By.xpath("(.//td[@id='statusesDropDownColumn3'])[4]")),
        newScoreText(By.xpath(".//td[@class='clsText']")),
        newScoreTextBox(By.xpath(".//input[@id='newScore']")),
        stepDetailsOnAlertDetails(By.xpath("(.//span[@class='ng-binding ng-scope'])[7]")),
        changeStepDeadlineBoxHeader(By.xpath(".//div[@class='qDialogTitle']")),
        changeStepDeadlineNewDate(By.xpath("(.//div[@class='q-field__control-container col relative-position row no-wrap q-anchor--skip']/input)[2]")),
        addToNewCaseRadioButton(By.xpath(".//input[@id='newCase']")),
        finishButtonOnAddToNewCase(By.xpath(".//td[@id='textButton_finishButton']")),
        alertNameOnAddToNewCase(By.xpath(".//input[@id='alertName']")),
        openItemButtonOnSuccessPage(By.xpath(".//td[@id='textButton_open_alert_button']")),
        selectNewPriority(By.xpath(".//select[@id='priorityIdentifier']")),
        okButtonOnChangePriority(By.xpath(".//td[@id='textButton_changePriorityDialog_SubmitButton']")),
        priorityOnAlertDetailsPage(By.xpath("(.//span[@class='ng-binding ng-scope'])[4]")),
        caseItemSavedMessageOnSuccessPage(By.xpath(".//td[@class='clsBoldText']")),
        errorTextOnErrorPage(By.xpath(".//td[@class='errortext']")),
        iconActionUpOnItemDetailsPage(By.xpath(".//i[@class='icon actions-up_light']")),
        checkOrSelectCaseItemAlert(By.xpath(".//input[@id='jqg_alertsModel_20812']")),
        selectOpenedCaseItem(By.xpath(".//td[@id='cell_1_7']")),
        dataEntryOptionOnEditItem(By.xpath(".//td[@id='part2_text']")),
        localAlertTimeOnEditItem(By.xpath(".//input[@id='dateField_custField_ACT_TC_cd17']")),
        localAlertDateOnItemDetailsPage(By.xpath("(.//span[@class='ng-binding ng-scope'])[5]")),
        closebittonOnChangeStepDeadlineUpdateFailed(By.xpath(".//span[@class='q-btn__content text-center col items-center q-anchor--skip justify-center row']")),

        //alertSummaryDetails (By.xpath("//div[@class='sectionTitle semi-bold textSmallFont']")),

        /* Common attribute for all alert types */
        labelSummaryProductName(By.xpath("(//div[contains(text(),'Product Name')])[1]")),
        labelSummaryProductID(By.xpath("(//div[contains(text(),'Product ID')])[1]")),
        labelSummaryAccountID(By.xpath("(//div[contains(text(),'Account ID')])[1]")),
        labelSummaryProductSymbol(By.xpath("(//div[contains(text(),'Product Symbol')])[1]")),
        labelSummaryExchange(By.xpath("(//div[contains(text(),'Exchange')])[1]")),
        valueSummaryProductName(By.xpath("(//div[contains(text(),'Product Name')])[1]/../../div[2]/div[1]")),
        valueSummaryProductID(By.xpath("(//div[contains(text(),'Product ID')])[1]/../../div[2]/div[2]")),
        valueSummaryAccountID(By.xpath("(//div[contains(text(),'Account ID')])[1]/../../div[2]/div[3]")),
        valueSummaryProductSymbol(By.xpath("(//div[contains(text(),'Product Symbol')])[1]/../../div[2]/div[4]")),
        valueSummaryExchange(By.xpath("(//div[contains(text(),'Exchange')])[1]/../../div[2]/div[5]")),

        /* Specific attribute for alert type 'MSC Markup Markdown' */
        labelSummaryOffMarketType(By.xpath("(//div[contains(text(),'Off Market Type')])[1]")),
        labelSummaryPercentChange(By.xpath("(//div[contains(text(),'Percent Change')])[1]")),
        labelSummaryEvaluatedPrice(By.xpath("(//div[contains(text(),'Evaluated Price')])[1]")),
        labelSummaryThreshold(By.xpath("//div[contains(@title,'Threshold')][1]")),
        labelSummaryMasterAccount(By.xpath("(//div[contains(text(),'Master Account')])[1]")),
        labelSummaryTicker(By.xpath("(//div[contains(text(),'Ticker')])[1]")),
        labelSummaryEvaluatedBid(By.xpath("(//div[contains(text(),'Evaluated Bid')])[1]")),
        labelSummaryEvaluatedAsk(By.xpath("(//div[contains(text(),'Evaluated Ask')])[1]")),
        labelSummaryPriceThreshold(By.xpath("(//div[contains(@title,'Price Threshold')][1]")),
        labelSummaryLastTrxUTCDateTime(By.xpath("(//div[contains(text(),'Last Trx UTC Date Time')])[1]")),
        labelSummaryLastTrxLocalDateTime(By.xpath("(//div[contains(text(),'Last Trx Local Date Time')])[1]")),
        valueSummaryThreshold(By.xpath("(//div[contains(text(),'Threshold')])[1]/../../div[2]/div[1]")),
        valueSummaryMasterAccount(By.xpath("(//div[contains(text(),'Master Account')])[1]/../../div[2]/div[2]")),
        valueSummaryTicker(By.xpath("(//div[contains(text(),'Ticker')])[1]/../../div[2]/div[3]")),
        valueSummaryEvaluatedBid(By.xpath("(//div[contains(text(),'Evaluated Bid')])[1]/../../div[2]/div[4]")),
        valueSummaryEvaluatedAsk(By.xpath("(//div[contains(text(),'Evaluated Ask')])[1]/../../div[2]/div[5]")),
        valueSummaryOffMarketType(By.xpath("(//div[contains(text(),'Off Market Type')])[1]/../../div[2]/div[6]")),
        valueSummaryPercentChange(By.xpath("(//div[contains(text(),'Percent Change')])[1]/../../div[2]/div[7]")),
        valueSummaryEvaluatedPrice(By.xpath("(//div[contains(text(),'Evaluated Price')])[1]/../../div[2]/div[8]")),
        valueSummaryPriceThreshold(By.xpath("(//div[contains(text(),'Price Threshold')])[1]/../../div[2]/div[6]")),
        valueSummaryLastTrxUTCDateTime(By.xpath("(//div[contains(text(),'Last Trx UTC Date Time')])[1]/../../div[2]/div[7]")),
        valueSummaryLastTrxLocalDateTime(By.xpath("(//div[contains(text(),'Last Trx Local Date Time')])[1]/../../div[2]/div[8]")),

        /* Specific attribute for alert type 'MSC Ramping' */
        labelPreviousBenchmarkPrice(By.xpath("//div[contains(text(),'Previous Benchmark Price')]")),
        labelOpenBenchmarkPrice(By.xpath("//div[contains(text(),'Open Benchmark Price')]")),
        labelPreviousPercentChange(By.xpath("//div[contains(text(),'Previous Percent Change')]")),
        labelOpenPercentChange(By.xpath("//div[contains(text(),'Open Percent Change')]")),
        labelRampingType(By.xpath("//div[contains(text(),'Ramping Type')]")),
        labelRampingPercentChange(By.xpath("//div[contains(text(),'Ramping Percent Change')]")),
        labelRampingBenchmarkPrice(By.xpath("//div[contains(text(),'Ramping Benchmark Price')]")),
        labelRampingThreshold(By.xpath("(//div[contains(text(),'Ramping Threshold')])[1]")),
        labelDTAIncrease(By.xpath("(//div[contains(text(),'DTA Increase')])[1]")),
        labelRampingThresholdOpeningClose(By.xpath("//div[contains(text(),'Ramping Threshold (Opening Price)')]")),
        labelRampingThresholdPreviousClose(By.xpath("//div[contains(text(),'Ramping Threshold (Previous Close)')]")),
        labelLastTrxUTCDateTime(By.xpath("(//div[contains(text(),'Last Trx UTC Date Time')])[1]")),
        labelLastTrxLocalDateTime(By.xpath("(//div[contains(text(),'Last Trx Local Date Time')])[1]")),
        valueOpenBenchmarkPrice(By.xpath("//div[contains(text(),'Open Benchmark Price')]/../../div[2]/div[6]")),
        valuePreviousBenchmarkPrice(By.xpath("//div[contains(text(),'Previous Benchmark Price')]/../../div[2]/div[6]")),
        valuePreviousPercentChange(By.xpath("//div[contains(text(),'Previous Percent Change')]/../../div[2]/div[7]")),
        valueOpenPercentChange(By.xpath("//div[contains(text(),'Open Percent Change')]/../../div[2]/div[7]")),
        valueRampingType(By.xpath("//div[contains(text(),'Ramping Type')]/../../div[2]/div[8]")),
        valueRampingPercentChange(By.xpath("//div[contains(text(),'Ramping Percent Change')]/../../div[2]/div[1]")),
        valueRampingBenchmarkPrice(By.xpath("//div[contains(text(),'Ramping Benchmark Price')]/../../div[2]/div[2]")),
        valueRampingThreshold(By.xpath("(//div[contains(text(),'Ramping Threshold')])[1]/../../div[2]/div[3]")),
        valueDTAIncrease(By.xpath("(//div[contains(text(),'DTA Increase')])[1]/../../div[2]/div[4]")),
        valueRampingThresholdPreviousClose(By.xpath("//div[contains(text(),'Ramping Threshold (Previous Close)')]/../../div[2]/div[5]")),
        valueRampingThresholdOpeningPrice(By.xpath("//div[contains(text(),'Ramping Threshold (Opening Price)')]/../../div[2]/div[5]")),
        valueLastTrxUTCDateTime(By.xpath("(//div[contains(text(),'Last Trx UTC Date Time')])[1]/../../div[2]/div[6]")),
        valueLastTrxLocalDateTime(By.xpath("(//div[contains(text(),'Last Trx Local Date Time')])[1]/../../div[2]/div[7]")),

        labelDescription(By.xpath("//span[contains(text(),'Description')]")),
        valueDescription(By.xpath("//span[contains(text(),'Description')]/../../div[2]")),
        aggregatedExecutionsByAccountsTag(By.xpath(".//span[@id='section-exec_display_agg_by_product-static-title']")),
        crossProductTransactionsTag(By.xpath(".//span[@id='section-crossProductTransactions-static-title']")),

        /* Specific attribute for alert type 'MSC Wash' */
        //labelPreviousBenchmarkPrice (By.xpath("//div[contains(text(),'Previous Benchmark Price')]")),

        ;
        private By findBy;

        WorkbenchWorkItems(By locator) {
            this.findBy = locator;
        }
    }


    @FindBy(xpath = "(.//span[@id='activities-rulename-0'])[1]")
    public WebElement tradingActivityDetails;

    @FindBy(xpath = "(.//span[@id='activities-rulename-0'])[2]")
    public WebElement markUpMarkDownAnalysisDetails1;

    @FindBy(xpath = "(.//span[@id='activities-rulename-1'])[1]")
    public WebElement markUpMarkDownAnalysisDetails2;

    @FindBy(xpath = "(.//span[@id='activities-rulename-0'])[3]")
    public WebElement thresholdLockBackPeriodDetails;

    @FindBy(xpath = "(.//span[@id='activities-rulename-1'])[2]")
    public WebElement thresholdPriceThresholdDetails;

    @FindBy(xpath = ".//span[contains(text(),'Thresholds')]")
    public WebElement thresholdTabOnAnalytics;

    @FindBy(xpath = ".//span[contains(text(),'Thresholds')]")
    public WebElement fetchTotalNumberOfWorkItems;

    @FindBy(xpath = "(.//span[@id='activities-rulename-0'])[1]")
    public WebElement tradePriceSpikeAnalysis;

    @FindBy(xpath = "(.//span[@id='activities-rulename-1'])[1]")
    public WebElement dTAIncrease;

    @FindBy(xpath = "(.//span[@id='activities-rulename-0'])[2]")
    public WebElement thresholdDTAIncrease;

    @FindBy(xpath = "(.//span[@id='activities-rulename-1'])[2]")
    public WebElement rampingThresholdOpeningPrice;

    @FindBy(xpath = "(.//span[@id='activities-rulename-2'])[1]")
    public WebElement rampingThresholdPreviousClose;

    @FindBy(xpath = "(.//a[@class='clsGridLinkRenderer'])[1]")
    public WebElement valueOfLatestProductSymbol;

    @FindBy(xpath = "(.//span[@class='investigationQueryTermValue'])[3]")
    public WebElement productSymbolValueOnDartPage;

    @FindBy(xpath = ".//span[@class='rightHeader textSmallFont']/span[6]")
    public WebElement scoreOnItemDetailsPage;

    @FindBy(xpath = ".//input[@id='dateField_custField_ACT_TC_cd17']")
    public WebElement localAlertTimeOnEditItem;


    public void clickOnAlertId() throws Throwable {
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.recentAlertId.findBy);
    }

    public void clickOnProductSymbol() throws Throwable {
        sleep(3);
        clickedProductSymbolID = fetchText(valueOfLatestProductSymbol);
        verifyAndClick(WorkbenchWorkItems.latestProductSymbol.findBy);
    }

    public void verifyProductSymbolValueOnDartPage() throws Throwable {
        sleep(3);
        verifyContainsText(productSymbolValueOnDartPage, "SYMBOL_");
        String fetchedProductSymbolValue = fetchText(productSymbolValueOnDartPage);
        logInfo("Product Symbol Value On Dart Page" + fetchedProductSymbolValue);
        assertEquals(clickedProductSymbolID, fetchedProductSymbolValue, "Product Symbol Value On Dart Page is not matching");

    }

    public void validateWorkItemMSCSummaryExpandedSection() throws Throwable {
        //verifyAndClick(WorkbenchWorkItems.imageSummaryExpanded.findBy);
        verifyText(WorkbenchWorkItems.labelSummaryProductName.findBy, "Product Name:");
        verifyText(WorkbenchWorkItems.labelSummaryProductID.findBy, "Product ID:");
        verifyText(WorkbenchWorkItems.labelSummaryAccountID.findBy, "Account ID:");
        verifyText(WorkbenchWorkItems.labelSummaryProductSymbol.findBy, "Product Symbol:");
        verifyText(WorkbenchWorkItems.labelSummaryExchange.findBy, "Exchange:");
        /*verifyText(WorkbenchWorkItems.labelSummaryOffMarketType.findBy, "Off Market Type:");
        verifyText(WorkbenchWorkItems.labelSummaryPercentChange.findBy, "Percent Change:");
        verifyText(WorkbenchWorkItems.labelSummaryEvaluatedPrice.findBy, "Evaluated Price:");
        verifyText(WorkbenchWorkItems.labelSummaryThreshold.findBy, "Threshold:");
        verifyText(WorkbenchWorkItems.labelSummaryMasterAccount.findBy, "Master Account:");
        verifyText(WorkbenchWorkItems.labelSummaryTicker.findBy, "Ticker:");
        verifyText(WorkbenchWorkItems.labelSummaryEvaluatedBid.findBy, "Evaluated Bid:");
        verifyText(WorkbenchWorkItems.labelSummaryEvaluatedAsk.findBy, "Evaluated Ask:");
        verifyText(WorkbenchWorkItems.labelSummaryPriceThreshold.findBy, "Price Threshold:");
        verifyText(WorkbenchWorkItems.labelSummaryLastTrxUTCDateTime.findBy, "Last Trx UTC Date Time:");
        verifyText(WorkbenchWorkItems.labelSummaryLastTrxLocalDateTime.findBy, "Last Trx Local Date Time:");*/
        sleep(1);

        /*verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryThreshold.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryMasterAccount.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryTicker.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryEvaluatedBid.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryOffMarketType.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryEvaluatedAsk.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryPercentChange.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryEvaluatedPrice.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryPriceThreshold.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryLastTrxUTCDateTime.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryLastTrxLocalDateTime.findBy);*/

        /* Specific attribute for alert type 'MSC Ramping' */
        //verifyText(WorkbenchWorkItems.labelPreviousBenchmarkPrice.findBy, "Previous Benchmark Price:");
        //verifyText(WorkbenchWorkItems.labelPreviousBenchmarkPrice.findBy, "Previous Benchmark Price:");
        //verifyText(WorkbenchWorkItems.labelPreviousPercentChange.findBy, "Previous Percent Change:");
        //verifyText(WorkbenchWorkItems.labelPreviousPercentChange.findBy, "Previous Percent Change:");
        verifyText(WorkbenchWorkItems.labelRampingType.findBy, "Ramping Type:");
        verifyText(WorkbenchWorkItems.labelRampingPercentChange.findBy, "Ramping Percent Change:");
        verifyText(WorkbenchWorkItems.labelRampingBenchmarkPrice.findBy, "Ramping Benchmark Price:");
        verifyText(WorkbenchWorkItems.labelRampingThreshold.findBy, "Ramping Threshold:");
        verifyText(WorkbenchWorkItems.labelDTAIncrease.findBy, "DTA Increase:");
        //verifyText(WorkbenchWorkItems.labelRampingThresholdPreviousClose.findBy, "Ramping Threshold (Previous Close):");
        //verifyText(WorkbenchWorkItems.labelRampingThresholdPreviousClose.findBy, "Ramping Threshold (Previous Close):");
        verifyText(WorkbenchWorkItems.labelLastTrxUTCDateTime.findBy, "Last Trx UTC Date Time:");
        verifyText(WorkbenchWorkItems.labelLastTrxLocalDateTime.findBy, "Last Trx Local Date Time:");
        verifyText(WorkbenchWorkItems.labelDescription.findBy, "Description");

        //verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryProductName.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryProductID.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryAccountID.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryProductSymbol.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueSummaryExchange.findBy);

        /* Values for Specific attribute-for alert type 'MSC Ramping' */
        //verifyTextWithNonEmptyString(WorkbenchWorkItems.valuePreviousBenchmarkPrice.findBy);
        //verifyTextWithNonEmptyString(WorkbenchWorkItems.valuePreviousPercentChange.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueRampingType.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueRampingPercentChange.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueRampingBenchmarkPrice.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueRampingThreshold.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueDTAIncrease.findBy);
        //verifyTextWithNonEmptyString(WorkbenchWorkItems.valueRampingThresholdPreviousClose.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueLastTrxUTCDateTime.findBy);
        verifyTextWithNonEmptyString(WorkbenchWorkItems.valueLastTrxLocalDateTime.findBy);
        //verifyTextWithNonEmptyString(WorkbenchWorkItems.valueDescription.findBy);
    }

    public void validateMSCTabOnAlertDetailsPage() throws Throwable {
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconChangeStep.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconAssign.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconAddNote.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconViewNotes.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconOpenWorkspace.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconAttachments.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconRFI.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconExport.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconNewItem.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconForms.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconAddCase.findBy);
        //isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
    }


    public void validateMoreOptionOnAlertDetailsPage() throws Throwable {
        //isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconEditItem.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconChangeStepDeadline.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconChangeScore.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconChangePriority.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconViewHistory.findBy);
        isElementDisplayedAndEnabled(WorkbenchWorkItems.alertDetailsPageIconDelete.findBy);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageEntityInsights.findBy);
    }

    public void validateTagsUnderTransactionsOfRelatedProducts() throws Throwable {
        verifyText(WorkbenchWorkItems.aggregatedExecutionsByAccountsTag.findBy, "Aggregated Executions by Accounts");
        verifyText(WorkbenchWorkItems.crossProductTransactionsTag.findBy, "Cross Product Transactions");
    }

    public void clickAndVerifyExportButtonFunctionality() throws Throwable {
        isElementDisplayedAndEnabled(WorkbenchWorkItems.exportButtonOnAlertTransactions.findBy);
        verifyAndClick(WorkbenchWorkItems.exportButtonOnAlertTransactions.findBy);
        sleep(5);
        waitUntilFileToDownloadInSystem(".csv");
        if (isFileDownloadedInSystem(".csv") == true) {
            logPass(driver, "File is downloaded");
        } else {
            logFail(driver, "File is not downloaded");
        }


    }

    public void verifyScoreOnItemDetailsPage() throws Throwable {
        verifyContainsText(scoreOnItemDetailsPage, "Score ");
        String actualScoreValue = fetchText(scoreOnItemDetailsPage);
        String targetedScoreValue = actualScoreValue.replace("Score ", "");
        int scoreValue = Integer.valueOf(targetedScoreValue);
        if (scoreValue >= 0 && scoreValue <= 100) {
            logPass(driver, "Alert Id score value on Item Details page is positive and less than 100");
        } else {
            logFail(driver, "Alert Id score value is invalid-Not in range of [0-100]");
        }
        sleep(3);
    }

    public int fetchCurrentScoreForClickedAlertId() throws Throwable {
        verifyContainsText(scoreOnItemDetailsPage, "Score ");
        String actualScoreValue = fetchText(scoreOnItemDetailsPage);
        String targetedScoreValue = actualScoreValue.replace("Score ", "");
        return Integer.valueOf(targetedScoreValue);
    }


    public void clickOnAddNoteIcon() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconAddNote.findBy);
        sleep(2);
    }


    public void clickOnViewNotesIcon() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconViewNotes.findBy);
        sleep(2);
    }


    public void validateAddNoteWithoutAddingAnyNote() throws Throwable {
        verifyAndClickForChildWindow(WorkbenchWorkItems.oKButtonOnAddNotePage.findBy);
        sleep(2);
        switchAndAcceptAlert();
        sleep(2);
    }

    public void verifyTheHeaderOfAddNoteNewWindow() throws Throwable {
        switchToNewWindow();
        driver.manage().window().maximize();
        sleep(4);
        getPageTitle(jsonRead.readStringFromDataJSON("addNoteWindow"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Add Note");
        sleep(2);
    }


    public void verifyTheHeaderOfViewNotesNewWindow() throws Throwable {
        switchToNewWindow();
        driver.manage().window().maximize();
        sleep(4);
        getPageTitle(jsonRead.readStringFromDataJSON("viewNotesWindow"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "View Notes");
        sleep(2);
    }


    public void selectsFreeTextFromTheDropdown() throws Throwable {
        sleep(4);
        selectElementFromDropdown(WorkbenchWorkItems.dropDownOnAddNoteWindow.findBy, " [ Free Text ] ");
        sleep(2);
    }

    public void addNoteInTextArea() throws Throwable {
        changeFrameWithFrameName("noteModelFreeTextNote_ifr");
        verifyAndEnterText(WorkbenchWorkItems.textAreaToAddNote.findBy, "This note is added by an automated script. [TEST SCRIPT]");
        sleep(2);
        switchToDefaultFrame();
        sleep(2);
        verifyAndClickForChildWindow(WorkbenchWorkItems.oKButtonOnAddNotePage.findBy);
        sleep(2);
        //switchToDefaultWindow();
    }

    public void viewNotesFunction() throws Throwable {
        if (verifyElementPresent(WorkbenchWorkItems.viewNotes.findBy)) {
            logPass(driver, "There are some notes available to view");
        } else {
            logFail(driver, "No Note to show");
        }
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.closeButtonOnViewNotesPage.findBy);
        sleep(2);
    }


    public void clickOnChangeScoreOption() throws Throwable {
        switchToDefaultFrame();
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconChangeScore.findBy);
        sleep(2);
    }


    public void verifyTheHeaderOfChangeScoreNewWindow() throws Throwable {
        switchToNewWindow();
        driver.manage().window().maximize();
        sleep(4);
        getPageTitle(jsonRead.readStringFromDataJSON("changeScoreWindow"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Change Score");
        sleep(2);
    }


    public void verifyTheHeaderOfViewHistoryNewWindow() throws Throwable {
        switchToNewWindow();
        driver.manage().window().maximize();
        sleep(4);
        getPageTitle(jsonRead.readStringFromDataJSON("viewHistoryWindowPageTitle"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "View History");
        sleep(2);
    }

    public void verifyTheHeaderOfChangeStepWindow() throws Throwable {
        switchToNewWindow();
        maximizeWindow();
        sleep(4);
        getPageTitle(jsonRead.readStringFromDataJSON("changeStepWindowPageTitle"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Change Step");
        sleep(2);
    }


    public void verifyTheHeaderAndSelectANewDateAndTime() throws Throwable {
        switchToNewWindow();
        sleep(2);
        if (verifyPageTitle(jsonRead.readStringFromDataJSON("changeStepWindowPageTitle"))) {
            verifyText(WorkbenchWorkItems.changeStepDeadlineBoxHeader.findBy, " Change Step Deadline ");
            sleep(2);
            verifyAndEnterText(WorkbenchWorkItems.changeStepDeadlineNewDate.findBy, "12/31/2022 12:00 am");
            sleep(2);
        } else
            try {
                verifyAndClickForChildWindow(WorkbenchWorkItems.closebittonOnChangeStepDeadlineUpdateFailed.findBy);
                logPass(driver, "Update Failed - The step deadline has already passed and therefore cannot be changed");
            } catch (Exception e) {
                logFail(driver, "Driver failed to switch to alert pop up");
            }
    }

    public void verifyTheHeaderForEditItemWindow() throws Throwable {
        switchToNewWindow();
        maximizeWindow();
        sleep(2);
        getPageTitle(jsonRead.readStringFromDataJSON("editItemPageTitle"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Edit Item");
        sleep(2);
    }


    public void verifyTheHeaderOfChangeItemUserBUWindow() throws Throwable {
        switchToNewWindow();
        maximizeWindow();
        changeItemUse_BUWindow = getCurrentWindowTitle();
        sleep(2);
        getPageTitle(jsonRead.readStringFromDataJSON("ChangeItemUserBUWindowPageTitle"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Change Item User/BU");
        sleep(2);
    }


    public void clickAndEnterScoreValue() throws Throwable {
        verifyText(WorkbenchWorkItems.newScoreText.findBy, "New Score");
        sleep(2);
        newScoreInput = jsonRead.readStringFromDataJSON("valueForChangeScoreFunctionality");
        verifyAndEnterText(WorkbenchWorkItems.newScoreTextBox.findBy, newScoreInput);
        verifyAndClickForChildWindow(WorkbenchWorkItems.oKButtonOnChangeScorePage.findBy);
        sleep(2);
        switchToDefaultWindow();
        refreshBrowser();
    }


    public void verifyUpdatedScore() throws Throwable {
        int updatedScore = fetchCurrentScoreForClickedAlertId();
        if (updatedScore == Integer.valueOf(newScoreInput))
            logPass(driver, "Change Score functionality working as expected");
        else
            logFail(driver, "Failed to update/change the Score value");
    }

    public void clickOnOkButtonOnChildWindow() throws Throwable {
        verifyAndClickForChildWindow(WorkbenchWorkItems.oKButtonOnAddNotePage.findBy);
        sleep(2);
    }

    public void clickOnViewHistoryOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconViewHistory.findBy);
        sleep(2);
    }

    public void clickOnAssignIconOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconAssign.findBy);
        sleep(2);
    }

    public void clickOnChangeStepIconOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconChangeStep.findBy);
        sleep(2);
    }


    public void clicksOnDeleteOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconDelete.findBy);
        sleep(2);
    }

    public void clicksOnEditOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconEditItem.findBy);
        sleep(2);
    }


    public void clickOnAddToCaseItemIconOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconAddCase.findBy);
        sleep(2);
    }

    public void clickOnChangeStepDeadlineIconOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconChangeStepDeadline.findBy);
        sleep(2);
    }

    public void viewHistoryFunction() throws Throwable {
        if (verifyElementPresent(WorkbenchWorkItems.viewHistoryLine.findBy)) {

            logPass(driver, "History lines available to view");
        } else {
            logFail(driver, "No history to view ");
        }
        sleep(2);
    }

    public void validateRecentHistoryLine() throws Throwable {
        String latestHistoryLineValue = fetchText(WorkbenchWorkItems.recentHistoryLineValue.findBy);
        String updatedHistoryValueOnViewHistory = fetchText(WorkbenchWorkItems.recentUpdatedHistoryValue.findBy);
        if (latestHistoryLineValue.contentEquals(updatedHistoryValueOnViewHistory)) {
            logPass(driver, "Successfully validated the recent history line");
        } else {
            logFail(driver, "No history to view");
        }
        sleep(4);
        verifyAndClick(WorkbenchWorkItems.closeButtonOnViewHistoryPage.findBy);
        sleep(2);
    }

    public void selectsAndAssignAnotherBU() throws Throwable {
        verifyText(WorkbenchWorkItems.labelAssignToAnotherBusinessUnit.findBy, "Assign to another Business Unit");
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.buPickerImgOnChangeItemUserPage.findBy);
        switchToNewWindow();
        maximizeWindow();
        String businessUnitExplorerWindow = getCurrentWindowTitle();
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.businessUnitHierarchyRootAnchor.findBy);
        verifyAndClickForChildWindow(WorkbenchWorkItems.okButtonOnBusinessUnitExplorer.findBy);
        sleep(2);
        Set<String> allOpenWindowTitle = getAllWindowTitles();
        for (String handle : allOpenWindowTitle) {
            if (!handle.equals(parentWindow) && !handle.equals(businessUnitExplorerWindow))
                driver.switchTo().window(changeItemUse_BUWindow);
        }
    }

    public void selectsAndAssignAnotherUser() throws Throwable {
        verifyText(WorkbenchWorkItems.labelAssignToAnotherUser.findBy, "Assign to another user (or make it Unassigned)");
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.radioButtonAssignToUser.findBy);
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.userPickerImgOnChangeItemUserPage.findBy);
        switchToNewWindow();
        maximizeWindow();
        String selectUserWindow = getCurrentWindowTitle();
        sleep(2);
        getPageTitle(jsonRead.readStringFromDataJSON("selectUserPageTitle"));
        verifyText(WorkbenchWorkItems.labelEnterSearchText.findBy, "Enter Search Text");
        sleep(2);
        verifyAndEnterText(WorkbenchWorkItems.enterSearchTextBox.findBy, "Administrator");
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.goButtonOnSelectUserPage.findBy);
        sleep(2);
        selectElementFromDropdown(WorkbenchWorkItems.availableUserOptionsOnSelectUserPage.findBy, "Administrator - admin (General)");
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.oKButtonOnSelectUserPage.findBy);
        sleep(2);
        Set<String> allOpenWindowTitle = getAllWindowTitles();
        for (String handle : allOpenWindowTitle) {
            if (!handle.equals(parentWindow) && !handle.equals(selectUserWindow))
                driver.switchTo().window(changeItemUse_BUWindow);
        }
        sleep(2);
        verifyAndClickForChildWindow(WorkbenchWorkItems.oKButtonOnChangeItemUserBUPage.findBy);
    }

    public void verifyTheCurrentStepAndSelectNextStepOfAlert() throws Throwable {
        String currentStatus = fetchText(WorkbenchWorkItems.changeStatusCurrentStatus.findBy);
        if (currentStatus.contentEquals("Ready")) {
            sleep(2);
            verifyAndClick(WorkbenchWorkItems.nextStepDropDownOnChangeStep.findBy);
            verifyAndClick(WorkbenchWorkItems.selectedStatusInProgress.findBy);
            sleep(2);
        } else if (currentStatus.contentEquals("In Process")) {
            verifyAndClick(WorkbenchWorkItems.nextStepDropDownOnChangeStep.findBy);
            verifyAndClick(WorkbenchWorkItems.selectedStatusResetToReady.findBy);
            sleep(2);
        }
    }

    public void addNoteForChangeStepAndVerifyUpdatedStep() throws Throwable {
        String currentStatus = fetchText(WorkbenchWorkItems.changeStatusCurrentStatus.findBy);
        if (currentStatus.contentEquals("Ready")) {
            changeFrameWithFrameName("changeStatusNoteModelFreeTextNote_ifr");
            verifyAndEnterText(WorkbenchWorkItems.textAreaToAddNote.findBy, "This note is added by an automated script. [TEST SCRIPT]");
            sleep(2);
            switchToDefaultFrame();
            sleep(2);
            verifyAndClickForChildWindow(WorkbenchWorkItems.oKButtonOnChangeStepPage.findBy);
            sleep(2);
            switchToDefaultWindow();
            refreshBrowser();
            changeFrameWithFrameName("frmDetailsSingleView");
            String updatedStepStatus = fetchText(WorkbenchWorkItems.stepDetailsOnAlertDetails.findBy);
            if (updatedStepStatus.contains("Step: In Process"))
                logPass("Step status updated successfully.");
            else
                logFail("Step status not updated.");
        } else {
            changeFrameWithFrameName("changeStatusNoteModelFreeTextNote_ifr");
            verifyAndEnterText(WorkbenchWorkItems.textAreaToAddNote.findBy, "This note is added by an automated script. [TEST SCRIPT]");
            sleep(2);
            switchToDefaultFrame();
            sleep(2);
            verifyAndClickForChildWindow(WorkbenchWorkItems.oKButtonOnChangeStepPage.findBy);
            switchAndAcceptAlert();
            sleep(2);
            switchToDefaultWindow();
            refreshBrowser();
            changeFrameWithFrameName("frmDetailsSingleView");
            String updatedStepStatus = fetchText(WorkbenchWorkItems.stepDetailsOnAlertDetails.findBy);
            if (updatedStepStatus.contains("Step: Ready"))
                logPass("Step status updated successfully.");
            else
                logFail("Step status not updated.");
        }
    }

    public void verifyTheHeaderAndAddANewCaseItem() throws Throwable {
        switchToNewWindow();
        maximizeWindow();
        sleep(2);
        getPageTitle(jsonRead.readStringFromDataJSON("addToCaseItemPageTitle"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Add to Case Item");
        sleep(2);
        String addToCaseItemPageWindowTitle = getCurrentWindowTitle();
        System.out.println(addToCaseItemPageWindowTitle);
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.addToNewCaseRadioButton.findBy);
        sleep(2);
        verifyAndClickForChildWindow(WorkbenchWorkItems.addToCaseButton.findBy);
        sleep(2);
        String newCaseItemPageWindowTitle = getCurrentWindowTitle();
        Set<String> allOpenWindowTitle = getAllWindowTitles();
        for (String handle : allOpenWindowTitle) {
            if (!handle.equals(parentWindow) && !handle.equals(addToCaseItemPageWindowTitle))
                driver.switchTo().window(newCaseItemPageWindowTitle);
        }
        maximizeWindow();
        sleep(2);
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "New Case Item");
        sleep(2);
        verifyAndEnterText(WorkbenchWorkItems.alertNameOnAddToNewCase.findBy, "Test Alert");
        sleep(2);
        verifyAndClickForChildWindow(WorkbenchWorkItems.finishButtonOnAddToNewCase.findBy);
        sleep(2);
        sleep(2);
        String successPageWindowTitle = getCurrentWindowTitle();
        for (String handle : allOpenWindowTitle) {
            if (!handle.equals(parentWindow) && !handle.equals(addToCaseItemPageWindowTitle))
                driver.switchTo().window(successPageWindowTitle);
        }
        maximizeWindow();
        getPageTitle(jsonRead.readStringFromDataJSON("successNewCaseItemPageTitle"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Success");
        sleep(2);
        verifyText(WorkbenchWorkItems.caseItemSavedMessageOnSuccessPage.findBy, "Case item saved.");
        sleep(2);
        verifyAndClickForChildWindow(WorkbenchWorkItems.openItemButtonOnSuccessPage.findBy);
        sleep(10);
    }


    public void changeThePriority() throws Throwable {
        switchToDefaultWindow();
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
        sleep(2);
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconChangePriority.findBy);
        sleep(2);
        switchToNewWindow();
        maximizeWindow();
        getPageTitle(jsonRead.readStringFromDataJSON("changePriorityPageTitle"));
        verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Change Priority");
        sleep(2);
        selectElementFromDropdown(WorkbenchWorkItems.selectNewPriority.findBy, "High");
        sleep(2);
        verifyAndClickForChildWindow(WorkbenchWorkItems.okButtonOnChangePriority.findBy);
        sleep(8);
        switchToDefaultWindow();
        changeFrameWithFrameName("frmDetails");
        sleep(2);
        verifyText(WorkbenchWorkItems.priorityOnAlertDetailsPage.findBy, "Priority: High |");
    }


    public void verifyAnyCaseItemLinkedAndDeleteFunctionalityForThisAlert() throws Throwable {
        switchToNewWindow();
        maximizeWindow();
        if (verifyPageTitle(jsonRead.readStringFromDataJSON("errorPageTitle"))) {
            sleep(2);
            String errorMessageOnErrorPage = fetchText(WorkbenchWorkItems.errorTextOnErrorPage.findBy);
            String linkedParentItems = errorMessageOnErrorPage.replace("Cannot delete items. One or more items for deletion are related to the following parent items:", "");
            String removeOpeningSquare = linkedParentItems.replace("[", "").trim();
            String removeClosingSquare = removeOpeningSquare.replace("]", "").trim();
            String removeDot = removeClosingSquare.replace(".", "").trim();
            String removeSpaces = removeDot.replace(" ", "").trim();
            List<String> listOfLinkedParentsItems = new ArrayList<String>(Arrays.asList(removeDot.split(",")));
            verifyAndClickForChildWindow(WorkbenchWorkItems.closeButtonOnErrorPage.findBy);
            switchToDefaultWindow();
            verifyAndClick(WorkbenchWorkItems.iconActionUpOnItemDetailsPage.findBy);
            sleep(4);

            if (!fetchText(pom.dropdownTitleText).equalsIgnoreCase("Case Item Alerts")) {
                verifyAndClick(pom.dropdownTitleText);
                scrollIntoView(pom.dropdownOptionCaseItemAlerts);
                verifyAndClick(pom.dropdownOptionCaseItemAlerts);
                sleep(4);

                for (int i = 0; i < listOfLinkedParentsItems.size(); i++) {
                    verifyAndEnterText(pom.searchTextBoxOnWorkItemPage, listOfLinkedParentsItems.get(i).trim());
                    pressEnterButton(pom.searchTextBoxOnWorkItemPage);
                    sleep(4);
                    verifyAndClick(WorkbenchWorkItems.selectOpenedCaseItem.findBy);
                    sleep(2);
                    verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
                    sleep(2);
                    verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconDelete.findBy);
                    sleep(2);
                    switchToNewWindow();
                    maximizeWindow();
                    sleep(2);
                    verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Delete");
                    sleep(4);
                    verifyAndClickForChildWindow(WorkbenchWorkItems.yesButtonOnDeletePage.findBy);
                    switchToDefaultWindow();
                    sleep(2);
                }
                if (!fetchText(pom.dropdownTitleText).equalsIgnoreCase("MSC All Alerts")) {
                    verifyAndClick(pom.dropdownTitleText);
                    scrollIntoView(pom.dropdownOptionMSCAllAlerts);
                    verifyAndClick(pom.dropdownOptionMSCAllAlerts);
                    sleep(4);
                    verifyAndEnterText(pom.searchTextBoxOnWorkItemPage, "MSC Ramping");
                    sleep(1);
                    pressEnterButton(pom.searchTextBoxOnWorkItemPage);
                    sleep(4);
                    verifyAndClick(WorkbenchWorkItems.recentAlertId.findBy);
                    verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconMoreOption.findBy);
                    sleep(2);
                    verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconDelete.findBy);
                    sleep(2);
                    switchToNewWindow();
                    maximizeWindow();
                    sleep(2);
                    verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Delete");
                    sleep(4);
                    verifyAndClickForChildWindow(WorkbenchWorkItems.yesButtonOnDeletePage.findBy);
                    switchToDefaultWindow();
                }
            }
        } else {
            getPageTitle(jsonRead.readStringFromDataJSON("deletePageTitle"));
            sleep(2);
            verifyContainsText(WorkbenchWorkItems.HeaderOnNewWindow.findBy, "Delete");
            sleep(4);
            verifyAndClickForChildWindow(WorkbenchWorkItems.yesButtonOnDeletePage.findBy);
            switchToDefaultWindow();
        }
    }

    public void verifyTheEditFunctionality() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.dataEntryOptionOnEditItem.findBy);
        sleep(2);
        String localAlertTime = fetchTextWithSpecificAttribute(localAlertTimeOnEditItem, "value");
        sleep(2);
        verifyAndEnterText(WorkbenchWorkItems.localAlertTimeOnEditItem.findBy, jsonRead.readStringFromDataJSON("updatedLocalAlertTime"));
        sleep(2);
        verifyAndClickForChildWindow(WorkbenchWorkItems.saveButtonOnEditItemPage.findBy);
        switchToDefaultWindow();
        refreshBrowser();
        changeFrameWithFrameName("frmDetailsSingleView");
        String updatedDate = fetchText(WorkbenchWorkItems.localAlertDateOnItemDetailsPage.findBy);
        if (updatedDate.contains("12/31/2023"))
            logPass("Edited value updated successfully.");
        else
            logFail("Edited value not updated.");
        sleep(2);
      /*  System.out.println(localAlertTime);
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/YYYY");
        System.out.println(formatter.format(date));*/
    }


    public void selectsShowAsPdfOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconExport.findBy);
        sleep(2);
        verifyAndClickViaJavaScript(WorkbenchWorkItems.alertDetailsPageOptionShowAsPDF.findBy);
    }


    public void verifyTheFunctionalityForPDFOption() throws Throwable {
        switchToNewWindow();
        maximizeWindow();
        sleep(2);
        isFileDownloadedInSystem(".pdf");

        /*driver.get("chrome://settings/content/pdfDocuments");
        new WebDriverWait(driver, 10).until(ExpectedConditions.numberOfElementsToBeMoreThan(By.cssSelector("body/deep/#control"), 10));
        driver.findElements(By.cssSelector("body/deep/#control")).get(10).click();
        sleep(2);*/

        /*URL url = new URL("http://10.128.166.43:8080/RCM/AlertDetailsFrame.go");
        InputStream inputStream = url.openStream();
        BufferedInputStream fileParse = new BufferedInputStream(inputStream);
        PDDocument pdfDocument = Loader.loadPDF(fileParse);
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String pdfContent = pdfStripper.getText(pdfDocument);
        System.out.println(pdfContent);*/


    /*    URL TestURL = new URL("http://www.axmag.com/download/pdfurl-guide.pdf");
        BufferedInputStream TestFile = new BufferedInputStream(TestURL.openStream());
        PDFParser TestPDF = new PDFParser(TestFile);
        TestPDF.parse();
        String TestText = new PDFTextStripper().getText(TestPDF.getPDDocument());*/
    }


    public void selectsAttachmentOption() throws Throwable {
        verifyAndClick(WorkbenchWorkItems.alertDetailsPageIconAttachments.findBy);
        sleep(2);
    }


    public void verifyTheHeaderForAttachmentWindow() throws Throwable {
        switchToNewWindow();
        sleep(2);
        getPageTitle(jsonRead.readStringFromDataJSON("attachementDilogBoxTitle"));
    }


}



    /*public void backGroundForAllAlertFeatureFile() throws Throwable {
        String alertType = "MSC All Alert";
        commonSteps.userNavigateToApplicationUrl();
        loginsteps.userLoginWithValidCredentials();
        userLoginSuccessfullyAndLandsOnDashboardPage();
        userVerifyAndClicksWorkbenchWorkItemsSubmenu();
        userLandedOnWorkItemPage();
        userSelectsOptionFromTheDropdown(alertType);
        userRefreshThePage();
        userValidateTheNumberOfTotalAlertsPresent();
    }*/



