package com.surveilx.qa.Reporting;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ExtentManager {

    public static Map<Integer, ExtentTest> extentTestMap = new HashMap<Integer, ExtentTest>();
    public static String timeStamp = new SimpleDateFormat("dd.MMM.yyyy_HH.mm.ss.SSS").format(new Date());
    public static String reportFileName = "Automation_Report_" + timeStamp + ".html";
    public static String reportFileFolder = System.getProperty("user.dir") + File.separator + "TestReport";
    public static String reportFilePath = reportFileFolder + File.separator + "Reports";
    public static String reportFileLocation = reportFilePath + File.separator + reportFileName;
    public static ExtentReports extent = ExtentManager.getInstance();

    public static ExtentReports getInstance() {
        if (extent == null)
            createInstance();
        return extent;
    }

    public static ExtentReports createInstance() {
        String fileName = getReportPath(reportFilePath);
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
        htmlReporter.config().setTestViewChartLocation(ChartLocation.BOTTOM);
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setCSS("css-string");
        htmlReporter.config().setDocumentTitle(reportFileName);
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setJS("js-string");
        htmlReporter.config().setProtocol(Protocol.HTTPS);
        htmlReporter.config().setReportName(reportFileName);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setTimeStampFormat("EEEE, MMM dd, yyyy, hh:mm a '('zzz')'");

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        //Set environment details
        extent.setSystemInfo("Company", "Nice");
        return extent;

    }

    //Create Report Path
    private static String getReportPath(String path) {
        //File testFolder = new File(reportFileFolder);
        File testDirectory = new File(path);
        if (!testDirectory.exists()) {
            if (testDirectory.mkdir()) {
                return reportFileLocation;
            } else {
                return System.getProperty("user.dir");
            }
        } else {
            System.out.println("Directory is already exists:" + path);
        }
        return reportFileLocation;
    }

    public static ExtentTest getTest() {
        return (ExtentTest) extentTestMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static void endTest() {
        extent.flush();
    }

    public static ExtentTest startTest(String testName) {
        ExtentTest test = extent.createTest(testName);
        extentTestMap.put((int) (long) (Thread.currentThread().getId()), test);
        return test;
    }

    public static void logInfo(String message) {
        getTest().log(Status.INFO, message);
    }

    public static void logPass(String message) {
        getTest().log(Status.PASS, message);
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertTrue(true, message);
    }

    public static void logFail(String message) {
        getTest().log(Status.FAIL, message);
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertFalse(false, message);
    }

    public static void logSkip(String message) {
        getTest().log(Status.SKIP, message);
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertTrue(true, message);
    }
}
