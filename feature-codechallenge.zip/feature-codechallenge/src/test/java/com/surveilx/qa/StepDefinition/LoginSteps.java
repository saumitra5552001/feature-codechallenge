package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.LoginPageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

import java.io.IOException;

public class LoginSteps extends CommonFunctions {

    LoginPageObjects loginpom = new LoginPageObjects(driver);

    @Then("^I validate login page elements$")
    public void iValidateLoginPageElements() throws Throwable {
        loginpom.validateLoginPageElements();
    }

    @And("I enter Username as {string}")
    public void iEnterUserName(String username) throws Exception {
        String username1 = jsonRead.readStringFromDataJSON("username");
        loginpom.enterUsername(username1);
    }

    @And("^I enter Password as \"([^\"]*)\"$")
    public void iEnterPassword(String password) throws Exception {
        String password1 = jsonRead.readStringFromDataJSON("password");
        loginpom.enterPassword(password1);
    }

    @And("^I click on login button$")
    public void iClickOnLoginButton() throws Throwable {
        loginpom.clickLoginButton();
    }

    @And("^I login with valid credentials$")
    public void iLoginWithValidCredentials() throws Throwable {
        String username = jsonRead.readStringFromDataJSON("username");
        String password = jsonRead.readStringFromDataJSON("password");
        iEnterUserName(username);
        iEnterPassword(password);
        iClickOnLoginButton();
    }

    @Then("User validate login page elements")
    public void user_validate_login_page_elements() throws Throwable {
        loginpom.validateLoginPageElements();
    }

    @And("User enter Username as {string}")
    public void user_enter_username_as(String string) throws Exception {
        String username1 = jsonRead.readStringFromDataJSON("username_MSC");
        loginpom.enterUsername(username1);
    }

    @And("User enter Password as {string}")
    public void user_enter_password_as(String string) throws Exception {
        String password1 = jsonRead.readStringFromDataJSON("password_MSC");
        loginpom.enterPassword(password1);
    }

    @And("User click on login button")
    public void user_click_on_login_button() throws Throwable {
        loginpom.clickLoginButton();
    }

    @And("User login with valid credentials")
    public void userLoginWithValidCredentials() throws Throwable {
        String username1 = jsonRead.readStringFromDataJSON("username_MSC");
        String password1 = jsonRead.readStringFromDataJSON("password_MSC");
        user_enter_username_as(username1);
        user_enter_password_as(password1);
        user_click_on_login_button();
    }




}
