package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import io.cucumber.java.en.And;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SystemConfigurationPageObjects extends CommonFunctions {

    public SystemConfigurationPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private enum SystemConfiguration {

        applicationPickerOnHomePage(By.xpath(".//div[@id='applicationPicker']")),
        systemConfigurationMenu(By.xpath(".//div[@id='headerLinkToAdmin']")),
        configParametersTab(By.xpath(".//td[@class='clsMainMenuSelected-middle clsMainMenuSelected-text']")),
        connectionsTab(By.xpath("(.//td[@class='clsMainMenuUnselected-text clsMainMenuPadding'])[1]")),
        aISConnectionsTab(By.xpath("(.//td[@class='clsMainMenuUnselected-text clsMainMenuPadding'])[2]")),
        configurationSetsTab(By.xpath("(.//td[@class='clsMainMenuUnselected-text clsMainMenuPadding'])[3]")),
        filterByTextBox(By.xpath(".//input[@id='toolbarFilterTextArea']")),
        goButtonOnConfigParameter(By.xpath(".//td[@id='textButton_toolbarGoButton']")),
        clearButtonOnConfigParameter(By.xpath(".//td[@id='textButton_toolbarClearButton']")),
        actimizeAboutDialogDisplayAdditionalModulesValue(By.xpath("(.//td[@id='tdGridCell_3']/span)[1]")),
        actimizeAboutDialogDisplayGeneralInformationValue(By.xpath("(.//td[@id='tdGridCell_3']/span)[2]")),
        actimizeAboutDialogDisplayLicensedModulesValue(By.xpath("(.//td[@id='tdGridCell_3']/span)[3]")),
        actimizeAboutDialogDisplayOptionalModulesValue(By.xpath("(.//td[@id='tdGridCell_3']/span)[4]")),
        configparameterPanelheader(By.xpath(".//td[contains(text(),'Configuration Parameters')]")),
        connectionsPanelheader(By.xpath("(.//td[contains(text(),'Connections')])[3]")),
        aISConnectionsPanelheader(By.xpath("(.//td[contains(text(),'AIS Connections')])[2]")),
        configurationSetsPanelheader(By.xpath("(.//td[contains(text(),'Work Items')])[2]")),
        connectionNameTCAPPConnector(By.linkText("TC_APP_Connector")),
        connectionNameTCIDWConnector(By.linkText("TC_IDW_Connector")),
        connectionNameTCAMVProfilesConnector(By.linkText("TC_AMV_Profiles_Connector")),
        connectionNameTCCDSConnector(By.linkText("TC_CDS_Connector")),
        connectionNameTCAPPConnectorURL(By.xpath("(.//td[@class='Standart'])[9]")),
        connectionNameTCIDWConnectorURL(By.xpath("(.//td[@class='Standart'])[19]")),
        connectionNameTCAMVProfilesConnectorURL(By.xpath("(.//td[@class='Standart'])[24]")),
        connectionNameTCCDSConnectorURL(By.xpath("(.//td[@class='Standart'])[29]")),
        connectionNameValueOnUpdateConnectionPage(By.xpath(".//input[@id='dsn_name']")),
        databaseTypeValueOnUpdateConnectionPage(By.xpath(".//select[@id='driver_id']")),
        urlValueOnUpdateConnectionPage(By.xpath(".//input[@id='conn_url']")),
        userNameValueOnUpdateConnectionPage(By.xpath(".//input[@id='user_name']")),
        connectionPageHeader(By.xpath(".//td[@class='dialogHeaderText']")),
        testConnectionButton(By.xpath(".//td[@id='textButton_testConnection']")),
        connectionTestSuccessfullyMessage(By.xpath(".//div[@class='commonPopupCellData11']")),
        closeButtonOnTestResultPage(By.xpath(" .//td[@id='textButton_testConnection_OkButton']")),
        closeButtonOnConnectionPage(By.xpath("(.//td[@id='textButton_'])[2]")),

        ;
        private By findBy;

        SystemConfiguration(By locator) {
            this.findBy = locator;
        }
    }

    @FindBy(xpath = "//font[@id='nodeText_1']")
    WebElement SettingsNavigatorNodeTradeSurveillance;


    public void verifyAndClicksOnSystemConfigurationOption() throws Throwable {
        verifyAndClick(SystemConfiguration.applicationPickerOnHomePage.findBy);
        sleep(1);
        verifyAndClick(SystemConfiguration.systemConfigurationMenu.findBy);

    }

    public void verifyUserLandedOnConfigParameterPage() throws Throwable {
        getPageTitle(jsonRead.readStringFromDataJSON("configParametersPageTitle"));
        //verifyText(SystemConfiguration.configparameterPanelheader.findBy, "Configuration Parameters");
    }

    public void verifyOtionsAvailableForSystemConfiguration() throws Throwable {
        verifyText(SystemConfiguration.configParametersTab.findBy, "Config Parameters");
        verifyText(SystemConfiguration.connectionsTab.findBy, "Connections");
        verifyText(SystemConfiguration.aISConnectionsTab.findBy, "AIS Connections");
        verifyText(SystemConfiguration.configurationSetsTab.findBy, "Configuration Sets");
        sleep(1);
    }


    public void verifyAllTabsAreWorkingWithSystemConfiguration() throws Throwable {
        {
            verifyAndEnterText(SystemConfiguration.filterByTextBox.findBy, "actimize.aboutDialog.");
            sleep(1);
            verifyAndClick(SystemConfiguration.goButtonOnConfigParameter.findBy);
            sleep(2);
            verifyText(SystemConfiguration.actimizeAboutDialogDisplayAdditionalModulesValue.findBy, "1");
            verifyText(SystemConfiguration.actimizeAboutDialogDisplayGeneralInformationValue.findBy, "1");
            verifyText(SystemConfiguration.actimizeAboutDialogDisplayLicensedModulesValue.findBy, "1");
            verifyText(SystemConfiguration.actimizeAboutDialogDisplayOptionalModulesValue.findBy, "1");
            sleep(2);
            verifyAndClick(SystemConfiguration.clearButtonOnConfigParameter.findBy);
            sleep(4);

            verifyAndClick(SystemConfiguration.connectionsTab.findBy);
            sleep(2);
            verifyText(SystemConfiguration.connectionsPanelheader.findBy, "Connections");

            sleep(4);
            verifyAndClick(SystemConfiguration.aISConnectionsTab.findBy);
            sleep(2);
            verifyText(SystemConfiguration.aISConnectionsPanelheader.findBy, "AIS Connections");

            sleep(4);
            verifyAndClick(SystemConfiguration.configurationSetsTab.findBy);
            sleep(2);
            verifyText(SystemConfiguration.configurationSetsPanelheader.findBy, "Work Items");
        }
    }


    public void clicksOnConnectionTabAndVerifyConnectionNameURL() throws Throwable {
        {
            verifyAndClick(SystemConfiguration.connectionsTab.findBy);
            sleep(2);
            verifyText(SystemConfiguration.connectionsPanelheader.findBy, "Connections");
            sleep(2);
            verifyText(SystemConfiguration.connectionNameTCAPPConnector.findBy, "TC_APP_Connector");
            sleep(1);
            verifyContainsText(SystemConfiguration.connectionNameTCAPPConnectorURL.findBy, "jdbc:sqlserver://10.");
            sleep(2);
            verifyText(SystemConfiguration.connectionNameTCIDWConnector.findBy, "TC_IDW_Connector");
            sleep(1);
            verifyContainsText(SystemConfiguration.connectionNameTCIDWConnectorURL.findBy, "jdbc:sqlserver://10.");
            sleep(2);
            verifyContainsText(SystemConfiguration.connectionNameTCIDWConnectorURL.findBy, "sendStringParametersAsUnicode=false");
            sleep(2);
            verifyText(SystemConfiguration.connectionNameTCAMVProfilesConnector.findBy, "TC_AMV_Profiles_Connector");
            sleep(1);
            verifyContainsText(SystemConfiguration.connectionNameTCAMVProfilesConnectorURL.findBy, "jdbc:sqlserver://10.");
            sleep(2);
            verifyText(SystemConfiguration.connectionNameTCCDSConnector.findBy, "TC_CDS_Connector");
            sleep(1);
            verifyContainsText(SystemConfiguration.connectionNameTCCDSConnectorURL.findBy, "jdbc:sqlserver://10.");
        }
    }

    public void verifyMandetoryFieldsForTestConnection() throws Throwable {
        sleep(2);
        verifyTextFieldIsNonEmpty(SystemConfiguration.connectionNameValueOnUpdateConnectionPage.findBy);
        verifyTextFieldIsNonEmpty(SystemConfiguration.databaseTypeValueOnUpdateConnectionPage.findBy);
        verifyTextFieldIsNonEmpty(SystemConfiguration.urlValueOnUpdateConnectionPage.findBy);
        verifyTextFieldIsNonEmpty(SystemConfiguration.userNameValueOnUpdateConnectionPage.findBy);
        sleep(2);
    }

    public void verifyConnectionTestedSuccessfully() throws Throwable {
        sleep(2);
        getPageTitle(jsonRead.readStringFromDataJSON("testResultPageTitle"));
        verifyText(SystemConfiguration.connectionTestSuccessfullyMessage.findBy, "Connection tested successfully!");
        sleep(2);
        verifyAndClickForChildWindow(SystemConfiguration.closeButtonOnTestResultPage.findBy);
        switchToDefaultWindow();
        verifyAndClickForChildWindow(SystemConfiguration.closeButtonOnConnectionPage.findBy);
        sleep(2);
    }

    public void validateConnectivityUsingTestConnection(String connection_name) throws Throwable {
        {
            if (connection_name.equalsIgnoreCase("TC_APP_Connector")) {
                verifyAndClick(SystemConfiguration.connectionsTab.findBy);
                sleep(2);
                verifyAndClick(SystemConfiguration.connectionNameTCAPPConnector.findBy);
                sleep(2);
                switchToNewWindow();
                maximizeWindow();
                getPageTitle(jsonRead.readStringFromDataJSON("updateConnectionPageTitle"));
                verifyContainsText(SystemConfiguration.connectionPageHeader.findBy, "Connection");
                verifyMandetoryFieldsForTestConnection();
                verifyAndClickForChildWindow(SystemConfiguration.testConnectionButton.findBy);
                switchToNewWindow();
                maximizeWindow();
                verifyConnectionTestedSuccessfully();
            }

            if (connection_name.equalsIgnoreCase("TC_IDW_Connector")) {
                verifyAndClick(SystemConfiguration.connectionsTab.findBy);
                sleep(2);
                verifyAndClick(SystemConfiguration.connectionNameTCIDWConnector.findBy);
                sleep(2);
                switchToNewWindow();
                maximizeWindow();
                getPageTitle(jsonRead.readStringFromDataJSON("updateConnectionPageTitle"));
                verifyContainsText(SystemConfiguration.connectionPageHeader.findBy, "Connection");
                verifyMandetoryFieldsForTestConnection();
                verifyAndClickForChildWindow(SystemConfiguration.testConnectionButton.findBy);
                switchToNewWindow();
                maximizeWindow();
                verifyConnectionTestedSuccessfully();
            }

            if (connection_name.equalsIgnoreCase("TC_AMV_Profiles_Connector")) {
                verifyAndClick(SystemConfiguration.connectionsTab.findBy);
                sleep(2);
                verifyAndClick(SystemConfiguration.connectionNameTCAMVProfilesConnector.findBy);
                sleep(2);
                switchToNewWindow();
                maximizeWindow();
                getPageTitle(jsonRead.readStringFromDataJSON("updateConnectionPageTitle"));
                verifyContainsText(SystemConfiguration.connectionPageHeader.findBy, "Connection");
                verifyMandetoryFieldsForTestConnection();
                verifyAndClickForChildWindow(SystemConfiguration.testConnectionButton.findBy);
                switchToNewWindow();
                maximizeWindow();
                verifyConnectionTestedSuccessfully();
            }

            if (connection_name.equalsIgnoreCase("TC_CDS_Connector")) {
                verifyAndClick(SystemConfiguration.connectionsTab.findBy);
                sleep(2);
                verifyAndClick(SystemConfiguration.connectionNameTCCDSConnector.findBy);
                sleep(2);
                switchToNewWindow();
                maximizeWindow();
                getPageTitle(jsonRead.readStringFromDataJSON("updateConnectionPageTitle"));
                verifyContainsText(SystemConfiguration.connectionPageHeader.findBy, "Connection");
                verifyMandetoryFieldsForTestConnection();
                verifyAndClickForChildWindow(SystemConfiguration.testConnectionButton.findBy);
                switchToNewWindow();
                maximizeWindow();
                verifyConnectionTestedSuccessfully();
            }
        }
    }
}

