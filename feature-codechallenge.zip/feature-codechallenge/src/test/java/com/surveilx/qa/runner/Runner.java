package com.surveilx.qa.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

@CucumberOptions(features = {"src/test/java/com/surveilx/qa/BDD/features"},
        plugin = {"pretty", "json:target/cucumber.json","html:target/cucumber-html-report"},
        //plugin={"html:target/cucumber-html-report","json:target/cucumber-reports/cucumber.json","junit:target/cucumber-reports/cucumber.xml","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
        glue = "com/surveilx/qa/StepDefinition",
        monochrome = true,
        //tags = "@test or @test1 or @test2",
        tags = "@Login_TC_001",
        dryRun = false)
public class Runner extends AbstractTestNGCucumberTests {
    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}