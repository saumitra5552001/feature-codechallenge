package com.surveilx.qa.Utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.io.File;
import java.io.IOException;

public class Test {

    public static void main(String[] args) throws Exception{
        File source = new File("C:\\Users\\pgandhi\\Downloads\\Secrecy.model");
        File dest = new File("\\\\10.128.192.13\\nice\\Secrecy.model");
        copyFileUsingApacheCommonsIO(source,dest);
    }

    private static void copyFileUsingApacheCommonsIO(File source, File dest) throws IOException {
        FileUtils.copyFile(source, dest);
    }

}
