package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

import java.io.IOException;


public class SettingsNavigatorSteps extends CommonFunctions {

    LoginSteps loginstepsobj = new LoginSteps();
    NavigationPageObjects navigationpageobj = new NavigationPageObjects(driver);
    PageObject pom = new PageObject(driver);
    WorkbenchWorkItemsPageObjects workitemsobj = new WorkbenchWorkItemsPageObjects(driver);
    ResearchDartPageObjects researchdartobj = new ResearchDartPageObjects(driver);
    SettingsPageObjects settingspageobj = new SettingsPageObjects(driver);

    @Then("User verify and clicks Settings-Settings Navigator Submenu")
    public void user_verify_and_clicks_settings_settings_navigator_submenu() throws Throwable {
        navigationpageobj.clickOnSettingsTitleAndValidateItsName();
        navigationpageobj.clicksOnSettingsNavigatorAndValidateItsName();
    }

    @Then("User landed on Settings page")
    public void user_landed_on_settings_page() throws Throwable {
        getPageTitle(jsonRead.readStringFromDataJSON("settingsPageTitle"));
    }


    @Then("User verify the different options available for settings navigator")
    public void user_verify_the_different_options_available_for_settings_navigator() throws Throwable {
        settingspageobj.verifyNodesAvailableForSettingsNavigator();
    }

    @And("User clicks and expands node as {string}")
    public void user_clicks_and_expands_node_as(String node_type) throws Throwable {
        sleep(5);
        settingspageobj.verifyAndClickOnExpandedOption(node_type);
    }

    @Then("User verify sub node by selecting {string}")
    public void user_verify_sub_node_by_selecting(String sub_node_type_MSCAdvancedSetting) throws Throwable {
        sleep(5);
        settingspageobj.verifyAndClickSubNodeInMSCAdvancedSettings(sub_node_type_MSCAdvancedSetting);
    }


    @Then("User verify sub node for MSC Trade Surveillance")
    public void user_verify_sub_node_for_MSC_Trade_Surveillance() throws Throwable {
        sleep(5);
        settingspageobj.verifySubNodesAvailableForMSCTradeSurveillance();
    }

    @Then("User verify sub node as {string}")
    public void user_verify_sub_node_as(String sub_node_type_MSCTradeSurveillance) throws Throwable {
        sleep(5);
        settingspageobj.clickAndValidateSubNodeInMSCTradeSurveillance(sub_node_type_MSCTradeSurveillance);
    }

    @Then("User verify sub node of Surveil-X Investigate as {string}")
    public void user_verify_sub_node_of_Surveil_X_Investigate_as(String sub_node_type_SurveilXInvestigate) throws Throwable {
        sleep(5);
        settingspageobj.clickAndValidateSubNodeInSurveilXInvestigate(sub_node_type_SurveilXInvestigate);
    }

    @Then("User verify sub node for Trade Surveillance menu")
    public void user_verify_sub_node_for_Trade_Surveillance_menu() throws Throwable {
        sleep(5);
        settingspageobj.verifySubNodesAvailableForTradeSurveillance();
    }

    @Then("User clicked on Override Thresholds under Behavioral_Watch List Exec_Equities")
    public void user_clicked_on_override_thresholds_under_behavioral_watch_list_exec_equities() throws Throwable {
        sleep(5);
        settingspageobj.verifyAndClickedOnOverrideThresholdsUnderBehavioral();
    }

    @Then("User created new override thresholds")
    public void user_created_new_override_thresholds() throws Throwable {
        sleep(5);
        settingspageobj.createdNewOverrideThresholds();
    }


    @Then("User deleted newly created override thresholds")
    public void user_deleted_newly_created_override_thresholds() throws Throwable {
        sleep(5);
        settingspageobj.deleteNewlyCreatedOverrideThresholds();
    }


    @Then("User clicked on Thresholds node under Behavioral_Watch List Exec_Equities")
    public void user_clicked_on_thresholds_node_under_behavioral_watch_list_exec_equities() throws Throwable {
        sleep(5);
        settingspageobj.verifyAndClickedOnThresholdNodesUnderBehavioral();
    }

    @Then("User clicked on edit link and able to edit Threshold Value")
    public void user_clicked_on_edit_link_and_able_to_edit_threshold_value() throws Throwable {
        sleep(5);
        settingspageobj.clickedOnEditLinkAndAbleToEditThresholdValue();
    }

    @Then("User verify the Activate and Deactivate alert functionality")
    public void user_verify_the_activate_and_deactivate_alert_functionality() throws Throwable {
        sleep(5);
        settingspageobj.userVerifyTheActivateAndDeactivateAlertFunctionality();
    }
}