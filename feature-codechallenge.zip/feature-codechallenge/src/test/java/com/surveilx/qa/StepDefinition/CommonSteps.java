package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.ExplorePageObjects;
import com.surveilx.qa.PageObjects.PageObject;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CommonSteps extends CommonFunctions {

    PageObject pom = new PageObject(driver);

    @Given("^I navigate to Application URL$")
    public void iNavigateToApplicationURL() throws Throwable {
//        driver.navigate().to("https://ess-skt-023.cssrd.local/Login.htm?ReturnUrl=%2f");
//        sleep(10);
//        verifyAndEnterText(pom.tempUserName,"admin");
//        verifyAndEnterText(pom.tempPassword,"password");
//        verifyAndClick(pom.tempSignInButton);
//        sleep(15);
//        ((JavascriptExecutor)driver).executeScript("window.open()");
//        ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
//        driver.switchTo().window(tabs.get(1));
        String URL = jsonRead.readStringFromEnvironmentJSON("applicationURL");
        //https://ess-skt-023.cssrd.local:8443/RCM/acegi/acegilogin.jsp
        driver.navigate().to(URL);
        sleep(10);
        logInfo(driver, "Application is getting launched");
    }

	@Given("User navigate to Application URL")
    public void userNavigateToApplicationUrl() throws Throwable {
        String URL = jsonRead.readStringFromEnvironmentJSON("applicationURL1");
    }

    @Then("^I validate user is able to login as \"([^\"]*)\"$")
    public void iValidateUserIsAbleToLoginAs(String userId) throws Throwable {
        isElementDisplayed(pom.imageApplicationLogo);
        verifyText(pom.loggedInUserId, userId);
    }

    @Then("User validate user is able to login as {string}")
    public void user_validate_user_is_able_to_login_as(String userId) throws IOException {
        verifyText(pom.loggedInUserId, userId);
    }
    @And("^I click on specific item id$")
    public void iClickOnSpecificItemID() throws Throwable {
        if(!fetchText(pom.dropdownTitleText).equalsIgnoreCase("My Communications Work Items")){
            verifyAndClick(pom.dropdownTitleText);
            scrollIntoView(pom.optionMyCommunicationWorkItems);
            verifyAndClick(pom.optionMyCommunicationWorkItems);
        }
        sleep(15);
        //String typeItemId = jsonRead.readStringFromDataJSON("itemID");
        String typeItemId = "Email";
        verifyAndEnterText(pom.searchTextBox,typeItemId);
        pressEnterButton(pom.searchTextBox);
        Random rand = new Random();
        List<WebElement> el = pom.listItemId;
        // nextInt as provided by Random is exclusive of the top value so you need to add 1
        int randomNum = rand.nextInt((pom.listItemId.size() - 1) + 1) + 1;
        verifyAndClick(pom.listItemId.get(randomNum));
    }

    @And("^I click on specific item id \"([^\"]*)\"$")
    public void iClickOnSpecificItemID(String itemType) throws Throwable {
        if(!fetchText(pom.dropdownTitleText).equalsIgnoreCase("Communication")){
            verifyAndClick(pom.dropdownTitleText);
            scrollIntoView(pom.optionMyCommunicationWorkItems);
            verifyAndClick(pom.optionMyCommunicationWorkItems);
        }
        sleep(15);
        verifyAndEnterText(pom.searchTextBox,itemType);
        pressEnterButton(pom.searchTextBox);
        sleep(10);
        if(itemType.equalsIgnoreCase("Attachment"))
        {
            verifyAndClick(pom.columnType);
        }
        sleep(10);
        Random rand = new Random();
        List<WebElement> el = pom.listItemId;
        //nextInt as provided by Random is exclusive of the top value so you need to add 1
        int randomNum = rand.nextInt((pom.listItemId.size() - 1) + 1) + 1;
        verifyAndClick(pom.listItemId.get(randomNum));
        sleep(15);
    }

    @And("^I switch to iFrame \"([^\"]*)\"$")
    public void switchToIframe(String frameName) throws Throwable {
        changeFrameWithFrameName(frameName);
    }

    @And("^I switch to parent iframe$")
    public void switchToIframe() throws Throwable {
        changeBackToParentFrame();
    }

    @And("^I switch to Child iFrame$")
    public void iSwitchToChildFrame() throws InterruptedException {
        changeFrameWithIndex(0);
    }

    @Then("^I verify text from Child iFrame$")
    public void iVerifyTextFromChildIFrame() throws Throwable {
        sleep(15);
        List li = jsonRead.readArrayFromDataJSON("ExpectedHighlightedText");
        for (int i = 0; i < li.size(); i++) {
            verifyText(pom.valueHighlightedWords.get(i),li.get(i).toString());
        }
    }

    @And("I do refresh$")
    public void iDoRefresh() throws Throwable {
        refreshBrowser();
    }

    @And("I log out$")
    public void logout() throws Throwable {
        iDoRefresh();
        scrollIntoView(ExplorePageObjects.Explore.loggedInUserId.findBy);
        verifyAndClick(ExplorePageObjects.Explore.loggedInUserId.findBy);
        verifyAndClick(ExplorePageObjects.Explore.linkLogout.findBy);
    }

}
