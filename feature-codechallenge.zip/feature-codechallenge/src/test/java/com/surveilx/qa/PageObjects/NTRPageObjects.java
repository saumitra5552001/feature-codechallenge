package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;
import java.util.List;

public class NTRPageObjects extends CommonFunctions {

    public NTRPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private enum NTR {
        headerNTR(By.xpath("//span[contains(text(),'NICE Trading Recording')]")),
        buttonAdd(By.xpath("//a[contains(text(),'Add')]")),
        labelClusterName(By.xpath("//th[contains(text(),'Cluster Name')]")),
        labelRedundancyType(By.xpath("//th[contains(text(),'Redundancy Type')]")),
        labelPrimaryHostAddress(By.xpath("//th[contains(text(),'Primary Host Address')]")),
        labelSecondaryHostAddress(By.xpath("//th[contains(text(),'Secondary Host Address')]")),
        labelCallType(By.xpath("//th[contains(text(),'Call Type')]")),
        labelSearchGrid(By.xpath("//th[contains(text(),'Search Grid')]")),
        buttonDelete(By.xpath("//a[@class='k-button k-button-icontext k-grid-delete']")),
        inputClusterName(By.xpath("//input[@id='ClusterName']")),
        inputPrimaryHostAddress(By.xpath("//input[@id='PrimaryHostAddress']")),
        buttonUpdate(By.xpath("//a[@class='k-button k-button-icontext k-primary k-grid-update']")),
        inputUsername(By.xpath("(//input[@class='credentialsForm__input k-textbox'])[1]")),
        inputPassword(By.xpath("(//input[@class='credentialsForm__input k-textbox'])[2]")),
        buttonOk(By.xpath("(//button[text()='Ok'])[1]")),
        notificationText(By.id("notificationText")),

        ;
        private By findBy;

        NTR(By locator) {
            this.findBy = locator;
        }
    }

    public By valueXpath(String s) {
        return By.xpath("//*[text()='" + s + "']");
    }

    @FindBy(xpath="//a[@class='k-button k-button-icontext k-grid-delete']")
    List<WebElement> listDeleteButton;

    public void iValidateNICETradingRecordingPageUI() throws IOException {
        verifyText(NTR.headerNTR.findBy,"NICE Trading Recording");
        verifyText(NTR.buttonAdd.findBy,"Add");
        verifyText(NTR.labelClusterName.findBy,"Cluster Name");
        verifyText(NTR.labelRedundancyType.findBy,"Redundancy Type");
        verifyText(NTR.labelPrimaryHostAddress.findBy,"Primary Host Address");
        verifyText(NTR.labelSecondaryHostAddress.findBy,"Secondary Host Address");
        verifyText(NTR.labelCallType.findBy,"Call Type");
        verifyText(NTR.labelSearchGrid.findBy,"Search Grid");
    }

    public void iAddNTR() throws Throwable {
        if(listDeleteButton.size()==1) {
            listDeleteButton.get(0).click();
            sleep(5);
            pressEnterButtonWithoutElement();
            sleep(5);
        }
        verifyAndClick(NTR.buttonAdd.findBy);
        String s = getRandomStringString();
        verifyAndEnterText(NTR.inputClusterName.findBy,s);
        verifyAndEnterText(NTR.inputPrimaryHostAddress.findBy,"APP-GRT-007.CSSRD.local");
        verifyAndClick(NTR.buttonUpdate.findBy);
        verifyAndEnterText(NTR.inputUsername.findBy,"service");
        verifyAndEnterText(NTR.inputPassword.findBy,"service");
        verifyAndClick(NTR.buttonOk.findBy);
        verifyText(NTR.notificationText.findBy,"'"+s+"' cluster configuration was successfully saved");
    }


}