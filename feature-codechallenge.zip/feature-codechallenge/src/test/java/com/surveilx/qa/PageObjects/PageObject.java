package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class PageObject extends CommonFunctions {

    public PageObject(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "usernameInHeader")
    public WebElement loggedInUserId;

    @FindBy(id = "rcmLogo")
    public WebElement imageApplicationLogo;

    @FindBy(xpath = "//input[@id='apf-login-input-value-username']")
    public WebElement tempUserName;

    @FindBy(xpath = "//input[@id='apf-login-input-value-password']")
    public WebElement tempPassword;

    @FindBy(xpath = "//div[@id='apf-login-button-text']")
    public WebElement tempSignInButton;

    @FindBy(xpath = "(//a[contains(text(),'CS_')])[1]")
    public WebElement linkItemID;

    @FindBy(xpath = "(//div[contains(text(),'Item Type')])[2]")
    public WebElement labelItemType;

    @FindBy(xpath = "(//div[contains(text(),'Item Type')])[2]/../div[2]")
    public WebElement valueItemType;

    @FindBy(xpath = "//span[contains(@class,'content__highlight content__highlight--secondary')]")
    public List<WebElement> valueHighlightedWords;

    public By valueXpath(String s) {
        return By.xpath("//*[text()='" + s + "']");
    }

    @FindBy(id = "toolbarFilterTextArea")
    public WebElement searchTextBox;

    @FindBy(xpath = "//div[contains(text(),'Type')]")
    public WebElement columnType;
	
	 @FindBy(xpath = ".//input[@id='toolbarFilterTextArea']")
    public WebElement searchTextBoxOnWorkItemPage;

    @FindBy(xpath = "//span[contains(@id,'titleText')]")
    public WebElement dropdownTitleText;

    @FindBy(xpath = "//span[@id='titleArrow_59']")
    public WebElement dropdownDownArrow;

    @FindBy(xpath = "//div[contains(text(),'My Communication Work Items')]")
    public WebElement optionMyCommunicationWorkItems;

    @FindBy(xpath = "//div[contains(text(),'MSC All Alerts')]")
    public WebElement dropdownOptionMSCAllAlerts;

    @FindBy(xpath = "//div[contains(text(),'Case Item Alerts')]")
    public WebElement dropdownOptionCaseItemAlerts;

    @FindBy(xpath = "//a[contains(text(),'CS_')]")
    public List<WebElement> listItemId;

    @FindBy(xpath = "//td[contains(text(),'MSC')]")
    public WebElement anyOfAlertId;

    @FindBy(xpath = "//td[contains(text(),'No Items to show')]")
    public WebElement noAnyAlertPresent;

    @FindBy(xpath = ".//span[@id='pagerTextPart']/input")
    public WebElement totalAlertRowsCount;

    @FindBy(xpath = ".//td[@id='cell_1_3']/span")
    public WebElement firstOderIdOnTransactionTab;



}
