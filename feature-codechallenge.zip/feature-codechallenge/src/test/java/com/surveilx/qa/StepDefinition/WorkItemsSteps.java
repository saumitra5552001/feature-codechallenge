package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.Given;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;
import java.util.Random;


public class WorkItemsSteps extends CommonFunctions {
    LoginSteps loginstepsobj = new LoginSteps();
    ResearchDartSteps ResearchDartStepsobj = new ResearchDartSteps();
    NavigationPageObjects navigationpageobj = new NavigationPageObjects(driver);
    PageObject pom = new PageObject(driver);
    WorkbenchWorkItemsPageObjects workitemsobj = new WorkbenchWorkItemsPageObjects(driver);
    ResearchDartPageObjects researchdartobj = new ResearchDartPageObjects(driver);
    public static  String workItemPageWindow;


    @Then("User login successfully and lands on dashboard page")
    public void userLoginSuccessfullyAndLandsOnDashboardPage() throws Throwable {
        navigationpageobj.clickOnNavBar();
        navigationpageobj.verifySideBarMenuName_MSC();
    }

    @Then("User verify and clicks Workbench-Work Items Submenu")
    public void userVerifyAndClicksWorkbenchWorkItemsSubmenu() throws Throwable {
        navigationpageobj.clickOnWorkBenchTitleAndValidateItsName();
        navigationpageobj.clickOnWorkItemTitleAndValidateItsName();
    }

    @Then("User landed on Work Item page")
    public void userLandedOnWorkItemPage() throws Throwable {
        getPageTitle(jsonRead.readStringFromDataJSON("WorkItemsPageTitle"));
    }

    @Then("User selects {string} option from the dropdown")
    public void userSelectsOptionFromTheDropdown(String string) throws Throwable {
        if (!fetchText(pom.dropdownTitleText).equalsIgnoreCase("MSC All Alerts")) {
            verifyAndClick(pom.dropdownTitleText);
            //verifyAndClick(pom.dropdownDownArrow);
            scrollIntoView(pom.dropdownOptionMSCAllAlerts);
            verifyAndClick(pom.dropdownOptionMSCAllAlerts);
            sleep(4);
            workItemPageWindow = getCurrentWindowTitle();
        }
    }

    @And("User refresh the page")
    public void userRefreshThePage() throws Throwable {
        navigationpageobj.clickOnRefreshButtonOnWorkItemPage();
    }


    @And("User validate the number of total alerts present")
    public void userValidateTheNumberOfTotalAlertsPresent() throws Throwable {
        String totalAlertCount = fetchTextWithSpecificAttribute(pom.totalAlertRowsCount, "total_rows");
        Assert.assertEquals(totalAlertCount, jsonRead.readStringFromDataJSON("TotalNumberOfWorkItemRowInRegression"),
                "Total number of alert rows are not matching with expected");
        logPass("Total number of alert rows are" + totalAlertCount);


    }


    @Then("User verifies that any alert present or not on the page")
    public void userVerifiesThatAnyAlertPresentOrNotOnThePage() throws Throwable {
        if (fetchText(pom.anyOfAlertId).contains("MSC")) {
            logPass(driver, "MSC Alerts present");
        } else {
            logFail(driver, "No Alert present for the searched work item");
        }
    }


    @Then("User clicks and open the recent alert ID")
    public void userClicksAndOpenTheRecentAlertID() throws Throwable {
        workitemsobj.clickOnAlertId();
        sleep(2);
    }

    @Then("User landed on Item Details page")
    public void userLandedOnItemDetailsPage() throws Throwable {
        getPageTitle(jsonRead.readStringFromDataJSON("ItemDetailsPageTitle"));
    }

    @Then("User fetch the actual score for the clicked alert Id")
    public void user_fetch_the_actual_score_for_the_clicked_alert_Id() throws Throwable {
        sleep(5);
        workitemsobj.fetchCurrentScoreForClickedAlertId();
    }

    @And("User switch to iFrame {string}")
    public void userSwitchToIframe(String frameName) throws Throwable {
        changeFrameWithFrameName(frameName);
    }

    @Then("User verify work item summary for expanded alert section")
    public void userVerifyWorkItemSummaryForExpandedAlertSection() throws Throwable {
        workitemsobj.validateWorkItemMSCSummaryExpandedSection();
    }

    @Then("User selects analytics view")
    public void userSelectsAnalyticsView() throws Throwable {
        //navigationpageobj.clickOnToggleButtonUnderItemDetails();
        navigationpageobj.clickOnAnalyticsTabUnderItemDetails();
    }

    @Then("User expands the screen by selecting full screen option")
    public void userExpandsTheScreenBySelectingFullScreenOption() throws Throwable {
        navigationpageobj.fullScreenUnderItemDetails();
    }


    @Then("User expands the transaction screen by selecting full screen option")
    public void userExpandsTheTransactionScreenBySelectingFullScreenOption() throws Throwable {
        navigationpageobj.fullScreenUnderItemDetailsTransactionTab();
    }

    @Then("User expands the screen by selecting detach as a new tab")
    public void userExpandsTheScreenBySelectingDetachAsANewTab() throws Throwable {
        navigationpageobj.detachAsANewTabUnderItemDetails();
    }


    @And("User landed on detach section")
    public void userLandedOnDetachSection() throws Throwable {
        getPageTitle(jsonRead.readStringFromDataJSON("DetachSectionPageTitle"));
    }

    @Then("User expands the transaction screen by selecting detach as a new tab")
    public void userExpandsTheTransactionScreenBySelectingDetachAsANewTab() throws Throwable {
        navigationpageobj.detachAsNewTabUnderItemDetailsTransactionTab();
    }

    @Then("User verifies the trading activity")
    public void userVerifiesTheTradingActivity_AlertMSC011() throws Throwable {

        if (fetchText(workitemsobj.tradingActivityDetails).contentEquals("Trade Details")) {
            logPass(driver, "Trading Details available");
        } else {
            logFail(driver, "No Trading Details available for this Product");
        }

        if (fetchText(workitemsobj.markUpMarkDownAnalysisDetails1).contentEquals("Trading Activity - Buy")) {
            logPass(driver, "Mark Up Mark Down Analysis Details available");
        } else {
            logFail(driver, "No Trading Details available for this Product");
        }

        if (fetchText(workitemsobj.markUpMarkDownAnalysisDetails2).contentEquals("Trading Activity - Sell")) {
            logPass(driver, "Mark Up Mark Down Analysis Details available");
        } else {
            logFail(driver, "No Trading Details available for this Product");
        }
    }

    @Then("User verifies the trading activity for MSC ramping")
    public void userVerifiesTheTradingActivityForMSCRamping() throws Throwable {

        if (fetchText(workitemsobj.tradePriceSpikeAnalysis).contentEquals("Trade Price Spike Analysis")) {
            logPass(driver, "Trade Price Spike Analysis available");
        } else {
            logFail(driver, "No Trade Price Spike Analysis Details available for this Product");
        }

        if (fetchText(workitemsobj.dTAIncrease).contentEquals("DTA Increase")) {
            logPass(driver, "DTA Increase Details available");
        } else {
            logFail(driver, "No DTA Increase Details available for this Product");
        }
    }

    @Then("User verifies the thresholds details")
    public void userVerifiesTheThresholdsDetails_AlertMSC011() throws Throwable {
        workitemsobj.thresholdTabOnAnalytics.click();

        if (fetchText(workitemsobj.thresholdLockBackPeriodDetails).contains("Look Back Period")) {
            logPass(driver, "Threshold Details available");
        } else {
            logFail(driver, "No Threshold Details available for this Product");
        }

        if (fetchText(workitemsobj.thresholdPriceThresholdDetails).contains("Price Threshold")) {
            logPass(driver, "Trading Details available");
        } else {
            logFail(driver, "No Threshold Details available for this Product");
        }
    }

    @And("User verifies the thresholds details for MSC ramping alert")
    public void userVerifiesTheThresholdsDetailsForMSCRampingAlert() throws Throwable {
        workitemsobj.thresholdTabOnAnalytics.click();

        if (fetchText(workitemsobj.thresholdDTAIncrease).contains("DTA Increase |")) {
            logPass(driver, "DTA Increase Details available");
        } else {
            logFail(driver, "No DTA Increase Details available for this Product");
        }

        if (fetchText(workitemsobj.rampingThresholdOpeningPrice).contains("Ramping Threshold (Opening Price) |")) {
            logPass(driver, "Ramping Threshold (Opening Price) Details available");
        } else if (fetchText(workitemsobj.rampingThresholdPreviousClose).contains("Ramping Threshold (Previous Close) |")) {
            logPass(driver, "Ramping Threshold (Previous Close) Details available");
        } else {
            logFail(driver, "No Ramping Threshold Details available for this Product");
        }
    }

    @Then("User types specific alert type {string} in the search box")
    public void userTypesSpecificAlertTypeInTheSearchBox(String string) throws Throwable {
        verifyAndEnterText(pom.searchTextBoxOnWorkItemPage, string);
        pressEnterButton(pom.searchTextBoxOnWorkItemPage);
        sleep(4);
    }


    @Then("User verify MSC tab icons on Alerts Details page")
    public void userVerifyMSCTabIconsOnAlertsDetailsPage() throws Throwable {
        workitemsobj.validateMSCTabOnAlertDetailsPage();
        workitemsobj.validateMoreOptionOnAlertDetailsPage();
        sleep(2);
    }


    @Then("User selects Transaction view")
    public void userSelectsTransactionView() throws Throwable {
        navigationpageobj.clickOnTransactionTabUnderItemDetails();
        sleep(8);
    }

    @And("User clicks on Transactions of Related Products tab")
    public void userClicksOnTransactionsOfRelatedProductsTab() throws Throwable {
        navigationpageobj.clickOnTransactionsOfRelatedProductsTab();
        sleep(3);
    }

    @And("User verify Aggregated Executions by Accounts and Cross Product Transactions available")
    public void userVerifyAggregatedExecutionsByAccountsAndCrossProductTransactionsAvailable() throws Throwable {
        workitemsobj.validateTagsUnderTransactionsOfRelatedProducts();
        sleep(3);
    }


    @Then("User verifies that any transaction details available")
    public void userVerifiesThatAnyTransactionDetailsAvailable() throws Throwable {
        sleep(5);
        if (verifyElementPresent(pom.firstOderIdOnTransactionTab)) {
            logPass(driver, "Some alerted transaction available");
        } else {
            logFail(driver, "No alerted transaction available for the searched alert type");
        }
    }

    @Then("User clicks on recent Product Symbol available on Work Item page")
    public void user_clicks_on_recent_product_symbol_available_on_work_item_page() throws Throwable {
        workitemsobj.clickOnProductSymbol();
        sleep(5);
    }

    @Then("User verify that DART navigation is achieved from clicked Product Symbol")
    public void user_verify_that_DART_navigation_is_achieved_from_clicked_Product_Symbol() throws Throwable {
        ResearchDartStepsobj.userLandedOnDARTPage();
        sleep(2);
        workitemsobj.verifyProductSymbolValueOnDartPage();
        sleep(2);
    }

    @Then("Verify Alerted Transaction tab and export functionality")
    public void verify_Alerted_Transaction_tab_and_export_functionality() throws Throwable {
        workitemsobj.clickAndVerifyExportButtonFunctionality();
        sleep(2);
    }


    @Then("User verify Score On MSC All Alerts Page")
    public void user_verify_score_on_msc_all_alerts_page() throws Throwable {
        workitemsobj.verifyScoreOnItemDetailsPage();
        sleep(2);
    }

    @Then("User clicks on Add Note icon")
    public void user_clicks_on_add_note_icon() throws Throwable {
        workitemsobj.clickOnAddNoteIcon();
    }

    @Then("User verify the header on new window")
    public void user_verify_the_header_on_new_window() throws Throwable {
        workitemsobj.verifyTheHeaderOfAddNoteNewWindow();
    }

    @And("User verify that Add Note action can not be completed without note")
    public void user_verify_that_add_note_action_can_not_be_completed_without_note() throws Throwable {
        workitemsobj.validateAddNoteWithoutAddingAnyNote();
    }

    @Then("User clicks on View Notes icon")
    public void user_clicks_on_view_notes_icon() throws Throwable {
        workitemsobj.clickOnViewNotesIcon();
    }

    @Then("User verify the header for View Notes window")
    public void user_verify_the_header_for_view_notes_window() throws Throwable {
        workitemsobj.verifyTheHeaderOfViewNotesNewWindow();
    }

    @Then("User selects Free Text from the dropdown to Add Note")
    public void user_selects_free_text_from_the_dropdown_to_add_note() throws Throwable {
        workitemsobj.selectsFreeTextFromTheDropdown();
    }

    @Then("User add a note and clicks on OK button")
    public void user_add_a_note_and_clicks_on_ok_button() throws Throwable {
        workitemsobj.addNoteInTextArea();
    }

    @Then("User view a added note")
    public void user_view_a_added_note() throws Throwable {
        workitemsobj.viewNotesFunction();
    }

    @Then("User clicks on Change Score option")
    public void user_clicks_on_change_score_option() throws Throwable {
        workitemsobj.clickOnChangeScoreOption();
    }

    @Then("User verify the header for Change Score window")
    public void user_verify_the_header_for_change_score_window() throws Throwable {
        workitemsobj.verifyTheHeaderOfChangeScoreNewWindow();
    }

    @Then("User enters the new score value in text box and clicks on Ok button")
    public void user_enters_the_new_score_value_in_text_box_and_clicks_on_ok_button() throws Throwable {
        workitemsobj.clickAndEnterScoreValue();
    }

    @Then("User verify that score updated properly")
    public void user_verify_that_score_updated_properly() throws Throwable {
        workitemsobj.verifyUpdatedScore();
    }

    @Then("User clicks on View History option")
    public void user_clicks_on_view_history_option() throws Throwable {
        workitemsobj.clickOnViewHistoryOption();
    }

    @Then("User verify the header for View History window")
    public void user_verify_the_header_for_view_history_window() throws Throwable {
        workitemsobj.verifyTheHeaderOfViewHistoryNewWindow();
    }

    @Then("User verify the history line and close the window")
    public void user_verify_the_history_line_and_close_the_window() throws Throwable {
        workitemsobj.viewHistoryFunction();
        workitemsobj.validateRecentHistoryLine();
    }

    @Then("User clicks on Assign icon option")
    public void user_clicks_on_assign_icon_option() throws Throwable {
        workitemsobj.clickOnAssignIconOption();
    }

    @Then("User clicks on Change Step icon option")
    public void user_clicks_on_change_step_icon_option() throws Throwable {
        workitemsobj.clickOnChangeStepIconOption();
    }

    @Then("User clicks on Delete option")
    public void user_clicks_on_delete_option() throws Throwable {
        workitemsobj.clicksOnDeleteOption();
    }

    @Then("User clicks on Edit option")
    public void user_clicks_on_edit_option() throws Throwable {
        workitemsobj.clicksOnEditOption();
    }

    @Then("User clicks on Add to Case Item icon option")
    public void user_clicks_on_add_to_case_item_icon_option() throws Throwable {
        workitemsobj.clickOnAddToCaseItemIconOption();
    }

    @Then("User clicks on Change Step deadline icon option")
    public void user_clicks_on_change_step_deadline_icon_option() throws Throwable {
        workitemsobj.clickOnChangeStepDeadlineIconOption();
    }

    @Then("User selects Show as PDF option")
    public void user_selects_show_as_pdf_option() throws Throwable {
        workitemsobj.selectsShowAsPdfOption();
    }

    @Then("User selects Attachment option and verify the header for attachment window")
    public void user_selects_attachment_option_and_verify_the_header_for_attachment_window() throws Throwable {
        workitemsobj.selectsAttachmentOption();
        workitemsobj.verifyTheHeaderForAttachmentWindow();
    }


    @Then("User verify the header for Change Step window")
    public void user_verify_the_header_for_change_step_window() throws Throwable {
        workitemsobj.verifyTheHeaderOfChangeStepWindow();
    }

    @Then("User verify the header and add a new case item")
    public void user_verify_the_header_and_add_a_new_case_item() throws Throwable {
        workitemsobj.verifyTheHeaderAndAddANewCaseItem();
    }


    @Then("User verify any case item linked and delete functionality for this alert")
    public void user_verify_any_case_item_linked_and_delete_functionality_for_this_alert() throws Throwable {
        workitemsobj.verifyAnyCaseItemLinkedAndDeleteFunctionalityForThisAlert();
    }


    @Then("User verify the header and select a new date and time for Change Step Deadline")
    public void user_verify_the_header_and_select_a_new_date_and_time_for_change_step_deadline() throws Throwable {
        workitemsobj.verifyTheHeaderAndSelectANewDateAndTime();
    }

    @Then("User verify the header for Edit Item window")
    public void user_verify_the_header_for_edit_item_window() throws Throwable {
        workitemsobj.verifyTheHeaderForEditItemWindow();
    }

    @Then("User select and assign business unit")
    public void user_select_and_assign_business_unit() throws Throwable {
        workitemsobj.selectsAndAssignAnotherBU();
    }

    @Then("User select and assign another user functionality")
    public void user_select_and_assign_another_user_functionality() throws Throwable {
        workitemsobj.selectsAndAssignAnotherUser();
    }

    @Then("User verify the header for Change Item User_BU window")
    public void user_verify_the_header_for_change_item_user_bu_window() throws Throwable {
        workitemsobj.verifyTheHeaderOfChangeItemUserBUWindow();
    }

    @Then("User verify the current step and select next step from dropdown")
    public void user_verify_the_current_step_and_select_next_step_from_dropdown() throws Throwable {
        workitemsobj.verifyTheCurrentStepAndSelectNextStepOfAlert();
    }


    @Then("User add note and click on OK button and verify step updated or not")
    public void user_add_note_and_click_on_ok_button_and_verify_step_updated_or_not() throws Throwable {
        workitemsobj.addNoteForChangeStepAndVerifyUpdatedStep();
    }


    @Then("User change the priority")
    public void user_change_the_priority() throws Throwable {
        workitemsobj.changeThePriority();
    }


    @Then("User verify the edit functionality")
    public void user_verify_the_edit_functionality() throws Throwable {
        workitemsobj.verifyTheEditFunctionality();
    }


    @Then("User verify the functionality for PDF option")
    public void user_verify_the_functionality_for_pdf_option() throws Throwable {
        workitemsobj.verifyTheFunctionalityForPDFOption();
    }



}



   /* @Then("Given User did the Initial setup")
    public void given_User_did_the_initial_setup() throws Throwable {
        workitemsobj.backGroundForAllAlertFeatureFile();
    }*/

