package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.CommunicationAnalyticsPageObjects;
import com.surveilx.qa.PageObjects.ExplorePageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class CommunicationAnalyticsSteps extends CommonFunctions {

    CommunicationAnalyticsPageObjects communicationAnalyticsPom = new CommunicationAnalyticsPageObjects(driver);

    @Then("I verify name change functionality for Dashboard$")
    public void iVerifyNameChangeFunctionalityForDashboard() throws Throwable {
        communicationAnalyticsPom.iValidateDashboardNameChangeFunctionalityForDiscard();
        communicationAnalyticsPom.iValidateDashboardNameChangeFunctionalityForConfirm();
    }

    @Then("I verify dashboard set as default page functionality$")
    public void iVerifyDashboardSetAsDefaultPageFunctionality() throws Throwable {
        communicationAnalyticsPom.iValidateDashboardSetAsDefaultCancel();
        communicationAnalyticsPom.iValidateDashboardSetAsDefaultOk();
    }

    @Then("I verify dashboard view with pre-define date filter$")
    public void iVerifyDashboardViewWithPredefineDateFilter() throws Throwable {
        communicationAnalyticsPom.iValidateDashboardWithLastWeekFilter();
        communicationAnalyticsPom.iValidateDashboardWithLast4WeekFilter();
        communicationAnalyticsPom.iValidateDashboardWithBetweenDateFilter();
        communicationAnalyticsPom.pageContentVerification();
    }

    @Then("I verify dashboard view with user-define date filter$")
    public void iVerifyDashboardViewWithUserdefineDateFilter() throws Throwable {
        communicationAnalyticsPom.iValidateDashboardWithBetweenDateFilter();
    }

    @Then("I verify dashboard view date filter and explore date filter same$")
    public void iVerifyDashboardViewDateFilterAndExploreDateFilterSame() throws Throwable {
        communicationAnalyticsPom.iValidateDashboardWithBetweenDateFilter();
        communicationAnalyticsPom.iValidateDashboardDateValueWithExploreDateValue();
    }

    @Then("I verify dashboard view timezone verification$")
    public void iVerifyDashboardViewTimezoneVerification() throws Throwable {
        communicationAnalyticsPom.iValidateDashboardWithBetweenDateFilter();
        communicationAnalyticsPom.iValidateDashboardViewForTimezone();
    }

    @Then("I verify dashboard view in explore page$")
    public void iVerifyDashboardViewInExplore() throws Throwable {
        communicationAnalyticsPom.iNavigateDashboardViewInExplorePage();
        communicationAnalyticsPom.iValidateDashboardViewForExplorePage();
    }
}
