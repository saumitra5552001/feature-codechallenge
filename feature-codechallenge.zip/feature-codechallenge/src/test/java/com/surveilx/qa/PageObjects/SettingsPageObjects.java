package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.Set;

public class SettingsPageObjects extends CommonFunctions {

    public SettingsPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private enum Settings {

        expandNodeMSCAdvancedSettings(By.xpath(".//img[@id='stateImg_279']")),
        expandNodeTradeSurveillance(By.xpath(".//img[@id='stateImg_1']")),
        expandNodeMSCTradeSurveillance(By.xpath(".//img[@id='stateImg_283']")),
        expandNodeSurveilXInvestigate(By.xpath(".//img[@id='stateImg_1160']")),
        expandSubNodeMSCSettingsConfiguration(By.xpath(".//font[@id='nodeText_280']")),
        expandSubNodeMSCInternalSettingsConfiguration(By.xpath(".//font[@id='nodeText_281']")),
        expandSubNodeMSCInternalThresholds(By.xpath(".//font[@id='nodeText_282']")),
        headerMSCSettingsConfiguration(By.xpath(".//div[contains(text(),'MSC Settings Configuration')]")),
        headerMSCInternalSettingsConfiguration(By.xpath(".//div[contains(text(),'MSC Internal Settings Configuration')]")),
        headerMSCInternalThresholds(By.xpath(".//div[contains(text(),'MSC Internal Thresholds')]")),
        headerAlertActivation(By.xpath(".//div[contains(text(),'Alert Activation')]")),
        headerThresholds(By.xpath(".//div[contains(text(),'Thresholds')]")),
        headerOverrideThresholds(By.xpath(".//div[contains(text(),'Override Thresholds')]")),
        headerConfigureMSInvestigate(By.xpath(".//div[contains(text(),'Configure MS - Investigate')]")),
        settingsNavigatorSubNodeAnalyticsActivation(By.xpath(".//font[contains(text(),'Analytics Activation')]")),
        settingsNavigatorSubNodeAnalyticsThresholdsAndOverrides(By.xpath("(.//font[contains(text(),'Analytics Thresholds and Overrides')])[1]")),
        settingsNavigatorSubNodeAllAnalyticsThresholdsAndOverrides(By.xpath(".//font[contains(text(),'All Analytics Thresholds and Overrides')]")),
        settingsNavigatorSubNodeAlertActivation(By.xpath(".//font[contains(text(),'Alert Activation')]")),
        settingsNavigatorSubNodeBehavioral(By.xpath(".//font[contains(text(),'Behavioral')]")),
        settingsNavigatorSubNodeBestExecution(By.xpath(".//font[contains(text(),'Best Execution')]")),
        settingsNavigatorSubNodeFraud(By.xpath(".//font[contains(text(),'Fraud')]")),
        settingsNavigatorSubNodeMarketManipulation(By.xpath("(.//font[contains(text(),'Market Manipulation')])[2]")),
        settingsNavigatorSubNodeThresholds(By.xpath(".//font[@id='nodeText_1156']")),
        SubNodeThresholds(By.xpath(".//img[@id='stateImg_1156']")),
        SubNodeOverrides(By.xpath(".//img[@id='stateImg_1158']")),
        settingsNavigatorSubNodeThresholds_internal(By.xpath(".//font[@id='nodeText_1157']")),
        settingsNavigatorSubNodeOverrides(By.xpath(".//font[@id='nodeText_1158']")),
        settingsNavigatorSubNodeOverrideThresholds(By.xpath(".//font[@id='nodeText_1159']")),
        settingsNavigatorSubNodeConfigureMSInvestigate(By.xpath(".//font[@id='nodeText_1161']")),
        settingsNavigatorSubNodeCancelsCorrectsAndAsOfTrades(By.xpath(".//font[@id='nodeText_2']")),
        settingsNavigatorSubNodeCommonSettings(By.xpath(".//font[@id='nodeText_9']")),
        settingsNavigatorSubNodeCrossMarketManipulation(By.xpath(".//font[@id='nodeText_33']")),
        settingsNavigatorSubNodeFictitiousOrdersIndividual(By.xpath(".//font[@id='nodeText_47']")),
        settingsNavigatorSubNodeFilterLists(By.xpath(".//font[@id='nodeText_56']")),
        settingsNavigatorSubNodeFrontRunningLargeOrders(By.xpath(".//font[@id='nodeText_75']")),
        settingsNavigatorSubNodeFrontRunningExecutions(By.xpath(".//font[@id='nodeText_86']")),
        settingsNavigatorSubNodeHistoricalRateRollover(By.xpath(".//font[@id='nodeText_91']")),
        settingsNavigatorSubNodeInsiderDealing(By.xpath(".//font[@id='nodeText_98']")),
        settingsNavigatorSubNodeLayering(By.xpath(".//font[@id='nodeText_112']")),
        settingsNavigatorSubNodeWatchListExec(By.xpath(".//font[@id='nodeText_380']")),
        settingsNavigatorSubNodeWatchListExecEquities(By.xpath(".//font[@id='nodeText_381']")),
        settingsNavigatorSubNodeWatchListExecEquitiesOverrides(By.xpath(".//font[@id='nodeText_384']")),
        settingsNavigatorSubNodeWatchListExecEquitiesOverridesThresholds(By.xpath(".//font[@id='nodeText_385']")),
        newItemIconOnOverrideThresholds(By.xpath(".//i[@id='icon_create_item']")),
        newPlatformListItemPageHeader(By.xpath(".//div[@class='dialogHeader']")),
        editPlatformListItemPageHeader(By.xpath(".//div[@class='dialogHeader']")),
        advanceSearchOptionForThresholdName(By.xpath(".//span[@class='clsButton clsBuPicker']")),
        thresholdNameTextBox(By.xpath(".//input[@id='platformListField_800']")),
        settingsNavigatorSubNodeWatchListExecEquitiesThresholds(By.xpath(".//font[@id='nodeText_383']")),
        WatchListExecEquitiesMainNodeThresholds(By.xpath(".//font[@id='nodeText_382']")),
        thresholdDescriptionTextBox(By.xpath(".//input[@id='platformListField_801']")),
        overrideTypeTextBox(By.xpath(".//input[@id='platformListField_802']")),
        entityNameOrRuleTextBox(By.xpath(".//input[@id='platformListField_832']")),
        thresholdValueTextBox(By.xpath(".//input[@id='platformListField_833']")),
        ruleDescriptionTextBox(By.xpath(".//input[@id='platformListField_831']")),
        rulePriorityTextBox(By.xpath(".//input[@id='platformListField_805']")),
        saveButtonOnNewPlatformListItem(By.xpath(".//td[@id='textButton_editInternalListItem_SubmitButton']")),
        selectThresholdNameFromTheList(By.xpath(".//tr[@class='dataTable1Row1']/td[1]")),
        oKButtonOnselectThresholdNamePage(By.xpath(".//td[@id='textButton__SubmitButton']")),
        verifyFirstOrNewlyCreatedThresholdName(By.xpath("(.//span[@class='ag-cell-value'])[5]")),
        deleteOptionOnOverrideThresholdPage(By.xpath(".//i[@id='icon_delete_item']")),
        noRecordToShowMessage(By.xpath(".//div[@class='ag-overlay-wrapper ag-layout-normal ag-overlay-no-rows-wrapper']")),
        editLinkForAvailableThresholdName(By.xpath("(.//span[@class='ag-cell-value'])[9]")),
        editLinkForAlertActivation(By.xpath("(.//span[@class='ag-cell-value'])[2]")),
        thresholdValueEditPlatformListItem(By.xpath(".//input[@id='platformListField_831']")),
        saveButtonOnEditPlatformListItem(By.xpath(".//td[@id='textButton_editInternalListItem_SubmitButton']")),
        updatedThresholdValue(By.xpath("(.//span[@class='ag-cell-value'])[14]")),
        isActiveStatusOnFromDropdown(By.xpath(".//select[@id='platformListField_825']")),
        isActiveStatusOnAlertActivationpage(By.xpath("(.//span[@class='ag-cell-value'])[7]")),

        ;
        private By findBy;

        Settings(By locator) {
            this.findBy = locator;
        }
    }

    @FindBy(xpath = "//font[@id='nodeText_1']")
    WebElement SettingsNavigatorNodeTradeSurveillance;

    @FindBy(xpath = ".//font[@id='nodeText_279']")
    WebElement SettingsNavigatorNodeMSCAdvancedSettings;

    @FindBy(xpath = ".//font[@id='nodeText_283']")
    WebElement SettingsNavigatorNodeMSCTradeSurveillance;

    @FindBy(xpath = ".//font[@id='nodeText_1160']")
    WebElement SettingsNavigatorNodeSurveilXInvestigate;

    @FindBy(xpath = ".//input[@id='platformListField_831']")
    WebElement thresholdValueEditPlatformListItem;

    @FindBy(xpath = ".//select[@id='platformListField_825']")
    WebElement isActiveStatusOnEditPlatformListItem;

    @FindBy(xpath = "(.//span[@class='ag-cell-value'])[7]")
    WebElement isActiveStatusOnAlertActivationpage1;


    public void verifyNodesAvailableForSettingsNavigator() throws Throwable {
        verifyText(SettingsNavigatorNodeTradeSurveillance, "Trade Surveillance");
        sleep(1);
        verifyText(SettingsNavigatorNodeMSCAdvancedSettings, "MSC Advanced Settings");
        sleep(1);
        verifyText(SettingsNavigatorNodeMSCTradeSurveillance, "MSC Trade Surveillance");
        sleep(1);
        verifyText(SettingsNavigatorNodeSurveilXInvestigate, "Surveil-X Investigate");
        sleep(1);
    }

    public void verifyAndClickOnExpandedOption(String node_type) throws Throwable {

        if (node_type.equalsIgnoreCase("Trade Surveillance")) {
            verifyAndClick(Settings.expandNodeTradeSurveillance.findBy);
        }
        if (node_type.equalsIgnoreCase("MSC Advanced Settings")) {
            verifyAndClick(Settings.expandNodeMSCAdvancedSettings.findBy);
        }
        if (node_type.equalsIgnoreCase("MSC Trade Surveillance")) {
            verifyAndClick(Settings.expandNodeMSCTradeSurveillance.findBy);
        }
        if (node_type.equalsIgnoreCase("Surveil-X Investigate")) {
            verifyAndClick(Settings.expandNodeSurveilXInvestigate.findBy);
        }
    }


    public void verifyAndClickSubNodeInMSCAdvancedSettings(String sub_node_type_MSCAdvancedSetting) throws Throwable {
        if (sub_node_type_MSCAdvancedSetting.equalsIgnoreCase("MSC Settings Configuration")) {
            verifyAndClick(Settings.expandSubNodeMSCSettingsConfiguration.findBy);
            sleep(2);
            getPageTitle(jsonRead.readStringFromDataJSON("MSCSettingsConfigurationPageTitle"));
            sleep(2);
            verifyText(Settings.headerMSCSettingsConfiguration.findBy, "MSC Settings Configuration");
        }
        if (sub_node_type_MSCAdvancedSetting.equalsIgnoreCase("MSC Internal Settings Configuration")) {
            verifyAndClick(Settings.expandSubNodeMSCInternalSettingsConfiguration.findBy);
            sleep(2);
            getPageTitle(jsonRead.readStringFromDataJSON("MSCInternalSettingsConfigurationPageTitle"));
            sleep(2);
            verifyText(Settings.headerMSCInternalSettingsConfiguration.findBy, "MSC Internal Settings Configuration");
        }
        if (sub_node_type_MSCAdvancedSetting.equalsIgnoreCase("MSC Internal Thresholds")) {
            verifyAndClick(Settings.expandSubNodeMSCInternalThresholds.findBy);
            sleep(2);
            getPageTitle(jsonRead.readStringFromDataJSON("MSCInternalThresholdsPageTitle"));
            sleep(2);
            verifyText(Settings.headerMSCInternalThresholds.findBy, "MSC Internal Thresholds");
        }
    }

    public void verifySubNodesAvailableForMSCTradeSurveillance() throws Throwable {
        verifyText(Settings.settingsNavigatorSubNodeAnalyticsActivation.findBy, "Analytics Activation");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeAnalyticsThresholdsAndOverrides.findBy, "Analytics Thresholds and Overrides");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeAllAnalyticsThresholdsAndOverrides.findBy, "All Analytics Thresholds and Overrides");
        sleep(1);
    }

    public void verifySubNodesAvailableForTradeSurveillance() throws Throwable {
        verifyText(Settings.settingsNavigatorSubNodeCancelsCorrectsAndAsOfTrades.findBy, "Cancels/Corrects and As-Of Trades");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeCommonSettings.findBy, "Common Settings");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeCrossMarketManipulation.findBy, "Cross Market Manipulation");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeFictitiousOrdersIndividual.findBy, "Fictitious Orders Individual");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeFilterLists.findBy, "Filter Lists");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeFrontRunningLargeOrders.findBy, "Front Running Large Orders");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeFrontRunningExecutions.findBy, "Front Running Executions");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeHistoricalRateRollover.findBy, "Historical Rate Rollover");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeInsiderDealing.findBy, "Insider Dealing");
        sleep(1);
        verifyText(Settings.settingsNavigatorSubNodeLayering.findBy, "Layering");
        sleep(1);
    }


    public void clickAndValidateSubNodeInMSCTradeSurveillance(String sub_node_type_MSCTradeSurveillance) throws Throwable {
        if (sub_node_type_MSCTradeSurveillance.equalsIgnoreCase("Analytics Activation")) {
            verifyAndClick(Settings.settingsNavigatorSubNodeAnalyticsActivation.findBy);
            sleep(2);
            verifyAndClick(Settings.settingsNavigatorSubNodeAlertActivation.findBy);
            sleep(2);
            getPageTitle(jsonRead.readStringFromDataJSON("AlertActivationPageTitle"));
            sleep(2);
            verifyText(Settings.headerAlertActivation.findBy, "Alert Activation");
        }
        if (sub_node_type_MSCTradeSurveillance.equalsIgnoreCase("Analytics Thresholds and Overrides")) {
            verifyAndClick(Settings.settingsNavigatorSubNodeAnalyticsThresholdsAndOverrides.findBy);
            sleep(2);
            verifyText(Settings.settingsNavigatorSubNodeBehavioral.findBy, "Behavioral");
            verifyText(Settings.settingsNavigatorSubNodeBestExecution.findBy, "Best Execution");
            verifyText(Settings.settingsNavigatorSubNodeFraud.findBy, "Fraud");
            verifyText(Settings.settingsNavigatorSubNodeMarketManipulation.findBy, "Market Manipulation");
        }
        if (sub_node_type_MSCTradeSurveillance.equalsIgnoreCase("All Analytics Thresholds and Overrides")) {
            verifyAndClick(Settings.settingsNavigatorSubNodeAllAnalyticsThresholdsAndOverrides.findBy);
            if (fetchText(Settings.settingsNavigatorSubNodeThresholds.findBy).contains("Thresholds")) {
                sleep(5);
                verifyAndClick(Settings.SubNodeThresholds.findBy);
                sleep(2);
                verifyAndClick(Settings.settingsNavigatorSubNodeThresholds_internal.findBy);
                sleep(2);
                getPageTitle(jsonRead.readStringFromDataJSON("ThresholdsPageTitle"));
                sleep(2);
                verifyText(Settings.headerThresholds.findBy, "Thresholds");
            }
            sleep(5);
            if (fetchText(Settings.settingsNavigatorSubNodeOverrides.findBy).contains("Overrides")) {
                sleep(5);
                verifyAndClick(Settings.SubNodeOverrides.findBy);
                sleep(2);
                verifyAndClick(Settings.settingsNavigatorSubNodeOverrideThresholds.findBy);
                sleep(2);
                getPageTitle(jsonRead.readStringFromDataJSON("OverrideThresholdsPageTitle"));
                sleep(2);
                verifyText(Settings.headerOverrideThresholds.findBy, "Override Thresholds");
            }
        }
    }

    public void clickAndValidateSubNodeInSurveilXInvestigate(String sub_node_type_SurveilXInvestigate) throws Throwable {
        if (sub_node_type_SurveilXInvestigate.equalsIgnoreCase("Configure MS - Investigate")) {
            sleep(2);
            verifyAndClick(Settings.settingsNavigatorSubNodeConfigureMSInvestigate.findBy);
            sleep(2);
            getPageTitle(jsonRead.readStringFromDataJSON("ConfigureMSInvestigatePageTitle"));
            sleep(2);
            verifyText(Settings.headerConfigureMSInvestigate.findBy, "Configure MS - Investigate");
            sleep(2);
        }

    }

    public void verifyAndClickedOnOverrideThresholdsUnderBehavioral() throws Throwable {
        verifyAndClick(Settings.settingsNavigatorSubNodeBehavioral.findBy);
        sleep(1);
        verifyAndClick(Settings.settingsNavigatorSubNodeWatchListExec.findBy);
        sleep(1);
        verifyAndClick(Settings.settingsNavigatorSubNodeWatchListExecEquities.findBy);
        sleep(1);
        verifyAndClick(Settings.settingsNavigatorSubNodeWatchListExecEquitiesOverrides.findBy);
        sleep(1);
        verifyAndClick(Settings.settingsNavigatorSubNodeWatchListExecEquitiesOverridesThresholds.findBy);
        sleep(1);
    }


    public void createdNewOverrideThresholds() throws Throwable {
        switchToNewWindow();
        getPageTitle(jsonRead.readStringFromDataJSON("OverrideThresholdsPageTitle"));
        String overrideThresholdWindowTitle = getCurrentWindowTitle();
        sleep(2);
        verifyText(Settings.headerOverrideThresholds.findBy, "Override Thresholds");
        sleep(1);
        verifyAndClick(Settings.newItemIconOnOverrideThresholds.findBy);
        switchToNewWindow();
        maximizeWindow();
        String newPlatformListItemeWindowTitle = getCurrentWindowTitle();
        sleep(2);
        getPageTitle(jsonRead.readStringFromDataJSON("newPlatformListItemPageTitle"));
        verifyText(Settings.newPlatformListItemPageHeader.findBy, "New Platform List Item");
        sleep(2);

        verifyAndClick(Settings.advanceSearchOptionForThresholdName.findBy);
        switchToNewWindow();
        maximizeWindow();
        String selectThresholdNameWindowTitle = getCurrentWindowTitle();
        sleep(2);
        verifyAndClick(Settings.selectThresholdNameFromTheList.findBy);
        sleep(1);
        verifyAndClickForChildWindow(Settings.oKButtonOnselectThresholdNamePage.findBy);
        switchToDefaultWindow();
        verifyAndEnterText(Settings.entityNameOrRuleTextBox.findBy, "@ADV30==120000");
        verifyAndEnterText(Settings.thresholdValueTextBox.findBy, "1");
        verifyAndEnterText(Settings.ruleDescriptionTextBox.findBy, "@ADV30==120000 equity");
        verifyAndEnterText(Settings.rulePriorityTextBox.findBy, "1");
        sleep(2);
        verifyAndClickForChildWindow(Settings.saveButtonOnNewPlatformListItem.findBy);

        Set<String> allOpenWindowTitle = getAllWindowTitles();
        for (String handle : allOpenWindowTitle) {
            if (!handle.equals(parentWindow) && !handle.equals(newPlatformListItemeWindowTitle))
                driver.switchTo().window(overrideThresholdWindowTitle);
        }
        verifyAndClick(Settings.verifyFirstOrNewlyCreatedThresholdName.findBy);
        sleep(4);
        logInfo("User created new override thresholds");
    }


    public void deleteNewlyCreatedOverrideThresholds() throws Throwable {
        verifyAndClick(Settings.verifyFirstOrNewlyCreatedThresholdName.findBy);
        sleep(2);
        verifyAndClick(Settings.deleteOptionOnOverrideThresholdPage.findBy);
        sleep(2);
        switchAndAcceptAlert();
        sleep(2);
        fetchText(Settings.noRecordToShowMessage.findBy);
        logInfo("User deleted newly created override thresholds successfully");
    }


    public void verifyAndClickedOnThresholdNodesUnderBehavioral() throws Throwable {
        verifyAndClick(Settings.settingsNavigatorSubNodeBehavioral.findBy);
        sleep(1);
        verifyAndClick(Settings.settingsNavigatorSubNodeWatchListExec.findBy);
        sleep(1);
        verifyAndClick(Settings.settingsNavigatorSubNodeWatchListExecEquities.findBy);
        sleep(1);
        verifyAndClick(Settings.WatchListExecEquitiesMainNodeThresholds.findBy);
        sleep(1);
        verifyAndClick(Settings.settingsNavigatorSubNodeWatchListExecEquitiesThresholds.findBy);
        sleep(1);
    }


    public void clickedOnEditLinkAndAbleToEditThresholdValue() throws Throwable {
        switchToNewWindow();
        getPageTitle(jsonRead.readStringFromDataJSON("ThresholdsPageTitle"));
        sleep(2);
        verifyText(Settings.headerThresholds.findBy, "Thresholds");
        sleep(1);
        verifyAndClick(Settings.editLinkForAvailableThresholdName.findBy);
        sleep(2);
        switchToNewWindow();
        maximizeWindow();
        getPageTitle(jsonRead.readStringFromDataJSON("editPlatformListItemPageTitle"));
        verifyText(Settings.editPlatformListItemPageHeader.findBy, "Edit Platform List Item");
        sleep(2);
        String currentThresholdValue = fetchTextWithSpecificAttribute(thresholdValueEditPlatformListItem, "value");
        if (currentThresholdValue.contentEquals("1"))
            verifyAndEnterText(thresholdValueEditPlatformListItem, "10");
        else verifyAndEnterText(thresholdValueEditPlatformListItem, "1");
        sleep(2);
        verifyAndClickForChildWindow(Settings.saveButtonOnEditPlatformListItem.findBy);
        switchToDefaultWindow();
        verifyAndClick(Settings.updatedThresholdValue.findBy);
        sleep(2);
        //String updatedThresholdValue = fetchText(Settings.updatedThresholdValue.findBy);
        // Assert.assertEquals("","","");
    }

    public void userVerifyTheActivateAndDeactivateAlertFunctionality() throws Throwable {
        verifyAndClick(Settings.editLinkForAlertActivation.findBy);
        sleep(1);
        switchToNewWindow();
        maximizeWindow();
        getPageTitle(jsonRead.readStringFromDataJSON("editPlatformListItemPageTitle"));
        verifyText(Settings.editPlatformListItemPageHeader.findBy, "Edit Platform List Item");
        sleep(2);
        String currentIsActiveStatus = fetchTextWithSpecificAttribute(isActiveStatusOnEditPlatformListItem, "value");
        if (currentIsActiveStatus.contentEquals("True")) {
            sleep(2);
            selectElementFromDropdown(Settings.isActiveStatusOnFromDropdown.findBy, "False");
        } else {
            sleep(2);
            selectElementFromDropdown(Settings.isActiveStatusOnFromDropdown.findBy, "True");
        }
        sleep(2);
        verifyAndClickForChildWindow(Settings.saveButtonOnEditPlatformListItem.findBy);
        switchToDefaultWindow();
        verifyAndClick(Settings.isActiveStatusOnAlertActivationpage.findBy);
       // String updatedIsActiveStatus = fetchTextWithSpecificAttribute(isActiveStatusOnAlertActivationpage1, "value");
        //Assert.assertNotEquals("currentIsActiveStatus", "updatedIsActiveStatus", "Activate and deactivate alert fuctionality working fine.");

    }
}
