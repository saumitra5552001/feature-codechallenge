package com.surveilx.qa.Utils;

public class PropertyUtility {
}
