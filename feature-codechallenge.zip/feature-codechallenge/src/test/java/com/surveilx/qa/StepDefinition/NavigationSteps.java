package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.NavigationPageObjects;
import com.surveilx.qa.PageObjects.SupervisionPageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class NavigationSteps extends CommonFunctions {

    NavigationPageObjects navigationpom = new NavigationPageObjects(driver);

    @Then("I verify default RCM Sidebar menu display status$")
    public void iVerifyDefaultMenuDisplayStatus() throws Throwable {
        navigationpom.validateDefaultRCMSideBarMenuDisplayStatus();
    }

    @And("I verify Side bar menu tile and verify its name$")
    public void iVerifySideBarMenuTileAndVerifyItsName() throws Throwable {
        //WorkBench Validation
        navigationpom.clickOnNavBar();
        navigationpom.verifySideBarMenuName();
    }


    @Then("I verify Work Items View Submenu$")
    public void iVerifyWorkItemsViewSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnWorkBenchTileAndValidateItsName();
        navigationpom.clickOnWorkItemViewsTileAndValidateItsName();
    }

    @Then("I verify Scenario Items Submenu$")
    public void iVerifyScenarioItemsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnWorkBenchTileAndValidateItsName();
        navigationpom.clickOnScenarioItemsTileAndValidateItsName();
    }

    @Then("I verify Observe Policies Submenu$")
    public void iVerifyObservePoliciesSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnCommunicationPolicyTileAndValidateItsName();
        navigationpom.clickOnObservePoliciesTileAndValidateItsName();
    }

    @Then("I verify Review Selection Submenu$")
    public void iVerifyReviewSelectionSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnCommunicationPolicyTileAndValidateItsName();
        navigationpom.clickOnReviewSelectionTileAndValidateItsName();
    }

    @Then("I verify Queue Manager Submenu$")
    public void iVerifyQueueManagerSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnCommunicationPolicyTileAndValidateItsName();
        navigationpom.clickOnQueueManagerTileAndValidateItsName();
    }

    @Then("I verify Audit History Submenu$")
    public void iVerifyAuditHistorySubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnCommunicationPolicyTileAndValidateItsName();
        navigationpom.clickOnAuditHistoryTileAndValidateItsName();
    }

    @Then("I verify Thresholds Submenu$")
    public void iVerifyThresholdsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnThresholdsTileAndValidateItsName();
    }

    @Then("I verify References Submenu$")
    public void iVerifyReferencesSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnReferencesTileAndValidateItsName();
    }

    @Then("I verify Lists Submenu$")
    public void iVerifyListsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnListsTileAndValidateItsName();
    }

    @Then("I verify Disclaimer Manager Submenu$")
    public void iVerifyDisclaimerManagerSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnDisclaimerManagerTileAndValidateItsName();
    }

    @Then("I verify Settings Navigator Submenu$")
    public void iVerifySettingsNavigatorSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnSettingsNavigatorTileAndValidateItsName();
    }

    @Then("I verify Platform Lists Submenu$")
    public void iVerifyPlatformListsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnPlatformListsTileAndValidateItsName();
    }

    @Then("I verify Entity Management Submenu$")
    public void iVerifyEntityManagementSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnEntityManagementTileAndValidateItsName();
    }

    @Then("I verify Nexidia Search Grid Submenu$")
    public void iVerifyNexidiaSearchGridSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnNexidiaSearchGridTileAndValidateItsName();
    }

    @Then("I verify Field Configuration Submenu$")
    public void iVerifyFieldConfigurationSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnFieldConfigurationTileAndValidateItsName();
    }

    @Then("I verify View Assignments Submenu$")
    public void iVerifyViewAssignmentsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnFieldConfigurationTileAndValidateItsName();
    }

    @Then("I verify Labels Submenu$")
    public void iVerifyLabelsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnLabelsTileAndValidateItsName();
    }

    @Then("I verify Global Settings Submenu$")
    public void iVerifyGlobalSettingsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnGlobalSettingsTileAndValidateItsName();
    }

    @Then("I verify Report Delivery Submenu$")
    public void iVerifyReportDeliverySubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnReportDeliveryTileAndValidateItsName();
    }

    @Then("I verify Audio Player Submenu$")
    public void iVerifyAudioPlayerSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnAudioPlayerTileAndValidateItsName();
    }

    @Then("I verify Scenario Configuration Submenu$")
    public void iVerifyScenarioConfigurationSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnScenarioConfigurationTileAndValidateItsName();
    }

    @Then("I verify Smart Index Configuration Submenu$")
    public void iVerifySmartIndexConfigurationSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnSmartIndexConfigurationTileAndValidateItsName();
    }

    @Then("I verify NTR Clusters Administration Submenu$")
    public void iVerifyNTRClustersAdministrationSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnNTRClustersAdministrationsTileAndValidateItsName();
    }

    @Then("I verify NTR Clusters Status Submenu$")
    public void iVerifyNTRClustersStatusSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnNTRClustersStatusTileAndValidateItsName();
    }

    @Then("I verify Reporting Configuration Submenu$")
    public void iVerifyReportingConfigurationSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnSettingsTileAndValidateItsName();
        navigationpom.clickOnReportingConfigurationsTileAndValidateItsName();
    }

    @Then("I verify Communication Analytics Submenu$")
    public void iVerifyCommunicationAnalyticsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnDashboardsTileAndValidateItsName();
        navigationpom.clickOnCommunicationAnalyticsTileAndValidateItsName();
    }

    @Then("I verify Cases Submenu$")
    public void iVerifyCasesSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnCasesTileAndValidateItsName();
    }

    @Then("I verify On-Demand Report Submenu$")
    public void iVerifyOnDemandReportSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnResearchTileAndValidateItsName();
        navigationpom.clickOnOnDemandReportsTileAndValidateItsName();
    }

    @Then("I verify Explore Submenu navigation$")
    public void iVerifyExplorerSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnResearchTileAndValidateItsName();
        navigationpom.clickOnExploreTileAndValidateItsName();
    }

    @Then("I verify Transcription Queue Submenu$")
    public void iVerifyTranscriptionQueueSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnMonitoringTileAndValidateItsName();
        navigationpom.clickOnTranscriptionQueueTileAndValidateItsName();
    }

    @Then("I verify Alarms Submenu$")
    public void iVerifyAlarmsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnMonitoringTileAndValidateItsName();
        navigationpom.clickOnAlarmsTileAndValidateItsName();
    }

    @Then("I verify Jobs Submenu$")
    public void iVerifyJobsSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnConnectorsTileAndValidateItsName();
        navigationpom.clickOnJobTileAndValidateItsName();
    }

    @Then("I verify Legacy NTR Connector Submenu$")
    public void iVerifyLegacyNTRConnectorSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnConnectorsTileAndValidateItsName();
        navigationpom.clickOnLegacyNTRConnectorTileAndValidateItsName();
    }

    @Then("I verify Network Voice Connector Submenu$")
    public void iVerifyNetworkVoiceConnectorSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnConnectorsTileAndValidateItsName();
        navigationpom.clickOnNetworkVoiceConnectorTileAndValidateItsName();
    }

    @Then("I verify NICE Trading Recording Submenu$")
    public void iVerifyNICETradingRecordingSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnConnectorsTileAndValidateItsName();
        navigationpom.clickOnNICETradingRecordingTileAndValidateItsName();
    }

    @Then("I verify NIM Connector Submenu$")
    public void iVerifyNIMConnectorSubmenu() throws Throwable {
        navigationpom.clickOnNavBar();
        navigationpom.clickOnConnectorsTileAndValidateItsName();
        navigationpom.clickOnNIMConnectorTileAndValidateItsName();
    }


}
