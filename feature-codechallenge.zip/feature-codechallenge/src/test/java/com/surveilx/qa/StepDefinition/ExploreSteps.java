package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.ExplorePageObjects;
import com.surveilx.qa.PageObjects.NavigationPageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

import java.io.IOException;

public class ExploreSteps extends CommonFunctions {

    ExplorePageObjects explorepom = new ExplorePageObjects(driver);

    @Then("I verify number of interaction as \"([^\"]*)\" in explore page for Text Input as \"([^\"]*)\"$")
    public void iVerifyNumberOfInteractionsInExplorePageForTextInput(String count,String word) throws Throwable {
        explorepom.iValidateNumberOfInteractionsInExplorePageForTextInput(word,count);
    }

    @And("I filter interactions via Channel option as \"([^\"]*)\"$")
    public void iFilterInteractionsViaSourceOption(String itemType) throws Throwable {
        explorepom.iInsertFilterViaSourceOption(itemType);
    }

    @Then("I verify interaction in Explore as \"([^\"]*)\"$")
    public void iVerifyInteractionInExplore(String itemType) throws Throwable {
        explorepom.iValidateInteractionInExplore(itemType);
    }

    @Then("I verify timezone in Explore as \"([^\"]*)\"$")
    public void iVerifyTimezoneInExplore(String itemType) throws Throwable {
        explorepom.timeZoneVerification();
        explorepom.timeZoneVerification();
        explorepom.timeZoneVerification();
        if(itemType.equalsIgnoreCase("Voice")){
            explorepom.timeZoneVerificationForPlayerTime();
            explorepom.timeZoneVerificationForPlayerTime();
            explorepom.timeZoneVerificationForPlayerTime();
        }
        if(itemType.equalsIgnoreCase("Chat")){
            explorepom.timeZoneVerificationForChatTime();
            explorepom.timeZoneVerificationForChatTime();
            explorepom.timeZoneVerificationForChatTime();
        }
    }

    @Then("I verify number of interaction as \"([^\"]*)\" in facet filter functionality as \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iVerifyNumberOfInteractionsInFacetFilterFunctionality(String count,String menu,String subMenu) throws Throwable {
        explorepom.iValidateNumberOfInteractionsInFacetFilterFunctionality(menu,subMenu,count);
    }

    @Then("I create filter as \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iCreateFilterAs(String menu,String subMenu) throws Throwable {
        explorepom.iCreateFilterAs(menu,subMenu);
    }

    @Then("I open Interaction for word as \"([^\"]*)\"$")
    public void iOpenInteractionForWordAs(String word) throws Throwable {
        explorepom.iOpenInteractionForWord(word);
    }

    @Then("I open Interaction$")
    public void iOpenInteraction() throws Throwable {
        explorepom.iOpenInteraction();
    }

    @Then("I download interaction$")
    public void iDownloadInteraction() throws Throwable {
        explorepom.iDownloadInteraction();
    }

    @Then("I check filter via date facet$")
    public void iCheckFilterViaDateFacet() throws Throwable {
        explorepom.iCheckFilterForDateFacet();
    }

    @Then("I verify Interaction for \"([^\"]*)\" as \"([^\"]*)\"$")
    public void iVerifyInteractionForWordAs(String word,String fileType) throws Throwable {
        explorepom.iValidateInteraction(word,fileType);
    }

    @Then("I verify save search functionality$")
    public void iVerifySaveSearchFunctionality() throws Throwable {
        explorepom.iValidateSaveSearchFunctionality();
    }

    @Then("I verify default search functionality$")
    public void iVerifyDefaultSearchFunctionality() throws Throwable {
        explorepom.iValidateDefaultSearchFunctionality();
    }

    @Then("I verify delete search functionality$")
    public void iVerifyDeleteSearchFunctionality() throws Throwable {
        explorepom.iValidateDeleteSearchFunctionality();
    }

    @Then("I verify no of interactions according to \"([^\"]*)\"$")
    public void iVerifyNoOfInteractionsAccordingToSubmenu(String subMenu) throws Throwable {
        explorepom.iValidateNoOfInteractionsAccordingToSubmenu(subMenu);
    }

    @And("I add new Scenario for \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iAddNewScenario(String valueStatus,String valueRole) throws Throwable {
        explorepom.iAddScenario(valueStatus,valueRole);
    }

    @And("I add interactions in scenario \"([^\"]*)\" and count verification$")
    public void iAddInteractionsInScenarioAndCountVerification(String countScenario) throws Throwable {
        explorepom.iAddInteractionsInScenario(countScenario);
        explorepom.iValidateCountOfInteractions(countScenario);
    }

    @Then("I do interaction verification$")
    public void iDoInteractionVerification() throws Throwable {
        explorepom.iDoInteractionValidation();
    }

    @Then("I compare Scenario Item and Investigate page$")
    public void iCompareScenarioItemAndInvestigatePage() throws Throwable {
        explorepom.iVerifyScenarioItemWithInvestigatePage();
    }

    @Then("I create work items$")
    public void iCreateWorkItems() throws Throwable {
        explorepom.iCreateWorkItem();
    }

    @Then("I verify sorting as \"([^\"]*)\"$")
    public void iVerifySorting(String sortType) throws Throwable {
        explorepom.iValidateSorting(sortType);
    }
}
