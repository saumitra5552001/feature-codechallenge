package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class HeaderPageObject extends CommonFunctions {

    public HeaderPageObject(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private enum Header{
        imageApplicationLogo(By.id("rcmLogo")),
        labelWorkFlow(By.xpath("//li[@title='Workflow']")),
        labelEntityInsights(By.xpath("//li[@title='Entity Insights']")),
        labelCommunicationWorkItem(By.xpath("//span[contains(text(),'Communication Work Item')]")),
        labelIssueId(By.xpath("//span[contains(text(),'Issue ID')]")),
        labelIssueDate(By.xpath("//span[contains(text(),'Issue Date')]")),
        labelBusinessUnit(By.xpath("//span[contains(text(),'Business Unit')]")),
        labelStep(By.xpath("//span[contains(text(),'Step')]")),
        labelScore(By.xpath("//span[contains(text(),'Score')]")),
        labelItemType(By.xpath("(//div[contains(text(),'Item Type')])[2]")),
        valueItemType(By.xpath("(//div[contains(text(),'Item Type')])[2]/../div[2]")),
        labelOwner(By.xpath("(//div[contains(text(),'Owner')])[1]")),
        valueOwner(By.xpath("(//div[contains(text(),'Owner')])[1]/../div[2]")),
        labelItemDate(By.xpath("(//div[contains(text(),'Item Date')])[1]")),
        valueItemDate(By.xpath("(//div[contains(text(),'Item Date')])[1]/../div[2]")),
        labelTo(By.xpath("(//div[contains(text(),'To')])[2]")),
        valueTo(By.xpath("(//div[contains(text(),'To')])[2]/../div[2]")),
        labelFrom(By.xpath("(//div[contains(text(),'From')])[2]")),
        valueFrom(By.xpath("(//div[contains(text(),'From')])[2]/../div[2]")),
        labelDuration(By.xpath("(//div[contains(text(),'Duration')])[2]")),
        valueDuration(By.xpath("(//div[contains(text(),'Duration')])[2]/../div[2]")),
        labelScore1(By.xpath("(//div[contains(text(),'Score')])[1]")),
        valueScore1(By.xpath("(//div[contains(text(),'Score')])[1]/../div[2]")),
        labelSender(By.xpath("(//div[@title='Sender'])[2]")),
        valueSender(By.xpath("(//div[@title='Sender'])[2]/../div[2]")),
        labelReceiver(By.xpath("(//div[@title='Receiver'])[2]")),
        valueReceiver(By.xpath("(//div[@title='Receiver'])[2]/../div[2]")),
        labelNumberOfParticipants(By.xpath("(//div[contains(text(),'Number of Participants')])[2]")),
        valueNumberOfParticipants(By.xpath("(//div[contains(text(),'Number of Participants')])[2]/../div[2]")),
        labelPublisher(By.xpath("(//div[contains(text(),'Publisher')])[2]")),
        valuePublisher(By.xpath("(//div[contains(text(),'Publisher')])[2]/../div[2]")),
        labelAuthor(By.xpath("(//div[contains(text(),'Author')])[2]")),
        valueAuthor(By.xpath("(//div[contains(text(),'Author')])[2]/../div[2]")),
        labelAttachmentName(By.xpath("(//div[contains(text(),'Attachment Name')])[2]")),
        valueAttachmentName(By.xpath("(//div[contains(text(),'Attachment Name')])[2]/../div[2]")),
        imageSummaryExpanded(By.id("expandedSummaryIcon")),
        labelSummaryDetails(By.xpath("(//div[contains(text(),'Summary Details')])[1]")),
        labelDescription(By.xpath("(//span[contains(text(),'Description')])[1]")),
        labelSummaryItemType(By.xpath("(//div[contains(text(),'Item Type')])[1]")),
        valueSummaryItemType(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[1]")),
        labelSummarySender(By.xpath("(//div[contains(text(),'Sender')])[1]")),
        labelSummaryReceiver(By.xpath("(//div[contains(text(),'Receiver')])[1]")),
        labelSummaryAttachment(By.xpath("(//div[contains(text(),'Attachment')])[1]")),
        labelSummarySource(By.xpath("(//div[contains(text(),'Source')])[1]")),
        labelSummarySentiment(By.xpath("(//div[contains(text(),'Sentiment')])[1]")),
        labelSummaryKeyPhrases(By.xpath("(//div[contains(text(),'Key Phrases')])[1]")),
        labelSummaryConcepts(By.xpath("(//div[contains(text(),'Concepts')])[1]")),
        labelSummaryCompaniesMentioned(By.xpath("(//div[contains(text(),'Companies Mentioned')])[1]")),
        labelSummaryNameMentioned(By.xpath("(//div[contains(text(),'Name Mentioned')])[1]")),
        labelSummaryTo(By.xpath("(//div[contains(text(),'To')])[1]")),
        labelSummaryFrom(By.xpath("(//div[contains(text(),'From')])[1]")),
        labelSummaryDuration(By.xpath("(//div[contains(text(),'Duration')])[1]")),
        labelSummaryLanguageDetected(By.xpath("(//div[contains(text(),'Detected Language')])[1]")),
        labelSummaryNumberOfParticipants(By.xpath("(//div[contains(text(),'Number of Participants')])[1]")),
        labelSummaryChatParticipants(By.xpath("(//div[contains(text(),'Chat Participants')])[1]")),
        labelSummarySourceId(By.xpath("(//div[contains(text(),'Source ID')])[1]")),
        valueSummarySender(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[2]")),
        valueSummaryReceiver(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[3]")),
        valueSummaryAttachment(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[4]")),
        valueSummarySource(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[5]")),
        valueSummarySentiment(By.xpath("(//div[contains(text(),'Sentiment')])[1]/../../div[2]/div[1]")),
        valueSummaryKeyPhrases(By.xpath("(//div[contains(text(),'Sentiment')])[1]/../../div[2]/div[2]")),
        valueSummaryConcepts(By.xpath("(//div[contains(text(),'Sentiment')])[1]/../../div[2]/div[3]")),
        valueSummaryCompaniesMentioned(By.xpath("(//div[contains(text(),'Sentiment')])[1]/../../div[2]/div[4]")),
        valueSummaryNameMentioned(By.xpath("(//div[contains(text(),'Sentiment')])[1]/../../div[2]/div[5]")),
        valueSummaryTo(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[3]")),
        valueSummaryFrom(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[2]")),
        valueSummaryDuration(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[4]")),
        valueSummaryLanguageDetected(By.xpath("(//div[contains(text(),'Sentiment')])[1]/../../div[2]/div[2]")),
        valueSummaryNumberOfParticipants(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[2]")),
        valueSummaryChatParticipants(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[3]")),
        valueSummarySourceId(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[6]")),
        valueSummarySourceIdForChat(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[5]")),
        labelSummaryDirection(By.xpath("(//div[contains(text(),'Direction')])[1]")),
        valueSummaryDirection(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[5]")),
        labelSummaryPublisher(By.xpath("(//div[contains(text(),'Publisher')])[1]")),
        valueSummaryPublisher(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[2]")),
        labelSummaryAuthor(By.xpath("(//div[contains(text(),'Author')])[1]")),
        valueSummaryAuthor(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[3]")),
        labelSummaryAttachmentName(By.xpath("(//div[contains(text(),'Attachment Name')])[1]")),
        valueSummaryAttachmentName(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[3]")),
        labelSummaryAttachmentType(By.xpath("(//div[contains(text(),'Attachment Type')])[1]")),
        valueSummaryAttachmentType(By.xpath("(//div[contains(text(),'Item Type')])[1]/../../div[2]/div[4]")),


        ;
        private By findBy;

        Header(By locator) {
            this.findBy = locator;
        }
    };

    public void validateViewWorkItemSection() throws Throwable {
        isElementDisplayed(Header.imageApplicationLogo.findBy);
        verifyText(Header.labelWorkFlow.findBy,"Workflow");
        verifyText(Header.labelEntityInsights.findBy,"Entity Insights");
        if(fetchAttribute(Header.labelEntityInsights.findBy,"class").contains("selected"))
        {
            logPass(driver,"Entity Insights is selected by default");
        }else{
            logFail(driver,"Entity Insights is not selected by default");
        }
    }

    public void validateWorkItemDetailsHeaderSection(String workItemType) throws IOException, InterruptedException {
        if(!workItemType.equalsIgnoreCase("Order")) {
            verifyText(Header.labelCommunicationWorkItem.findBy,"Communication Work Item: "+workItemType);
        }
        verifyContainsText(Header.labelIssueId.findBy,"Issue ID");
        verifyContainsText(Header.labelIssueDate.findBy, "Issue Date");
        verifyContainsText(Header.labelBusinessUnit.findBy, "Business Unit");
        verifyContainsText(Header.labelStep.findBy, "Step");
        verifyContainsText(Header.labelScore.findBy, "Score");
    }

    public void validateWorkItemHighlightHeaderSection(String workItemType) throws IOException, InterruptedException {
        verifyText(Header.labelItemType.findBy, "Item Type");
        verifyText(Header.valueItemType.findBy, workItemType);
        verifyText(Header.labelItemDate.findBy, "Item Date");
        verifyTextWithNonEmptyString(Header.valueItemDate.findBy);
        verifyText(Header.labelScore1.findBy, "Score");
        verifyTextWithNonEmptyString(Header.valueScore1.findBy);
        if(workItemType.equalsIgnoreCase("Voice"))
        {
            verifyText(Header.labelFrom.findBy, "From");
            verifyTextWithNonEmptyString(Header.valueFrom.findBy);
            //verifyText(Header.labelTo.findBy, "To");
            verifyTextWithNonEmptyString(Header.valueTo.findBy);
            verifyText(Header.labelDuration.findBy, "Duration");
            verifyTextWithNonEmptyString(Header.valueDuration.findBy);
            //verifyText(Header.labelOwner.findBy, "Owner");
            //verifyTextWithNonEmptyString(Header.valueOwner.findBy);
        }
        if(workItemType.equalsIgnoreCase("Email")){
            verifyText(Header.labelSender.findBy, "Sender");
            verifyTextWithNonEmptyString(Header.valueSender.findBy);
            verifyText(Header.labelReceiver.findBy, "Receiver");
            verifyTextWithNonEmptyString(Header.valueReceiver.findBy);
        }
        if(workItemType.equalsIgnoreCase("Chat")){
            //verifyText(Header.labelOwner.findBy, "Owner");
            //verifyTextWithNonEmptyString(Header.valueOwner.findBy);
            verifyText(Header.labelNumberOfParticipants.findBy, "Number of Participants");
            verifyTextWithNonEmptyString(Header.valueNumberOfParticipants.findBy);
        }
        if(workItemType.equalsIgnoreCase("News")){
            verifyText(Header.labelPublisher.findBy, "Publisher");
            verifyTextWithNonEmptyString(Header.valuePublisher.findBy);
            verifyText(Header.labelAuthor.findBy, "Author");
            verifyTextWithNonEmptyString(Header.valueAuthor.findBy);
        }
        if(workItemType.equalsIgnoreCase("Attachment")){
            verifyText(Header.labelSender.findBy, "Sender");
            verifyTextWithNonEmptyString(Header.valueSender.findBy);
            verifyText(Header.labelReceiver.findBy, "Receiver");
            verifyTextWithNonEmptyString(Header.valueReceiver.findBy);
            verifyText(Header.labelAttachmentName.findBy, "Attachment Name");
            verifyTextWithNonEmptyString(Header.valueAttachmentName.findBy);
        }

    }

    public void validateWorkItemSummaryExpandedSection(String workItemType) throws Throwable {
        verifyAndClick(Header.imageSummaryExpanded.findBy);
        verifyText(Header.labelSummaryDetails.findBy, "Summary Details");
        verifyText(Header.labelDescription.findBy, "Description");
        verifyText(Header.labelSummaryItemType.findBy, "Item Type:");
        verifyText(Header.valueSummaryItemType.findBy, workItemType);
        verifyText(Header.labelSummaryKeyPhrases.findBy, "Key Phrases:");
        verifyTextWithNonEmptyString(Header.valueSummaryKeyPhrases.findBy);
        verifyText(Header.labelSummaryConcepts.findBy, "Concepts:");
        verifyTextWithNonEmptyString(Header.valueSummaryConcepts.findBy);
        verifyText(Header.labelSummarySentiment.findBy, "Sentiment:");
        verifyTextWithNonEmptyString(Header.valueSummarySentiment.findBy);
        verifyText(Header.labelSummaryCompaniesMentioned.findBy, "Companies Mentioned:");
        verifyTextWithNonEmptyString(Header.valueSummaryCompaniesMentioned.findBy);
        if(workItemType.equalsIgnoreCase("Email")){
            verifyText(Header.labelSummarySender.findBy, "Sender:");
            verifyTextWithNonEmptyString(Header.valueSummarySender.findBy);
            verifyText(Header.labelSummaryReceiver.findBy, "Receiver:");
            verifyTextWithNonEmptyString(Header.valueSummaryReceiver.findBy);
            verifyText(Header.labelSummaryAttachment.findBy, "Attachment:");
            verifyTextWithNonEmptyString(Header.valueSummaryAttachment.findBy);
            verifyText(Header.labelSummarySource.findBy, "Source:");
            verifyTextWithNonEmptyString(Header.valueSummarySource.findBy);
            verifyText(Header.labelSummaryNameMentioned.findBy, "Name Mentioned:");
            verifyTextWithNonEmptyString(Header.valueSummaryNameMentioned.findBy);
            verifyText(Header.labelSummarySourceId.findBy, "Source ID:");
            verifyTextWithNonEmptyString(Header.valueSummarySourceId.findBy);
        }
        if(workItemType.equalsIgnoreCase("Voice")){
            verifyText(Header.labelSummaryFrom.findBy, "From:");
            verifyTextWithNonEmptyString(Header.valueSummaryFrom.findBy);
            //verifyText(Header.labelSummaryTo.findBy, "To:");
            verifyTextWithNonEmptyString(Header.valueSummaryTo.findBy);
            verifyText(Header.labelSummaryDuration.findBy, "Duration:");
            verifyTextWithNonEmptyString(Header.valueSummaryDuration.findBy);
            verifyText(Header.labelSummaryLanguageDetected.findBy, "Detected Language:");
            verifyTextWithNonEmptyString(Header.valueSummaryLanguageDetected.findBy);
            verifyText(Header.labelSummaryDirection.findBy,"Direction:");
            verifyTextWithNonEmptyString(Header.valueSummaryDirection.findBy);
        }
        if(workItemType.equalsIgnoreCase("Chat")){
            verifyText(Header.labelSummaryNumberOfParticipants.findBy, "Number of Participants:");
            verifyTextWithNonEmptyString(Header.valueSummaryNumberOfParticipants.findBy);
            verifyText(Header.labelSummaryChatParticipants.findBy, "Chat Participants:");
            verifyTextWithNonEmptyString(Header.valueSummaryChatParticipants.findBy);
            verifyText(Header.labelSummarySourceId.findBy, "Source ID:");
            verifyTextWithNonEmptyString(Header.valueSummarySourceIdForChat.findBy);
            verifyText(Header.labelSummarySource.findBy, "Source:");
            verifyTextWithNonEmptyString(Header.valueSummarySource.findBy);
            verifyText(Header.labelSummaryNameMentioned.findBy, "Name Mentioned:");
            verifyTextWithNonEmptyString(Header.valueSummaryNameMentioned.findBy);
        }
        if(workItemType.equalsIgnoreCase("News")){
            verifyText(Header.labelSummaryNameMentioned.findBy, "Name Mentioned:");
            verifyTextWithNonEmptyString(Header.valueSummaryNameMentioned.findBy);
            verifyText(Header.labelSummarySourceId.findBy, "Source ID:");
            verifyTextWithNonEmptyString(Header.valueSummarySourceIdForChat.findBy);
            verifyText(Header.labelSummarySource.findBy, "Source:");
            verifyTextWithNonEmptyString(Header.valueSummarySource.findBy);
            verifyText(Header.labelSummaryPublisher.findBy, "Publisher:");
            verifyTextWithNonEmptyString(Header.valueSummaryPublisher.findBy);
            verifyText(Header.labelSummaryAuthor.findBy, "Author:");
            verifyTextWithNonEmptyString(Header.valueSummaryAuthor.findBy);
        }
        if(workItemType.equalsIgnoreCase("Attachment")){
            verifyText(Header.labelSummaryNameMentioned.findBy, "Name Mentioned:");
            verifyTextWithNonEmptyString(Header.valueSummaryNameMentioned.findBy);
            verifyText(Header.labelSummarySourceId.findBy, "Source ID:");
            verifyTextWithNonEmptyString(Header.valueSummarySourceIdForChat.findBy);
            verifyText(Header.labelSummarySource.findBy, "Source:");
            verifyTextWithNonEmptyString(Header.valueSummarySource.findBy);
            verifyText(Header.labelSummarySender.findBy, "Sender:");
            verifyTextWithNonEmptyString(Header.valueSummarySender.findBy);
            verifyText(Header.labelSummaryReceiver.findBy, "Receiver:");
            verifyTextWithNonEmptyString(Header.valueSummaryReceiver.findBy);
            verifyText(Header.labelSummaryAttachmentName.findBy, "Attachment Name:");
            verifyTextWithNonEmptyString(Header.valueSummaryAttachmentName.findBy);
            verifyText(Header.labelSummaryAttachmentType.findBy, "Attachment Type / Format:");
            verifyTextWithNonEmptyString(Header.valueSummaryAttachmentType.findBy);
        }
    }
}