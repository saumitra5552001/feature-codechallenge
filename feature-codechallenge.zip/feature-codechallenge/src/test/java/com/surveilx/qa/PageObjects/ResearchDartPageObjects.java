package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.StepDefinition.CommonSteps;
import com.surveilx.qa.StepDefinition.LoginSteps;
import com.surveilx.qa.StepDefinition.NavigationSteps;
import com.surveilx.qa.StepDefinition.WorkItemsSteps;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ResearchDartPageObjects extends CommonFunctions {

    public ResearchDartPageObjects(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    }

    LoginSteps loginsteps = new LoginSteps();
    NavigationSteps navigation = new NavigationSteps();
    CommonSteps commonSteps = new CommonSteps();


    private enum ResearchDart {
        /* Research  - DART page object */
        dataSourceDropDownOnDartPage (By.xpath(".//select[@id='dataSource']")),
        queryDropDownOnDartPage (By.xpath(".//select[@id='investigationQuery']")),
        goButtonOnDartPage (By.xpath(".//td[@id='textButton_btnGoQuery']")),

        ;
        private By findBy;

        ResearchDart(By locator)
        {
            this.findBy = locator;
        }
    }

    @FindBy(xpath = ".//td[@id='cell_1_1']")
    public WebElement orderIdForQueryResultOnDartPage;

    public void clickOnDataSourceDropDown() throws Throwable {
        sleep(8);
        selectElementFromDropdown(ResearchDart.dataSourceDropDownOnDartPage.findBy,"MSC Transaction Finder");
    }

    public void clickOnQueryDropDown() throws Throwable {
        sleep(5);
        selectElementFromDropdown(ResearchDart.queryDropDownOnDartPage.findBy,"MSC_TransactionFinderQuery");
    }

    public void clickOnGoButtonOnDartPage() throws Throwable {
        sleep(3);
        verifyAndClick(ResearchDart.goButtonOnDartPage.findBy);
    }

}
