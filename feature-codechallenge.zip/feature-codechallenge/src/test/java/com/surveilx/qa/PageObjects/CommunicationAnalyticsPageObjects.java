package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.StepDefinition.CommonSteps;
import com.surveilx.qa.StepDefinition.LoginSteps;
import com.surveilx.qa.StepDefinition.NavigationSteps;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;
import java.util.List;
import java.util.Random;

public class CommunicationAnalyticsPageObjects extends CommonFunctions {

    public CommunicationAnalyticsPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    LoginSteps loginsteps = new LoginSteps();
    NavigationSteps navigation = new NavigationSteps();
    CommonSteps commonSteps = new CommonSteps();

    private enum dashboard {
        dropdownDashboardName(By.id("triangle-list")),
        msgBoardSelection(By.xpath("//div[@class='list-header']")),
        value1stDashboardName(By.xpath("//li[@id='dropdown-page0']/span[1]")),
        buttonEditDashboardName(By.xpath("//span[@class='list-controls edit']")),
        inputDashboardName(By.xpath("//input[@class='title-input']")),
        buttonDiscardchanges(By.xpath("//span[@class='list-controls cancel']")),
        buttonConfirmchanges(By.xpath("//span[@class='list-controls confirm']")),
        buttonSettings(By.id("widgetlibrary-cogwheel")),
        buttonDropdownSettings(By.id("dropdownMenu-triangle-icon")),
        headerDropdownMenu(By.id("dropdown-menu-header")),
        messageSetDefault(By.id("set-dashboard-as-default")),
        iconCancelSetDefault(By.id("set-dashboard-as-default-cancel-icon")),
        iconOkSetDefault(By.id("set-dashboard-as-default-ok-icon")),
        notificationText(By.id("notificationText")),
        notificationClose(By.id("notificationClose")),
        dateDropdown(By.xpath("(//span[contains(@class,'k-dropdown-wrap k-state-default')])[1]")),
        listLastWeek(By.xpath("//li[text()='Last Week']")),
        listLast4Week(By.xpath("//li[text()='Last 4 Weeks']")),
        listBetween(By.xpath("//li[text()='Between']")),
        startCalendar(By.xpath("(//span[@class='k-icon k-i-calendar'])[1]/..")),
        buttonNextMonthFromCalendar(By.xpath("(//span[@class='k-icon k-i-arrow-60-right'])[1]")),
        buttonNextMonthToCalendar(By.xpath("(//span[@class='k-icon k-i-arrow-60-right'])[2]")),
        endCalendar(By.xpath("(//span[@class='k-icon k-i-calendar'])[2]/..")),
        linkTodayDate(By.xpath("(//td[contains(@class,'k-today')]/a)[2]")),
        buttonPreviousMonthFromCalendar(By.xpath("(//span[@class='k-icon k-i-arrow-60-left'])[1]")),
        buttonPreviousMonthToCalendar(By.xpath("(//span[@class='k-icon k-i-arrow-60-left'])[2]")),
        dashboardFromDate(By.xpath("//input[@id='datepicker-from']")),
        dashboardToDate(By.xpath("//input[@id='datepicker-to']")),
        buttonNavigateExplore(By.id("targetIconContainer")),
        exploreFromDate(By.xpath("//input[@id='datePickerFrom']")),
        exploreToDate(By.xpath("//input[@id='datePickerTo']")),
        labelTimeZone(By.xpath("//span[contains(text(),'Time Zone:')]")),
        valueTimeZone(By.xpath("//span[@class='timezoneNameText']")),
        valueDateExplore(By.xpath("//div[@class='apf-interaction-details-content-date']/span")),
        valueLocalTimeZone(By.xpath("//div[@class='timezone-popup-option-item-islocal']")),
        select1stScenario(By.xpath("(//div[@class='k-listview-content']/div[1])[1]")),
        open1stScenario(By.xpath("(//div[@class='sa_menu_button sa_menu_open'])[1]")),
        buttonExplore(By.xpath("//div[contains(text(),' Explore')]")),
        buttonVisualize(By.xpath("//div[contains(text(),'Visualize')]")),
        buttonScenarios(By.xpath("(//div[contains(text(),' Scenarios')])[1]")),

        ;
        private By findBy;

        dashboard(By locator) {
            this.findBy = locator;
        }
    }

    @FindBy(xpath="//div[@class='timezone-popup-option-item']")
    List<WebElement> listTimeZone;

    public void iValidateDashboardNameChangeFunctionalityForDiscard() throws Throwable {
        verifyAndClick(dashboard.dropdownDashboardName.findBy);
        verifyText(dashboard.msgBoardSelection.findBy,"Board Selection");
        String defaultDashboardname = fetchText(dashboard.value1stDashboardName.findBy);
        mouseHoverToElement(dashboard.value1stDashboardName.findBy);
        verifyAndClickViaJavaScript(dashboard.buttonEditDashboardName.findBy);
        String randomDashboardname = "Dashboard "+getRandomStringString();
        verifyAndEnterText(dashboard.inputDashboardName.findBy,randomDashboardname);
        verifyAndClick(dashboard.buttonDiscardchanges.findBy);
        String updatedDashboardname = fetchText(dashboard.value1stDashboardName.findBy);
        if(defaultDashboardname.equalsIgnoreCase(updatedDashboardname)){
            logPass(driver,"Dashbboard Name Discard functionality is working fine");
        }else{
            logFail(driver,"Dashbboard Name Discard functionality is not working fine");
        }
        verifyAndClick(dashboard.dropdownDashboardName.findBy);
    }

    public void iValidateDashboardNameChangeFunctionalityForConfirm() throws Throwable {
        verifyAndClick(dashboard.dropdownDashboardName.findBy);
        verifyText(dashboard.msgBoardSelection.findBy,"Board Selection");
        String defaultDashboardname = fetchText(dashboard.value1stDashboardName.findBy);
        mouseHoverToElement(dashboard.value1stDashboardName.findBy);
        verifyAndClickViaJavaScript(dashboard.buttonEditDashboardName.findBy);
        String randomDashboardname = "Dashboard "+getRandomStringString();
        verifyAndEnterText(dashboard.inputDashboardName.findBy,randomDashboardname);
        verifyAndClick(dashboard.buttonConfirmchanges.findBy);
        String updatedDashboardname = fetchText(dashboard.value1stDashboardName.findBy);
        if(defaultDashboardname.equalsIgnoreCase(updatedDashboardname)){
            logFail(driver,"Dashbboard Name Confirm functionality is not working fine");
        }else{
            logPass(driver,"Dashbboard Name Confirm functionality is working fine");
        }
        verifyAndClick(dashboard.dropdownDashboardName.findBy);
    }

    public void iValidateDashboardSetAsDefaultCancel() throws Throwable {
        verifyAndClickViaJavaScript(dashboard.buttonSettings.findBy);
        verifyAndClick(dashboard.buttonDropdownSettings.findBy);
        verifyText(dashboard.headerDropdownMenu.findBy,"More");
        verifyText(dashboard.messageSetDefault.findBy,"Set as default for users without a dashboard");
        verifyAndClick(dashboard.messageSetDefault.findBy);
        verifyText(dashboard.messageSetDefault.findBy,"Set as default?");
        verifyAndClick(dashboard.iconCancelSetDefault.findBy);
    }

    public void iValidateDashboardSetAsDefaultOk() throws Throwable {
        sleep(10);
        verifyAndClick(dashboard.buttonDropdownSettings.findBy);
        verifyAndClick(dashboard.messageSetDefault.findBy);
        verifyAndClick(dashboard.iconOkSetDefault.findBy);
        verifyText(dashboard.notificationText.findBy,"Default Dashboard configuration was saved successfully.");
        verifyAndClick(dashboard.notificationClose.findBy);
    }

    public void iValidateDashboardWithLastWeekFilter() throws Throwable {
        sleep(20);
        verifyAndClickViaJavaScript(dashboard.dateDropdown.findBy);
        verifyAndClick(dashboard.listLastWeek.findBy);
        sleep(5);
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='panel-wrapper']"));
        if(elements.size()==6){
            logPass(driver,elements.size()+" no of widget is displayed");
        }else{
            logFail(driver,elements.size()+" no of widget is displayed");
        }
        System.out.println("-------------------------------------------------------------------------------------");
        String s = fetchPageSource();
        //System.out.println(s);
    }

    public static String last4weekPageContent;
    public void iValidateDashboardWithLast4WeekFilter() throws Throwable {
        verifyAndClickViaJavaScript(dashboard.dateDropdown.findBy);
        verifyAndClick(dashboard.listLast4Week.findBy);
        sleep(5);
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='panel-wrapper']"));
        if(elements.size()==6){
            logPass(driver,elements.size()+" no of widget is displayed");
        }else{
            logFail(driver,elements.size()+" no of widget is displayed");
        }
        System.out.println("-------------------------------------------------------------------------------------");
        last4weekPageContent = fetchPageSource();
        System.out.println(last4weekPageContent);
    }

    public static String betweenDatePageContent;
    public void iValidateDashboardWithBetweenDateFilter() throws Throwable {
        verifyAndClickViaJavaScript(dashboard.dateDropdown.findBy);
        verifyAndClick(dashboard.listBetween.findBy);
        sleep(3);
        verifyAndClickViaJavaScript(dashboard.startCalendar.findBy);
        for(int i =0;i<7;i++){
            sleep(2);
            verifyAndClick(dashboard.buttonPreviousMonthFromCalendar.findBy);
        }
        pressEnterButtonWithoutElement();
        sleep(2);
        verifyAndClickViaJavaScript(dashboard.endCalendar.findBy);
        sleep(2);
        pressEnterButtonWithoutElement();
        sleep(5);
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='panel-wrapper']"));
        if(elements.size()==7){
            logPass(driver,elements.size()+" no of widget is displayed");
        }else{
            logFail(driver,elements.size()+" no of widget is displayed");
        }
        betweenDatePageContent = fetchPageSource();
        System.out.println(betweenDatePageContent);
    }

    public void iValidateDashboardDateValueWithExploreDateValue() throws Throwable {
        String dashboardFromDate = fetchAttribute(dashboard.dashboardFromDate.findBy,"value");
        String dashboardToDate = fetchAttribute(dashboard.dashboardToDate.findBy,"value");
        verifyAndClick(dashboard.buttonNavigateExplore.findBy);
        String exploreFromDate = fetchAttribute(dashboard.exploreFromDate.findBy,"value");
        String exploreToDate = fetchAttribute(dashboard.exploreToDate.findBy,"value");
        verifyText(dashboardFromDate,exploreFromDate);
        verifyText(dashboardToDate,exploreToDate);
    }

    public void iValidateDashboardViewForTimezone() throws Throwable {
        String initialdashboardFromDate = fetchAttribute(dashboard.dashboardFromDate.findBy,"value");
        String initialdashboardToDate = fetchAttribute(dashboard.dashboardToDate.findBy,"value");
        verifyText(dashboard.labelTimeZone.findBy,"Time Zone: ");
        verifyAndClick(dashboard.valueTimeZone.findBy);
        Random rand = new Random();
        int randomNum = rand.nextInt((7 - 1) + 1) + 1;
        sleep(3);
        verifyAndClick(listTimeZone.get(randomNum));
        String updateddashboardFromDate = fetchAttribute(dashboard.dashboardFromDate.findBy,"value");
        String updateddashboardToDate = fetchAttribute(dashboard.dashboardToDate.findBy,"value");
        sleep(5);
        if(initialdashboardFromDate.equalsIgnoreCase(updateddashboardFromDate)){
            logFail(driver,"Time and Date is not getting changed according to timezone");
            logFail("Local Timezone:"+initialdashboardFromDate+" vs Changed Timezone:"+updateddashboardFromDate);
        }else{
            logPass(driver,"Time and Date are getting changed according to timezone");
            logPass("Local Timezone:"+initialdashboardFromDate+" vs Changed Timezone:"+updateddashboardFromDate);
        }
        if(initialdashboardToDate.equalsIgnoreCase(updateddashboardToDate)){
            logFail(driver,"Time and Date is not getting changed according to timezone");
            logFail("Local Timezone:"+initialdashboardToDate+" vs Changed Timezone:"+updateddashboardToDate);
        }else{
            logPass(driver,"Time and Date are getting changed according to timezone");
            logPass("Local Timezone:"+initialdashboardToDate+" vs Changed Timezone:"+updateddashboardToDate);
        }
        verifyAndClick(dashboard.valueTimeZone.findBy);
        sleep(3);
        verifyAndClick(dashboard.valueLocalTimeZone.findBy);
    }

    public void iNavigateDashboardViewInExplorePage() throws Throwable {
        sleep(10);
        verifyAndClick(dashboard.buttonScenarios.findBy);
        verifyAndClick(dashboard.select1stScenario.findBy);
        verifyAndClick(dashboard.open1stScenario.findBy);
        verifyAndClick(dashboard.buttonExplore.findBy);
        verifyAndClick(dashboard.buttonVisualize.findBy);
    }

    public void iValidateDashboardViewForExplorePage() throws IOException, InterruptedException {
        sleep(40);
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='panel-wrapper']"));
        if(elements.size()==4){
            logPass(driver,elements.size()+" no of widget is displayed");
        }else{
            logFail(driver,elements.size()+" no of widget is displayed");
        }
    }

    public void pageContentVerification(){
        if(last4weekPageContent.equalsIgnoreCase(betweenDatePageContent)){
            logFail("Page content is same");
        }else{
            logPass("Page content is not same");
        }
    }

}