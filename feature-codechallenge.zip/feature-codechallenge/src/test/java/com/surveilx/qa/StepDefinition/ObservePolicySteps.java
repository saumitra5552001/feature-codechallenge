package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.NetworkVoiceConnectorPageObjects;
import com.surveilx.qa.PageObjects.ObservePolicyPageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class ObservePolicySteps extends CommonFunctions {

    ObservePolicyPageObjects oppom = new ObservePolicyPageObjects(driver);

    @And("I verify Observe Policy Page UI$")
    public void iVerifyObservePolicyPageUI() throws Throwable {
        oppom.iValidateObservePolicyPageUI();
    }

    @Then("I create Observe Policy$")
    public void iCreateObservePolicy() throws Throwable {
        oppom.iCreateObservePolicy();
    }

    @Then("I remove existing policy if any$")
    public void iRemoveExistingPolicyIfAny() throws Throwable {
        oppom.removeExistingPolicyIfAny();
    }


}
