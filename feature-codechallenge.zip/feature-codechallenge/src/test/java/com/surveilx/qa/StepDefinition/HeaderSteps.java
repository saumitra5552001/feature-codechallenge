package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.HeaderPageObject;
import io.cucumber.java.en.Then;

import java.util.List;

public class HeaderSteps extends CommonFunctions {

    HeaderPageObject headerpom = new HeaderPageObject(driver);

    @Then("^I verify view work item section$")
    public void iVerifyViewWorkItemSection() throws Throwable {
        headerpom.validateViewWorkItemSection();
    }

    @Then("^I verify work item details header section as \"([^\"]*)\"$")
    public void iVerifyWorkItemDetailsHeaderSection(String workItemType) throws Exception {
        headerpom.validateWorkItemDetailsHeaderSection(workItemType);
    }

    @Then("^I verify work item highlight header section as \"([^\"]*)\"$")
    public void iVerifyWorkItemHighlightHeaderSection(String workItemType) throws Exception {
        headerpom.validateWorkItemHighlightHeaderSection(workItemType);
    }

    @Then("^I verify work item summary expanded section as \"([^\"]*)\"$")
    public void iVerifyWorkItemSummaryExpandedSection(String workItemType) throws Throwable {
        headerpom.validateWorkItemSummaryExpandedSection(workItemType);
    }
}
