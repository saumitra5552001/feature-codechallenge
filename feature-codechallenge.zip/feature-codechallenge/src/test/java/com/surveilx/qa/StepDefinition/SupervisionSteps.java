package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.SupervisionPageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class SupervisionSteps extends CommonFunctions {

    SupervisionPageObjects communicationpom = new SupervisionPageObjects(driver);

    @Then("^I verify work item Communication section as \"([^\"]*)\"$")
    public void iVerifyWorkItemCommunicationSection(String itemType) throws Throwable {
        String itemId =communicationpom.getItemID();
        communicationpom.clickOnTabNameToggleButton();
        communicationpom.validatePresetPanelCollepsed();
        communicationpom.clickOnTabNameToggleButton();
        communicationpom.validatePresetPanelExpanded();
        communicationpom.clickOnTabNameToggleButton();
        communicationpom.validatePresetPanelCollepsed();
        communicationpom.mouseHoverToCommunicationTab();
        communicationpom.mouseHoverToInvestigateTab();
        communicationpom.clickOn3DotButton();
        communicationpom.validateOn3DotButton();
        communicationpom.clickOnFullScreenButton();
        communicationpom.closeButtonOnFullScreenScreen();
        communicationpom.clickOn3DotButton();
        communicationpom.clickOnDetachAsNewTabButton();
        communicationpom.tabHandleForCommunicationNewTab(itemId,itemType);
        //communicationpom.validateUIOfSuperVisionPart(itemType);
    }

    @Then("^I verify work item Investigate section$")
    public void iVerifyWorkItemInvestigateSection() throws Throwable {
        communicationpom.clickOnInvestigateTab();
        communicationpom.createNewInteractionScenario();
    }

    @Then("^I verify work item Investigate functionality section$")
    public void iVerifyWorkItemInvestigateFunctionalitySection() throws Throwable {
        communicationpom.clickOnInvestigateTab();
        communicationpom.closeInteractions();
    }

    @Then("^I navigate to investigate section$")
    public void iNavigateToInvestigateSection() throws Throwable {
        communicationpom.clickOnInvestigateTab();
    }

    @Then("^I verify work item Investigate for Correlated as \"([^\"]*)\"$")
    public void iVerifyWorkItemInvestigateForCorrelated(String itemId) throws Throwable {
        communicationpom.clickOnInvestigateTab();
        communicationpom.validateCorrelatedInteractions(itemId);
    }

    @Then("^I verify no of Interactions as \"([^\"]*)\"$")
    public void iVerifyNoOfInteractions(String noOfInteractions) throws Throwable {
        communicationpom.validateInteractionsFunctionalityCounts(noOfInteractions);
    }

    @Then("^I verify no of Interactions in same frame as \"([^\"]*)\"$")
    public void iVerifyNoOfInteractionsInSameFrame(String noOfInteractions) throws Throwable {
        communicationpom.validateInteractionsFunctionalityCountsInSameFrame(noOfInteractions);
    }

    @And("I select multiple interactions for scenario$")
    public void iSelectMultipleInteractionsForScenario() throws Throwable {
        communicationpom.selectMultipleInteractions();
    }

    @And("I verify scenario overview text$")
    public void iVerifyScenarioOverviewText() throws Throwable {
        communicationpom.validateScenarioOverviewText();
    }

    @Then("I verify scenario creation for empty scenario$")
    public void iVerifyScenarioCreationForEmptyScenario() throws Throwable {
        communicationpom.clickOnInvestigateTab();
        communicationpom.validateScenarioCreationForEmptyScenario();
    }

    @Then("I verify download option in Communication Tab$")
    public void iVerifyDownloadOptionInCommunicationTab() throws Throwable {
        communicationpom.clickOnDownloadOption();
    }

    @Then("I verify download option in Investigate Tab$")
    public void iVerifyDownloadOptionInInvestigateTab() throws Throwable {
        communicationpom.clickOnDownloadOptionForInvestigateTab();
    }

    @Then("I verify Remove Scenarios option in Investigate Tab$")
    public void iVerifyRemoveScenariosOptionInInvestigateTab() throws Throwable {
        communicationpom.clickOnRemoveScenariosOptionForInvestigateTab();
    }

    @Then("I verify rules functionality as \"([^\"]*)\"$")
    public void iVerifyRulesFunctionality(String rulecheck) throws Throwable {
        communicationpom.ivalidateRulesUI();
        communicationpom.ivalidateRulesFunctionality(rulecheck);
    }


}
