package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.AuditHistoryPageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class AuditHistorySteps extends CommonFunctions {

    AuditHistoryPageObjects auditpom = new AuditHistoryPageObjects(driver);

    @Then("I verify UI of Audit History Page$")
    public void iVerifyUIofAuditHistoryPage() throws Throwable {
        auditpom.iValidateUIofAuditHistoryPage();
    }

    @Then("I verify audit history for Explore filter functionality$")
    public void iVerifyAuditHistoryForExploreFilterFunctionality() throws Throwable {
        auditpom.checkLogsForExploreFilterFunctionality();
    }

    @Then("I verify audit history for Explore open interaction functionality$")
    public void iVerifyAuditHistoryForExploreOpenInteractionFunctionality() throws Throwable {
        auditpom.checkLogsForExploreOpenInteractionFunctionality();
    }

    @Then("I verify audit history for Explore download result metadata functionality$")
    public void iVerifyAuditHistoryForExploreDownloadResultMetadataFunctionality() throws Throwable {
        auditpom.checkLogsForExploreDownloadResultMetadataFunctionality();
    }

    @Then("I verify audit history for Explore save search functionality$")
    public void iVerifyAuditHistoryForExploreSaveSearchFunctionality() throws Throwable {
        auditpom.checkLogsForExploreSaveSearchFunctionality();
    }

    @Then("I verify audit history for Explore default search functionality$")
    public void iVerifyAuditHistoryForExploreDefaultSearchFunctionality() throws Throwable {
        auditpom.checkLogsForExploreDefaultSearchFunctionality();
    }

    @Then("I verify audit history for Explore delete search functionality$")
    public void iVerifyAuditHistoryForExploreDeleteSearchFunctionality() throws Throwable {
        auditpom.checkLogsForExploreDeleteSearchFunctionality();
    }

    @Then("I verify audit history for login functionality$")
    public void iVerifyAuditHistoryForLoginFunctionality() throws Throwable {
        auditpom.checkLogsForLoginFunctionality();
    }




}
