package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;

public class ObservePolicyPageObjects extends CommonFunctions {

    public ObservePolicyPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private enum OP {
        headerObserve(By.xpath("//span[text()='Observe']")),
        labelConfiguration(By.xpath("//h2[contains(text(),'Configuration')]")),
        labelWorkFlowComponents(By.xpath("//div[contains(text(),'Workflow')]")),
        buttonCreateNew(By.xpath("//div[contains(@class,'create-new-component-options-container')]")),
        labelCreateActions(By.xpath("//*[contains(text(),'Create actions:')]")),
        buttonCreateNew1(By.xpath("//*[contains(text(),'Create new')]")),
        linkImport(By.xpath("//*[contains(text(),'Import')]")),
        textFileInput(By.id("import_model_file_select_input")),
        textFileInput1(By.xpath("//span[@class='import-model-popup-file-selection-text']")),
        buttonImport(By.xpath("//span[text()='Import']")),
        clickableinput(By.xpath("//div[@class='import-model-clickable-input-area']")),
        inputModelName(By.xpath("//input[@class='model-name-input inactive-input']")),
        drpModelName(By.xpath("//input[@class='k-input label-input-combobox model-details-label-search-input labelSearchInput']")),
        inputThreshold(By.xpath("//input[@class='model-detail-threshold-input inactive-input grey-border']")),
        inputNewRuleName(By.xpath("//input[@class='new-rule-name']")),
        inputNewRuleScore(By.xpath("//input[@class='new-rule-score']")),
        labelParameterName(By.xpath("//*[@class='rule-param-name']")),
        inputQueryName(By.xpath("(//*[@placeholder='Add new query'])[1]")),
        inputQueryDesc(By.xpath("(//*[@placeholder='Type query...'])[1]")),
        buttonAdd(By.xpath("(//*[contains(@class,'add-new-query-button')])[1]")),
        buttonSave(By.xpath("(//*[contains(@class,'save-button button')])[1]")),
        arrowCollapse(By.xpath("(//*[contains(@class,'expand-collapse-icon right-floated-line-icon expanded')])[1]")),
        labelMsg(By.xpath("//span[text()='Add label when exceeding:']")),
        buttonConfirm(By.xpath("//div[@class='buttons confirm']")),

        ;
        private By findBy;

        OP(By locator) {
            this.findBy = locator;
        }
    }

    public By valueXpath(String s) {
        return By.xpath("//*[text()='" + s + "']");
    }

    @FindBy(xpath="(//*[contains(@class,'remove-icon')])[1]")
    List<WebElement> listRemoveButton;

    public void iValidateObservePolicyPageUI() throws Throwable {
        verifyText(OP.headerObserve.findBy,"Observe");
        verifyText(OP.labelConfiguration.findBy,"Configuration");
        verifyText(OP.labelWorkFlowComponents.findBy,"Workflow components");
        verifyAndClick(OP.buttonCreateNew.findBy);
        verifyText(OP.labelCreateActions.findBy,"Create actions:");
        verifyText(OP.buttonCreateNew1.findBy,"Create new");
        verifyText(OP.linkImport.findBy,"Import");
//        verifyAndClick(OP.linkImport.findBy);
//        verifyAndClick(OP.clickableinput.findBy);
//        String modelFile = "C:\\Users\\pgandhi\\Downloads\\Secrecy.model";
//        StringSelection ss = new StringSelection(modelFile);
//        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
//        //native key strokes for CTRL, V and ENTER keys
//        Robot robot = new Robot();
//        robot.keyPress(KeyEvent.VK_CONTROL);
//        robot.keyPress(KeyEvent.VK_V);
//        robot.keyRelease(KeyEvent.VK_V);
//        robot.keyRelease(KeyEvent.VK_CONTROL);
//        robot.keyPress(KeyEvent.VK_ENTER);
//        robot.keyRelease(KeyEvent.VK_ENTER);
//        verifyAndClick(OP.buttonImport.findBy);
        //verifyAndEnterTextViaJavaScript(OP.textFileInput1.findBy,"C:\\Users\\pgandhi\\Downloads\\Secrecy.model");
    }

    public void iCreateObservePolicy() throws Throwable {
        verifyAndClick(OP.buttonCreateNew1.findBy);
        verifyAndEnterText(OP.inputModelName.findBy,getRandomStringString());
        verifyAndEnterText(OP.drpModelName.findBy,"SSecrecy");
        informationBreachAdd();
        avoidAttentionAdd();
        offlineConversation();
        verifyAndEnterText(OP.inputThreshold.findBy,"49");
        verifyAndClick(OP.labelMsg.findBy);
        sleep(10);
        verifyAndClick(OP.buttonSave.findBy);
        sleep(30);
    }

    public void informationBreachAdd() throws Throwable {
        verifyAndEnterText(OP.inputNewRuleName.findBy,"Information Breach");
        verifyAndEnterText(OP.inputNewRuleScore.findBy,"100");
        verifyAndClick(OP.labelParameterName.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(do, not, share, distance=2)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(for, your, eyes, only)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"or(gossip, hearsay)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(common, knowledge, distance=3)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(before, known)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"confidential");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(not, public, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(do, not, hear, it, from, me, distance=6)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndClick(OP.arrowCollapse.findBy);
    }

    public void avoidAttentionAdd() throws Throwable {
        verifyAndEnterText(OP.inputNewRuleName.findBy,"Avoid Attention");
        verifyAndEnterText(OP.inputNewRuleScore.findBy,"200");
        verifyAndClick(OP.labelParameterName.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(be, discreet, distance=3)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(uncomfortable, saying, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"near(between, you, or(i, me), distance=3)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(or(off, under), or(record, radar), distance=2)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(keep, or(down, low))");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(keep, to, your, self, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(keep, quiet, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(do, not, bring, attention, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(be, careful, distance=2)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndClick(OP.arrowCollapse.findBy);
    }

    public void offlineConversation() throws Throwable {
        verifyAndEnterText(OP.inputNewRuleName.findBy,"Offline Conversation");
        verifyAndEnterText(OP.inputNewRuleScore.findBy,"100");
        verifyAndClick(OP.labelParameterName.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"near(in, or(private, toilet, basement, family, pub, bar),distance=3)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(after, or(hours, work), distance=3)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(or(off, offline, call), or(cell, mobile, cellphone, phone, offline, off, line, conversation), distance=5)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(can, or(not, out), office)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(call, my, mobile, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(check, your, email, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(out, for, smoke, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(take, this, offline, distance=4)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(check, or(chat, email, text), distance=3)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(go, to, chat, room)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(meet, somewhere, distance=3)");
        verifyAndClick(OP.buttonAdd.findBy);
        verifyAndEnterText(OP.inputQueryDesc.findBy,"onear(talk, outside, or(bank, building), distance=6)");
        verifyAndClick(OP.buttonAdd.findBy);
    }

    public void removeExistingPolicyIfAny() throws Throwable {
        if(listRemoveButton.size()==1){
            verifyAndClickViaJavaScript(listRemoveButton.get(0));
            verifyAndClick(OP.buttonConfirm.findBy);
            sleep(10);
        }
    }


}