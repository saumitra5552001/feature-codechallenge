package com.surveilx.qa.runner;

import com.aventstack.extentreports.Status;
import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.Reporting.ExtentManager;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.IOException;

public class TestNGListener extends CommonFunctions implements ITestListener {

    public static String getTestMethodName(ITestResult iTestResult) {
        return iTestResult.getMethod().getConstructorOrMethod().getName();
    }

    public void onTestSuccess(ITestResult iTestResult) {
        //ExtentManager.getTest().log(Status.PASS,"Test Case Passed");
    }

    public void onTestFailure(ITestResult iTestResult) {
        iTestResult.getThrowable().printStackTrace();
        ExtentManager.getTest().log(Status.FAIL, "Test Case Failed");
    }

    public static void onTestSkip(ITestResult iTestResult) {
        iTestResult.getThrowable().printStackTrace();
        ExtentManager.getTest().log(Status.SKIP, "Test Case Skipped");
    }

    public void onStart(ITestContext iTestContext) {
        getInstance();
        try {
            loadConfig("src/test/resources/config.properties");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void onFinish(ITestContext iTestContext) {
        endTest();
    }
}
