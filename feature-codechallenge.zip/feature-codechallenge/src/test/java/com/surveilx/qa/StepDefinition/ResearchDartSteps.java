package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.NavigationPageObjects;
import com.surveilx.qa.PageObjects.PageObject;
import com.surveilx.qa.PageObjects.ResearchDartPageObjects;
import com.surveilx.qa.PageObjects.WorkbenchWorkItemsPageObjects;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.testng.Assert;


public class ResearchDartSteps extends CommonFunctions {

    LoginSteps loginstepsobj = new LoginSteps();
    NavigationPageObjects navigationpageobj = new NavigationPageObjects(driver);
    PageObject pom = new PageObject(driver);
    WorkbenchWorkItemsPageObjects workitemsobj = new WorkbenchWorkItemsPageObjects(driver);
    ResearchDartPageObjects researchdartobj = new ResearchDartPageObjects(driver);

    @Then("User verify and clicks Research-Dart Submenu")
    public void userVerifyAndClicksResearchDartSubmenu() throws Throwable {
        navigationpageobj.clickOnResearchTitleAndValidateItsName();
        navigationpageobj.clicksOnDARTAndValidateItsName();
    }

    @Then("User landed on DART page")
    public void userLandedOnDARTPage() throws Throwable {
        getPageTitle(jsonRead.readStringFromDataJSON("dartPageTitle"));
    }

    @Then("User selects the data source MSC Transaction Finder from dropdown")
    public void userSelectsTheDataSourceMSCTransactionFinderFromDropdown() throws Throwable {
        sleep(8);
        researchdartobj.clickOnDataSourceDropDown();
        sleep(3);
    }

    @And("User selects the query option MSC_TransactionFinderQuery from dropdown")
    public void userSelectsTheQueryOptionMSC_TransactionFinderQueryFromDropdown() throws Throwable {
        sleep(8);
        researchdartobj.clickOnQueryDropDown();
        sleep(3);
    }


    @Then("User clicks on Go button")
    public void userClicksOnGoButton() throws Throwable {
        researchdartobj.clickOnGoButtonOnDartPage();
        sleep(5);
    }

    @Then("User verify any order ID present or not")
    public void userVerifyAnyOrderIDPresentOrNot() throws Throwable {
        if (verifyElementPresent(researchdartobj.orderIdForQueryResultOnDartPage))
        {
            logPass(driver, "Some order ID available for query results");
        }
        else
        {
            logFail(driver, "No order ID available for query results");
        }
    }
}