package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.NTRPageObjects;
import com.surveilx.qa.PageObjects.NetworkVoiceConnectorPageObjects;
import io.cucumber.java.en.And;

public class NetworkVoiceConnectorSteps extends CommonFunctions {

    NetworkVoiceConnectorPageObjects nvcpom = new NetworkVoiceConnectorPageObjects(driver);

    @And("I verify Network Voice Connector Page UI$")
    public void iVerifyNICETradingRecordingPageUI() throws Throwable {
        nvcpom.iValidateNICETradingRecordingPageUI();
    }

    @And("I add new source$")
    public void iAddNewSource() throws Throwable {
        nvcpom.iAddNewSource();
    }

    @And("I remove existing source if any$")
    public void removeExistingSourceIfAny() throws Throwable {
        nvcpom.removeSourceIfAny();
    }


}
