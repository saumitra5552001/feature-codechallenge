package com.surveilx.qa.PageObjects;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;
import java.util.List;

public class NetworkVoiceConnectorPageObjects extends CommonFunctions {

    public NetworkVoiceConnectorPageObjects(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private enum NVC {
        headerNVC(By.xpath("//span[text()='Network Share']")),
        labelAddNewSource(By.xpath("//div[contains(text(),'Add new source...')]")),
        buttonAdd(By.xpath("//div[contains(@class,'configuration-add-new-icon')]")),
        headerSourceName(By.xpath("//h2[contains(text(),'Source name')]")),
        labelSourceName(By.xpath("//label[contains(text(),'Source name')]")),
        headerAudio(By.xpath("//h2[contains(text(),'Audio')]")),
        headerAuthentication(By.xpath("//h2[contains(text(),'Authentication')]")),
        headerMetadata(By.xpath("//h2[contains(text(),'Meta data')]")),
        headerSpeechToTextConversion(By.xpath("//h2[contains(text(),'Speech to Text Conversion')]")),
        inputSourceName(By.xpath("(//input[@class='k-textbox'])[1]")),
        dropdownSourceType(By.xpath("(//span[@class='k-dropdown-wrap k-state-default'])[1]/span[1]")),
        dropdownNetworkValue(By.xpath("(//li[text()='Network'])[1]")),
        inputNetworkShare(By.xpath("(//input[@class='k-textbox'])[2]")),
        checkboxServiceCredential(By.xpath("//label[contains(text(),'Use service')]/../input")),
        inputUsername(By.xpath("(//input[@class='k-textbox'])[3]")),
        inputPassword(By.xpath("(//input[@class='k-textbox'])[4]")),
        inputFieldSeparator(By.xpath("(//input[@class='k-textbox'])[5]")),
        inputValueSeparator(By.xpath("(//input[@class='k-textbox'])[6]")),
        dropdownSpeechToText(By.xpath("(//span[@class='k-dropdown-wrap k-state-default'])[3]")),
        dropdownNexidiaSearchGridValue(By.xpath("(//li[text()='Nexidia Search Grid'])[1]/span[1]")),
        buttonSave(By.xpath("//button[contains(text(),'Save')]")),
        msgNotification(By.id("notificationText")),
        buttonConfirm(By.xpath("//div[@class='buttons confirm']")),
        ;
        private By findBy;

        NVC(By locator) {
            this.findBy = locator;
        }
    }

    public By valueXpath(String s) {
        return By.xpath("//*[text()='" + s + "']");
    }

    @FindBy(xpath="//div[@class='configuration-settings-remove']")
    List<WebElement> listRemoveButton;

    public void iValidateNICETradingRecordingPageUI() throws Throwable {
        verifyText(NVC.headerNVC.findBy,"Network Share");
        verifyText(NVC.labelAddNewSource.findBy,"Add new source...");
        verifyAndClick(NVC.buttonAdd.findBy);
        verifyText(NVC.headerSourceName.findBy,"Source Name");
        verifyText(NVC.labelSourceName.findBy,"Source Name");
        verifyText(NVC.headerAudio.findBy,"Audio");
        verifyText(NVC.headerAuthentication.findBy,"Authentication");
        verifyText(NVC.headerMetadata.findBy,"Meta data");
        verifyText(NVC.headerSpeechToTextConversion.findBy,"Speech to Text Conversion");
    }

    public void iAddNewSource() throws Throwable {
        scrollIntoView(NVC.inputSourceName.findBy);
        verifyAndEnterText(NVC.inputSourceName.findBy,getRandomStringString());
        verifyAndClickViaJavaScript(NVC.dropdownSourceType.findBy);
        pressDownButtonWithoutElement();
        sleep(4);
        pressDownButtonWithoutElement();
        verifyAndEnterText(NVC.inputNetworkShare.findBy,"\\\\ess-skt-023\\Network Share");
        verifyAndClick(NVC.checkboxServiceCredential.findBy);
        verifyAndEnterText(NVC.inputUsername.findBy,"ess-skt-023\\Administrator");
        verifyAndEnterText(NVC.inputPassword.findBy,"Cyb3rt3ch");
        verifyAndEnterText(NVC.inputFieldSeparator.findBy,",");
        verifyAndEnterText(NVC.inputValueSeparator.findBy,"|");
        verifyAndClickViaJavaScript(NVC.dropdownSpeechToText.findBy);
        sleep(2);
        pressDownButtonWithoutElement();
        verifyAndClick(NVC.buttonSave.findBy);
        verifyText(NVC.msgNotification.findBy,"Files source configuration settings were saved successfully.");
    }

    public void removeSourceIfAny() throws Throwable {
        if(listRemoveButton.size()==1){
            verifyAndClickViaJavaScript(listRemoveButton.get(0));
            verifyAndClick(NVC.buttonConfirm.findBy);
            verifyText(NVC.msgNotification.findBy,"Files configuration has been successfully removed.");
        }
    }

}