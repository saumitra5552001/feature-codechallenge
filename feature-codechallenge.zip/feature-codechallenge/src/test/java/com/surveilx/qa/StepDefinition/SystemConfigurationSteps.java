package com.surveilx.qa.StepDefinition;

import com.surveilx.qa.BaseLibrary.CommonFunctions;
import com.surveilx.qa.PageObjects.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;


public class SystemConfigurationSteps extends CommonFunctions {

    LoginSteps loginstepsobj = new LoginSteps();
    NavigationPageObjects navigationpageobj = new NavigationPageObjects(driver);
    PageObject pom = new PageObject(driver);
    WorkbenchWorkItemsPageObjects workitemsobj = new WorkbenchWorkItemsPageObjects(driver);
    ResearchDartPageObjects researchdartobj = new ResearchDartPageObjects(driver);
    SettingsPageObjects settingspageobj = new SettingsPageObjects(driver);
    SystemConfigurationPageObjects systemConfigPageObj = new SystemConfigurationPageObjects(driver);

    @Then("User verify and clicks on System Configuration option")
    public void user_verify_and_clicks_on_system_configuration_option() throws Throwable {
        systemConfigPageObj.verifyAndClicksOnSystemConfigurationOption();
    }

    @Then("User landed on Config Parameter page")
    public void user_landed_on_config_parameter_page() throws Throwable {
        systemConfigPageObj.verifyUserLandedOnConfigParameterPage();
    }

    @Then("User verify the different options available for System Configuration")
    public void user_verify_the_different_options_available_for_system_configuration() throws Throwable {
        systemConfigPageObj.verifyOtionsAvailableForSystemConfiguration();
    }

    @Then("User verify all tabs are working with default settings in System Configuration menu")
    public void user_verify_all_tabs_are_working_with_default_settings_in_system_configuration_menu() throws Throwable {
        systemConfigPageObj.verifyAllTabsAreWorkingWithSystemConfiguration();
    }


    @Then("User clicks on Connection tab and verify connection name URL")
    public void user_clicks_on_connection_tab_and_verify_connection_name_url() throws Throwable {
        systemConfigPageObj.clicksOnConnectionTabAndVerifyConnectionNameURL();
    }


    @Then("User validate connectivity using Test Connection for {string}")
    public void user_validate_connectivity_using_test_connection_for(String connection_name) throws Throwable {
        systemConfigPageObj.validateConnectivityUsingTestConnection(connection_name);
    }

}