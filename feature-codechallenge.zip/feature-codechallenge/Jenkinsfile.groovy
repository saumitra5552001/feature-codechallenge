    //import com.actimize.automation.redeye.tests.JDBCNews
import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import org.apache.maven.model.Build

import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl = 'gitlab@tlvgit03.nice.com:srukmangad/uiautomation.git'

pipeline {

    agent {
        label 'AI_Build_Agent'
    }

    options {
        buildDiscarder(
                logRotator(numToKeepStr: '50')
        )
        timestamps()
        ansiColor('xterm')
    }

    parameters {
        string(defaultValue: 'master', description: 'generic branch for build', name: 'BRANCH_NAME')
        booleanParam(defaultValue: false, description: 'Whether to execute a Maven release process', name: 'PERFORM_RELEASE')
//        string(defaultValue: '', description: 'The version to be released', name: 'RELEASE_VERSION')
//        string(defaultValue: '', descKription: 'The next development version', name: 'DEVELOPMENT_VERSION')
    }

    triggers { cron('30 21 * * *') }

    stages {
        stage('Preparations', {
            steps {
                script {

                    wrap([$class: 'BuildUser']) { //Using this wrapped we get access to the user's info
                      buildUserEmail =  "saumitra.rukmangad@niceactimize.com"
                     //   buildUserEmail = "saumitra.rukmangad@niceactimize.com"
//                        buildUserEmail2 = "${env.BUILD_USER_EMAIL}"
//                        buildUserEmail3 = "${env.BUILD_USER_EMAIL}"
                    }
                }
            }
        })
        stage('Build & Unit Test', {
            steps {
                script {
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                        )
                        String setting_file = "${WORKSPACE}/pipelines/ascii_art_build/settings/setting.xml"
                        if (params.PERFORM_RELEASE) {
                            //deploy release
                            sh "git config.properties --global user.name 'gitlab'"
                            sh "git config.properties --global user.email 'gitlab@nice.com'"
//                            sh "mvn -B release:prepare release:perform -DdevelopmentVersion=${params.DEVELOPMENT_VERSION} -DreleaseVersion=${params.RELEASE_VERSION} -Dresume=false -s '${setting_file}'  -Dmaven.repo.local='${WORKSPACE}\\.repository'"
//                            sh "mvn -B release:branch -DbranchName=release/v${params.RELEASE_VERSION} -DupdateBranchVersions=true -DupdateWorkingCopyVersions=false"
                        } else {
                            sh "mvn  test -DsuiteXmlFile=TestNG.xml"
                        }
                    }
                }
            }

        })
    }//stages

    post {
        always {
            //  archiveArtifacts artifacts: 'build\\target\\release\\*.zip', onlyIfSuccessful: true
            script {
                sendEmailNotification(this, currentBuild.result as String, buildUserEmail)
                cleanWs()
            }
        }
    }

}
